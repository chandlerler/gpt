# 糯米 · 像素金毛桌宠

一个可离线运行的 Chrome Manifest V3 插件，让像素金毛住在普通网页底部。默认叫「糯米」，名字可以修改。

## 安装

1. 解压 `golden-companion-1.0.0.zip`。
2. 在 Chrome 地址栏输入 `chrome://extensions`。
3. 打开右上角「开发者模式」。
4. 点击「加载已解压的扩展程序」，选择解压后**包含 `manifest.json` 的 `golden-companion` 文件夹**。如果直接使用源码，则选择 `extension` 文件夹。
5. 在工具栏的拼图图标中固定本插件。
6. 打开普通 HTTP / HTTPS 网页；**已有网页请刷新一次**。

不需要执行 npm install，不需要账号、服务器或 API Key。不要直接把 ZIP 拖进 Chrome，也不要双击 `popup.html` 当作插件运行。

## 玩法

| 操作 | 行为 |
| --- | --- |
| 等它自己玩 | 随机散步、奔跑、摇尾巴、休息，碰到窗口边缘转身 |
| 点击金毛 | 摸摸头、冒爱心，增加心情 |
| 按住拖动 | 抱起来移动，松开后落回网页底部 |
| 右键金毛 / 悬停后点「···」 | 打开网页内互动菜单 |
| 喂一口 | 走到食盆边、吃饭、增加饱食度 |
| 扔小球 | 奔跑追球，增加心情并消耗体力 |
| 睡一会 | 趴下睡觉，每 15 秒恢复部分体力 |
| 散散步 / 跑起来 | 立即切换到指定活动 |

工具栏面板可查看饱食度、心情、体力和累计互动次数，修改名字、调节 70%–150% 大小、暂停、全局隐藏。名字最多 12 个字符。键盘可用 Tab 选择桌宠与按钮、Enter 互动、Esc 关闭桌宠菜单。

喂食间隔 8 秒、玩球间隔 5 秒；正在吃饭或追球时，需要先完成当前动作。喂食和玩球完成后才写入照顾记录。拖拽、暂停、隐藏、调整大小或窗口变化会取消尚未完成的活动。状态不会因为忘记照顾而归零或死亡。

## 运行范围与隐私

- **网页内桌宠**，不显示在浏览器外的系统桌面上。
- Chrome 内部页、新标签页、应用商店、其他插件页和内置 PDF 阅读器不支持；本版不匹配本地 `file://` 文件。
- 全屏内容、原生弹窗、页面特殊覆盖层可能遮住桌宠。
- 网页切换后会重新出现在底部；位置和当前动作各标签页独立，名字、数值和设置共享。
- 只申请 `storage` 权限；`content_scripts.matches` 匹配 HTTP / HTTPS 页面以显示桌宠。用户可在 Chrome 扩展详情中限制网站访问范围。
- 不读取网页正文、表单、浏览记录，不发送网络请求，不含分析统计、广告、远程代码、账号系统。
- 数据保存在 `chrome.storage.local`，卸载或清除扩展数据会删除记录。
- 不播放声音，不发通知。隐藏的标签页暂停动画，系统「减少动态效果」会降低动画和移动幅度。

## 工程结构

```text
extension/
  manifest.json             MV3 清单，安装入口
  background.js             串行处理状态修改，避免多标签页竞争覆盖
  core.js                   状态校验、冷却、离线变化等纯逻辑
  content.js                Shadow DOM 桌宠、有限状态动作、移动与拖拽
  pet.css / pet-style.js     样式源文件 / 打包后的内容脚本样式常量
  popup.html / css / js      中文互动和设置面板
  sprites.png               原创 80×64 像素，8 动作 × 8 帧
  icons/                    PNG 图标
  help.html / help.css       随插件提供的离线使用指南
tools/
  make_sprites.py            原创像素动画生成器（需要 Pillow）
  package.py                 生成样式常量，校验并打包可安装 ZIP
tests/
  core.test.cjs              状态逻辑测试
  browser_test.cjs           浏览器交互测试（Chrome API 测试适配层）
  server.cjs                 执行真实 background.js 的测试服务
  chrome-fixture.js          仅测试用 API 适配器，不打包
  native_browser_test.py     真实扩展加载测试，需允许未打包扩展的 Chromium
```

## 开发与验证

运行插件本身没有依赖。开发测试需要 Node.js、Python 3、Playwright 和 Chromium；重画动画需要 Pillow。

```sh
node --test tests/core.test.cjs
# 安装测试依赖后运行（默认 Chromium 路径为 /usr/bin/chromium）
node tests/browser_test.cjs
python3 tools/package.py
# 可选：重新生成像素动画后再打包
python3 tools/make_sprites.py
python3 tools/package.py
```

`pet.css` 修改后需运行 `tools/package.py`，它会更新 `pet-style.js`。Chrome 扩展页点刷新，再刷新目标网页。

### 验证边界

已进行纯状态逻辑测试及 Chromium 中的界面、移动、拖拽、喂食、追球、开关、多标签同步、并发写入、缺少内容脚本的提示等测试。浏览器测试使用 Chrome API 测试适配器，但执行产品的实际 `content.js`、`popup.js`、`core.js` 和 `background.js`，不将测试文件包含在安装包中。

**当前开发环境的管理员策略禁止加载未打包扩展**（Chromium 返回 `Loading of unpacked extensions is disabled by the administrator`）。因此，真实 MV3 加载、权限和隔离环境的端到端验证尚未在此环境通过；本机安装后应按上面的安装步骤确认。提供了 `tests/native_browser_test.py`，可在允许加载扩展的环境中运行。未发布到 Chrome 应用商店。
