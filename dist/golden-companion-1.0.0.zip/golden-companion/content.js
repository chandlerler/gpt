(() => {
  if (globalThis.__goldenCompanion) return;
  globalThis.__goldenCompanion = true;
  const { clamp, normalize } = GoldenCore;
  const el = (tag, className, text) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text) node.textContent = text;
    return node;
  };
  const host = document.createElement('golden-companion');
  host.id = 'golden-companion-root';
  const shadow = host.attachShadow({ mode: 'open' });
  const style = el('style'); style.textContent = GOLDEN_PET_STYLE;
  const world = el('div', 'world');
  const actor = el('div', 'actor');
  const dog = el('button', 'dog'); dog.type = 'button'; dog.title = '点击摸摸 · 拖拽移动 · 右键打开菜单';
  const sprite = el('span', 'sprite'); sprite.setAttribute('aria-hidden', 'true');
  sprite.style.backgroundImage = `url("${chrome.runtime.getURL('sprites.png')}")`;
  const trigger = el('button', 'menu-trigger', '···'); trigger.type = 'button'; trigger.setAttribute('aria-label', '打开桌宠菜单'); trigger.setAttribute('aria-expanded', 'false');
  const speech = el('div', 'speech'); speech.hidden = true; speech.setAttribute('role', 'status'); speech.setAttribute('aria-live', 'polite');
  const prop = el('div'); prop.hidden = true; prop.setAttribute('aria-hidden', 'true');
  const menu = el('div', 'menu'); menu.hidden = true; menu.setAttribute('role', 'dialog'); menu.setAttribute('aria-label', '金毛互动菜单');
  const head = el('div', 'menu-head'), name = el('strong', 'menu-name'), close = el('button', 'close', '×');
  close.type = 'button'; close.setAttribute('aria-label', '关闭菜单'); head.append(name, close);
  const summary = el('p', 'summary'), actions = el('div', 'actions');
  for (const [action, label] of [['feed','喂一口'],['pet','摸摸头'],['play','扔小球'],['walk','去散步'],['run','跑起来'],['sleep','睡一会']]) {
    const button = el('button', 'action', label); button.type = 'button'; button.dataset.action = action;
    button.addEventListener('click', () => { closeMenu(); command(action); }); actions.append(button);
  }
  menu.append(head, summary, actions, el('p', 'hint', '拖拽移动 · 暂停和大小可在插件面板设置'));
  dog.append(sprite); actor.append(dog, trigger); world.append(actor, prop, speech, menu); shadow.append(style, world);
  document.documentElement.append(host);

  let state = normalize(), x = Math.max(0, innerWidth - 220), y = 0, facing = -1;
  let mode = 'idle', remaining = 4, target = null, job = null, drag = null, falling = false, velocity = 0;
  let speechUntil = 0, elapsed = 0, sleepElapsed = 0, last = 0, raf = 0, frame = -1, disposed = false, lastTouch = 0;
  let actionPending = false;
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  const rows = { idle: 0, walk: 1, run: 2, happy: 3, eat: 4, sleep: 5, drag: 6, sit: 7 };
  const scale = () => Math.min(state.size / 100, innerWidth / 170, innerHeight / 138);
  const width = () => 160 * scale();
  const height = () => 128 * scale();
  const floor = () => Math.max(0, innerHeight - height() + 7 * scale() - 8);
  const bound = value => clamp(value, 0, Math.max(0, innerWidth - width()));

  async function request(action, payload) {
    try {
      const result = await chrome.runtime.sendMessage({ channel: 'golden-state', action, payload });
      if (result?.state) applyState(result.state);
      return result || { ok: false, message: '连接中断，请刷新网页。' };
    } catch {
      say('插件已更新，请刷新网页后继续玩。', 8);
      return { ok: false, message: '请刷新网页后重试。' };
    }
  }
  function applyState(next) {
    const wasPaused = state.paused, wasEnabled = state.enabled, oldSize = state.size;
    state = normalize(next);
    host.hidden = !state.enabled;
    // Inline important also survives host-page styles aimed at custom elements.
    host.style.setProperty('display', state.enabled ? 'block' : 'none', 'important');
    dog.setAttribute('aria-label', `摸摸${state.name}`);
    name.textContent = `${state.name} · 小金毛`;
    summary.textContent = `饱食 ${Math.round(state.hunger)}  ·  心情 ${Math.round(state.mood)}  ·  体力 ${Math.round(state.energy)}`;
    if ((!state.enabled && wasEnabled) || (state.paused && !wasPaused)) {
      cancelJob(); closeMenu(); mode = 'sit'; drag = null; falling = false;
    }
    if ((!state.paused && wasPaused) || (state.enabled && !wasEnabled)) setMode('idle', 3);
    if (oldSize !== state.size && job) { cancelJob(); setMode('idle', 3); }
    x = bound(x); if (!drag && !falling) y = floor();
    render(); schedule();
  }
  function say(text, seconds = 3) {
    speech.textContent = text; speechUntil = performance.now() + seconds * 1000; speech.hidden = false;
    positionUI();
  }
  function setMode(next, seconds = 4) {
    mode = next; remaining = seconds; elapsed = 0; frame = -1;
    actor.dataset.state = mode;
    if (next !== 'sleep') sleepElapsed = 0;
  }
  function cancelJob() { job = null; target = null; prop.hidden = true; }
  function closeMenu() { menu.hidden = true; trigger.setAttribute('aria-expanded', 'false'); }
  function openMenu() {
    if (!state.enabled) return;
    menu.hidden = !menu.hidden; trigger.setAttribute('aria-expanded', String(!menu.hidden));
    positionUI(); if (!menu.hidden) close.focus({ preventScroll: true });
  }
  close.addEventListener('click', () => { closeMenu(); dog.focus({ preventScroll: true }); });
  trigger.addEventListener('click', openMenu);
  dog.addEventListener('contextmenu', e => { e.preventDefault(); openMenu(); });
  shadow.addEventListener('keydown', e => { if (e.key === 'Escape') { closeMenu(); dog.focus({ preventScroll: true }); } });
  function hearts() {
    for (let i = 0; i < 3; i++) {
      const heart = el('span', 'effect', '♥');
      heart.style.left = `${x + width() * (.4 + i * .15)}px`; heart.style.top = `${y + height() * .18}px`;
      heart.style.animationDelay = `${i * .1}s`; world.append(heart); setTimeout(() => heart.remove(), 1700);
    }
  }
  function placeProp(type) {
    const maxX = Math.max(0, innerWidth - width());
    const offset = Math.max(50, Math.min(240, innerWidth * .3));
    const nextX = bound(x + (x < maxX / 2 ? offset : -offset));
    facing = nextX >= x ? 1 : -1;
    target = nextX;
    const propX = nextX + (facing === 1 ? width() * .84 : width() * .16) - (type === 'feed' ? 20 : 11);
    prop.className = type === 'feed' ? 'bowl' : 'ball';
    prop.style.left = `${clamp(propX, 0, Math.max(0, innerWidth - 40))}px`;
    prop.style.top = `${innerHeight - 35}px`; prop.hidden = false;
    job = { type, phase: 'approach', elapsed: 0 };
    setMode(type === 'feed' ? 'walk' : 'run', 30);
    say(type === 'feed' ? '闻到香香的饭啦！' : '小球，我来啦！');
  }
  async function command(action) {
    if (!['feed','pet','play','walk','run','sleep'].includes(action)) return { ok: false, message: '未知动作' };
    if (!state.enabled) return { ok: false, message: '请先打开“网页陪伴”。' };
    if (state.paused) { say('先取消暂停，我就来啦～'); return { ok: false, message: '请先取消“暂停活动”。' }; }
    if (job || actionPending || drag) return { ok: false, message: '正在忙这一件事，等我一下～' };
    closeMenu(); falling = false; y = floor();
    if (action === 'feed' || action === 'play') {
      // Cooldowns are checked again by the worker at completion.
      const wait = action === 'feed' ? 8000 : 5000;
      const previous = action === 'feed' ? state.lastFeed : state.lastPlay;
      if (Date.now() - previous < wait) {
        const message = action === 'feed' ? '刚吃过啦，等一小会儿再喂～' : '让我喘口气，再玩一次！';
        say(message); return { ok: false, message };
      }
      if (action === 'play' && state.energy < 12) { say('有点累啦，先睡一会儿～'); return { ok: false, message: '体力不足，先让它休息吧。' }; }
      placeProp(action);
    } else if (action === 'pet') {
      actionPending = true;
      const result = await request('pet'); actionPending = false;
      if (!state.enabled || state.paused) return result;
      setMode('happy', 2.5); hearts(); say(result.message); return result;
    } else if (action === 'sleep') {
      target = null; setMode('sleep', 30); say('Zzz… 睡个暖暖的小觉', 4);
    } else {
      target = null; facing = x > (innerWidth - width()) / 2 ? -1 : 1;
      setMode(action, 8); say(action === 'run' ? '看我的小短跑！' : '出发，巡逻小世界！');
    }
    schedule(); return { ok: true, message: '收到啦，看看网页下方的小金毛。' };
  }
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender.id !== chrome.runtime.id || message?.channel !== 'golden-pet') return;
    if (message.action === 'ping') { respond({ ok: true, mode, enabled: state.enabled }); return; }
    command(message.action).then(respond); return true;
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.pet?.newValue) applyState(changes.pet.newValue);
  });
  dog.addEventListener('pointerdown', e => {
    if (e.button !== 0 || state.paused) return;
    closeMenu(); cancelJob(); falling = false;
    drag = { id: e.pointerId, startX: e.clientX, startY: e.clientY, x, y, moved: false };
    dog.setPointerCapture(e.pointerId);
  });
  dog.addEventListener('pointermove', e => {
    if (!drag || drag.id !== e.pointerId) return;
    const dx = e.clientX - drag.startX, dy = e.clientY - drag.startY;
    if (Math.abs(dx) + Math.abs(dy) > 5) drag.moved = true;
    if (drag.moved) {
      setMode('drag', 10); x = bound(drag.x + dx); y = clamp(drag.y + dy, 0, floor());
      render();
    }
  });
  function release(e, cancelled = false) {
    if (!drag || drag.id !== e.pointerId) return;
    const moved = drag.moved; drag = null;
    if (dog.hasPointerCapture(e.pointerId)) dog.releasePointerCapture(e.pointerId);
    if (moved) { falling = true; velocity = 0; say('嘿咻，平稳落地！', 2); }
    else if (!cancelled) { lastTouch = performance.now(); command('pet'); }
    else setMode('idle', 2);
  }
  dog.addEventListener('pointerup', e => release(e));
  dog.addEventListener('pointercancel', e => release(e, true));
  dog.addEventListener('lostpointercapture', e => release(e, true));
  dog.addEventListener('click', e => {
    // Keyboard / assistive activation, pointer clicks are handled above.
    if (e.detail === 0 && performance.now() - lastTouch > 300) command('pet');
  });
  function choose() {
    target = null;
    if (state.energy < 22) { setMode('sleep', 25); return; }
    const r = Math.random(); facing = Math.random() < .5 ? -1 : 1;
    if (r < .44) setMode('walk', 4 + Math.random() * 5);
    else if (r < .64) setMode('run', 2 + Math.random() * 3);
    else if (r < .85) setMode('idle', 3 + Math.random() * 4);
    else setMode('sleep', 18);
  }
  async function finishJob(completed) {
    actionPending = true;
    const result = await request(completed.type === 'feed' ? 'feed' : 'play');
    actionPending = false;
    if (!state.enabled || state.paused || job !== completed) return;
    cancelJob(); setMode('happy', 3); say(result.message || '好开心！');
    if (result.ok) hearts();
  }
  function tick(now) {
    raf = 0;
    const dt = last ? Math.min((now - last) / 1000, .05) : 0; last = now;
    if (!state.enabled || document.hidden || disposed) { last = 0; return; }
    if (!state.paused && !drag && menu.hidden && !actionPending) {
      elapsed += dt;
      if (falling) {
        velocity += 900 * dt; y = Math.min(floor(), y + velocity * dt);
        if (y >= floor()) { falling = false; setMode('idle', 2); }
      } else {
        remaining -= dt;
        if (mode === 'walk' || mode === 'run') {
          const speed = (mode === 'run' ? 175 : 48) * scale() * (reducedMotion.matches ? .5 : 1);
          if (target !== null) {
            const distance = target - x;
            facing = distance >= 0 ? 1 : -1;
            x = bound(x + Math.sign(distance) * Math.min(Math.abs(distance), speed * dt));
            if (Math.abs(target - x) < 1 && job) {
              target = null; job.phase = 'interact'; job.elapsed = 0;
              if (job.type === 'feed') setMode('eat', 3);
              else { prop.hidden = true; setMode('happy', 1); }
            }
          } else {
            x += facing * speed * dt;
            if (x <= 0 || x >= innerWidth - width()) { x = bound(x); facing *= -1; }
          }
        }
        if (job?.phase === 'interact') {
          job.elapsed += dt;
          if (job.elapsed >= (job.type === 'feed' ? 2.5 : .8)) { job.phase = 'saving'; finishJob(job); }
        }
        if (mode === 'sleep') {
          sleepElapsed += dt;
          if (sleepElapsed >= 15) { sleepElapsed = 0; request('rest'); }
        }
        if (remaining <= 0 && !job) choose();
      }
    }
    if (!speech.hidden && now > speechUntil) speech.hidden = true;
    render(); schedule();
  }
  function positionUI() {
    speech.style.left = `${clamp(x + width() / 2 - 110, 8, Math.max(8, innerWidth - 248))}px`;
    speech.style.top = `${Math.max(8, y - 26)}px`;
    if (!menu.hidden) {
      menu.style.left = `${clamp(x + width() / 2 - 130, 8, Math.max(8, innerWidth - 268))}px`;
      menu.style.top = `${clamp(y - 205, 8, Math.max(8, innerHeight - 210))}px`;
    }
  }
  function render() {
    actor.dataset.state = mode;
    actor.style.transform = `translate3d(${x.toFixed(1)}px,${y.toFixed(1)}px,0) scale(${scale()})`;
    sprite.style.transform = `scaleX(${facing})`;
    const fps = mode === 'run' ? 16 : mode === 'walk' || mode === 'eat' ? 10 : 5;
    const nextFrame = state.paused || reducedMotion.matches || !menu.hidden ? 0 : Math.floor(elapsed * fps) % 8;
    if (frame !== nextFrame || sprite.dataset.mode !== mode) {
      frame = nextFrame; sprite.dataset.mode = mode;
      sprite.style.backgroundPosition = `${-frame * 160}px ${-rows[mode] * 128}px`;
    }
    positionUI();
  }
  function schedule() {
    if (!raf && !disposed && state.enabled && !document.hidden) raf = requestAnimationFrame(tick);
  }
  function resize() {
    x = bound(x); y = drag || falling ? clamp(y, 0, floor()) : floor();
    if (job) { cancelJob(); setMode('idle', 2); }
    render();
  }
  window.addEventListener('resize', resize, { passive: true });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) { cancelAnimationFrame(raf); raf = 0; last = 0; if (drag) { drag = null; falling = true; velocity = 0; } }
    else { request('get'); schedule(); }
  });
  // No timers animate a hidden tab. Care values are refreshed once a minute.
  const refresh = setInterval(() => { if (state.enabled && !document.hidden) request('get'); }, 60000);
  window.addEventListener('pagehide', e => {
    cancelAnimationFrame(raf); raf = 0; last = 0;
    if (!e.persisted) { disposed = true; clearInterval(refresh); }
  });
  window.addEventListener('pageshow', () => { schedule(); });
  y = floor(); request('get').then(() => { say(`汪！我是${state.name}，今天也陪着你。`, 5); schedule(); });
})();
