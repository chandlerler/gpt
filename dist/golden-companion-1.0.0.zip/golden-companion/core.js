/* Shared pure state logic; no page data or network access. */
(() => {
  const clamp = (n, min = 0, max = 100) => Math.max(min, Math.min(max, n));
  const defaults = (now = Date.now()) => ({
    version: 1, name: '糯米', enabled: true, paused: false, size: 100,
    hunger: 76, mood: 84, energy: 90, feeds: 0, pets: 0, games: 0,
    updatedAt: now, lastFeed: 0, lastPet: 0, lastPlay: 0, lastRest: 0
  });
  function normalize(raw = {}, now = Date.now()) {
    const s = defaults(now);
    if (!raw || typeof raw !== 'object') return s;
    for (const key of ['hunger', 'mood', 'energy']) {
      if (Number.isFinite(raw[key])) s[key] = clamp(raw[key]);
    }
    for (const key of ['feeds', 'pets', 'games', 'updatedAt', 'lastFeed', 'lastPet', 'lastPlay', 'lastRest']) {
      if (Number.isFinite(raw[key])) s[key] = Math.max(0, raw[key]);
    }
    s.updatedAt = Math.min(now, s.updatedAt);
    s.name = typeof raw.name === 'string' ? [...raw.name.trim()].slice(0, 12).join('') || '糯米' : s.name;
    s.enabled = typeof raw.enabled === 'boolean' ? raw.enabled : s.enabled;
    s.paused = typeof raw.paused === 'boolean' ? raw.paused : s.paused;
    s.size = Number.isFinite(raw.size) ? clamp(raw.size, 70, 150) : s.size;
    return s;
  }
  function advance(raw, now = Date.now()) {
    const s = normalize(raw, now);
    // Offline time is capped; the pet never dies and sleep restores energy.
    const minutes = Math.min(120, Math.max(0, now - s.updatedAt) / 60000);
    if (s.enabled && !s.paused) {
      s.hunger = clamp(s.hunger - minutes * 0.18, 15);
      s.mood = clamp(s.mood - minutes * 0.10, 25);
      s.energy = clamp(s.energy + minutes * 0.12);
    }
    s.updatedAt = now;
    return s;
  }
  function update(raw, action, payload = {}, now = Date.now()) {
    const s = advance(raw, now);
    let ok = true, message = '';
    switch (action) {
      case 'settings': {
        for (const key of ['name', 'enabled', 'paused', 'size']) {
          if (Object.hasOwn(payload, key)) s[key] = payload[key];
        }
        break;
      }
      case 'feed':
        if (now - s.lastFeed < 8000) { ok = false; message = '刚吃过啦，等一小会儿再喂～'; break; }
        s.hunger = clamp(s.hunger + 18); s.mood = clamp(s.mood + 5); s.feeds++; s.lastFeed = now;
        message = '咔嚓咔嚓，好香！'; break;
      case 'pet':
        if (now - s.lastPet < 1500) { ok = false; message = '最喜欢你的摸摸了 ♡'; break; }
        s.mood = clamp(s.mood + 7); s.pets++; s.lastPet = now;
        message = '最喜欢你的摸摸了 ♡'; break;
      case 'play':
        if (now - s.lastPlay < 5000) { ok = false; message = '让我喘口气，再玩一次！'; break; }
        if (s.energy < 12) { ok = false; message = '有点累啦，先让我睡一会儿～'; break; }
        s.mood = clamp(s.mood + 10); s.energy = clamp(s.energy - 8); s.games++; s.lastPlay = now;
        message = '捡到啦！再陪我玩一次吧'; break;
      case 'rest':
        if (now - s.lastRest >= 15000) { s.energy = clamp(s.energy + 8); s.lastRest = now; }
        break;
      case 'get': break;
      default: return { ok: false, message: '未知操作', state: s };
    }
    return { ok, message, state: normalize(s, now) };
  }
  const api = { clamp, defaults, normalize, advance, update };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else globalThis.GoldenCore = api;
})();
