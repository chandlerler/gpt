(() => {
  if (globalThis.__goldenCompanion) return;
  globalThis.__goldenCompanion = true;
  const { clamp, normalize, routine } = GoldenCore;
  const { launch, stepBall, sweptHit } = GoldenPhysics;
  const el = (tag, cls, text) => {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text) node.textContent = text;
    return node;
  };
  const button = (cls, text, label) => {
    const node = el('button', cls, text); node.type = 'button';
    if (label) node.setAttribute('aria-label', label);
    return node;
  };
  const host = el('golden-companion'); host.id = 'golden-companion-root';
  const shadow = host.attachShadow({ mode: 'open' });
  const style = el('style'); style.textContent = GOLDEN_PET_STYLE;
  const world = el('div', 'world'), actor = el('div', 'actor');
  const dog = button('dog'); dog.title = '点击摸摸 · 拖拽移动 · 右键打开菜单';
  const sprite = el('span', 'sprite'); sprite.setAttribute('aria-hidden', 'true');
  sprite.style.backgroundImage = `url("${chrome.runtime.getURL('sprites.png')}")`;
  const trigger = button('menu-trigger', '···', '打开桌宠菜单'); trigger.setAttribute('aria-expanded', 'false');
  const speech = el('div', 'speech'); speech.hidden = true; speech.setAttribute('role', 'status'); speech.setAttribute('aria-live', 'polite');
  const prop = el('div'); prop.hidden = true; prop.setAttribute('aria-hidden', 'true');
  const ballNode = el('div', 'ball'); ballNode.hidden = true; ballNode.setAttribute('aria-hidden', 'true');
  const kennel = button('kennel', '', '让金毛回窝休息');
  kennel.style.backgroundImage = `url("${chrome.runtime.getURL('kennel.png')}")`;
  const homeLabel = el('span', 'home-label'), homeStatus = el('span', 'home-status'); kennel.append(homeLabel, homeStatus);
  const menu = el('div', 'menu'); menu.hidden = true; menu.setAttribute('role', 'dialog'); menu.setAttribute('aria-label', '金毛互动菜单');
  const head = el('div', 'menu-head'), name = el('strong', 'menu-name'), close = button('close', '×', '关闭菜单');
  head.append(name, close);
  const summary = el('p', 'summary'), actions = el('div', 'actions');
  for (const [action, label] of [['feed','喂狗粮'],['banana','放香蕉'],['play','抛小球'],['pet','摸摸头'],['walk','去散步'],['run','跑起来'],['sleep','回窝睡觉']]) {
    const node = button('action', label); node.dataset.action = action;
    node.addEventListener('click', () => { closeMenu(); command(action); }); actions.append(node);
  }
  menu.append(head, summary, actions, el('p', 'hint', '香蕉和小球可以选位置 · 点击狗窝回家'));
  const aim = el('div', 'aim-layer'); aim.hidden = true; aim.tabIndex = -1; aim.setAttribute('role', 'dialog'); aim.setAttribute('aria-label', '选择道具位置');
  const guide = el('canvas', 'aim-guide'), hud = el('div', 'aim-hud'), aimText = el('span');
  const cancelAim = button('aim-cancel', '取消 · Esc'); hud.append(aimText, cancelAim); aim.append(guide, hud);
  dog.append(sprite); actor.append(dog, trigger);
  world.append(kennel, prop, actor, ballNode, speech, menu, aim); shadow.append(style, world); document.documentElement.append(host);

  let state = normalize(), ready = false, x = Math.max(0, innerWidth - 320), y = 0, facing = -1;
  let mode = 'idle', remaining = 4, elapsed = 0, frame = -1, last = 0, raf = 0, disposed = false;
  let job = null, target = null, drag = null, airborne = false, vy = 0, ball = null;
  let actionPending = false, speechUntil = 0, sleepElapsed = 0, lastTouch = 0;
  let placement = null, aimDrag = null, aimPoint = { x: innerWidth * .5, y: innerHeight * .4 };
  let peels = [], slipLeft = 0, hitPeel = null, manualUntil = 0, routineCheck = 0, routinePending = false, epoch = 0;
  let previousWidth = innerWidth;
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  const rows = { idle:0, walk:1, run:2, happy:3, eat:4, sleep:5, drag:6, sit:7, jump:8, slip:9 };
  const scale = () => Math.min(state.size / 100, innerWidth / 170, innerHeight / 150);
  const width = () => 160 * scale(), height = () => 128 * scale();
  const ground = () => innerHeight - 12;
  const floor = () => Math.max(0, ground() - 114 * scale());
  const bound = value => clamp(value, 0, Math.max(0, innerWidth - width()));
  const homeX = () => bound(innerWidth - 12 - 152 * scale());
  const homeFoodX = () => clamp(innerWidth - 12 - 162 * scale(), 24, Math.max(24, innerWidth - 24));
  const ballBounds = () => ({ width:innerWidth, height:ground() });
  const mouth = (px = x, py = y, direction = facing) => ({ x:px + width() * (direction === 1 ? .87 : .13), y:py + height() * .47 });
  const itemsImage = `url("${chrome.runtime.getURL('items.png')}")`;

  async function request(action, payload) {
    try {
      const result = await chrome.runtime.sendMessage({ channel:'golden-state', action, payload });
      if (result?.state) applyState(result.state);
      return result || { ok:false, message:'连接中断，请刷新网页。' };
    } catch {
      say('插件已更新，请刷新网页后继续玩。', 8);
      return { ok:false, message:'请刷新网页后重试。' };
    }
  }
  function applyState(next) {
    const previous = state; state = normalize(next);
    host.hidden = !state.enabled; host.style.setProperty('display', state.enabled ? 'block' : 'none', 'important');
    dog.setAttribute('aria-label', `摸摸${state.name}`); name.textContent = `${state.name} · 小金毛`;
    homeLabel.textContent = `${state.name}的小窝`;
    kennel.title = `点击回窝休息 · 本地时间 ${state.mealTimes.join(' / ')} 吃饭，${state.sleepStart}–${state.wakeTime} 睡觉`;
    summary.textContent = `饱食 ${Math.round(state.hunger)} · 心情 ${Math.round(state.mood)} · 体力 ${Math.round(state.energy)}`;
    if (!state.enabled && previous.enabled) { cancelJob(); clearPlacement(); closeMenu(); releaseDrag(); airborne = false; setMode('sit', 3); }
    if (state.paused && !previous.paused) { clearPlacement(); closeMenu(); releaseDrag(); }
    if (state.size !== previous.size) { cancelJob(); clearPlacement(); airborne = false; setMode('idle', 3); }
    if (JSON.stringify([state.scheduleEnabled,state.mealTimes,state.sleepStart,state.wakeTime]) !== JSON.stringify([previous.scheduleEnabled,previous.mealTimes,previous.sleepStart,previous.wakeTime])) {
      if (job?.scheduled) { cancelJob(); setMode('idle', 3); }
      routineCheck = 0; manualUntil = 0;
    }
    x = bound(x); if (!drag && !airborne) y = floor();
    render(); schedule();
  }
  function say(text, seconds = 3) {
    speech.textContent = text; speechUntil = performance.now() + seconds * 1000; speech.hidden = false; positionUI();
  }
  function setMode(next, seconds = 4) {
    mode = next; remaining = seconds; elapsed = 0; frame = -1; actor.dataset.state = mode;
    if (next !== 'sleep') sleepElapsed = 0;
  }
  function cancelJob(release = true) {
    const previous = job; job = null; target = null; prop.hidden = true; prop.style.backgroundImage = '';
    ball = null; ballNode.hidden = true;
    if (release && previous?.type === 'meal') request('releaseMeal', { token:previous.token });
  }
  function closeMenu() { menu.hidden = true; trigger.setAttribute('aria-expanded', 'false'); }
  function openMenu() {
    if (!state.enabled || placement) return;
    menu.hidden = !menu.hidden; trigger.setAttribute('aria-expanded', String(!menu.hidden)); positionUI();
    if (!menu.hidden) close.focus({ preventScroll:true });
  }
  close.addEventListener('click', () => { closeMenu(); dog.focus({ preventScroll:true }); });
  trigger.addEventListener('click', openMenu);
  kennel.addEventListener('click', () => command('sleep'));
  dog.addEventListener('contextmenu', e => { e.preventDefault(); openMenu(); });
  function hearts() {
    for (let i = 0; i < 3; i++) {
      const heart = el('span', 'effect', '♥'); heart.style.left = `${x + width() * (.4 + i * .15)}px`; heart.style.top = `${y + height() * .18}px`;
      heart.style.animationDelay = `${i * .1}s`; world.append(heart); setTimeout(() => heart.remove(), 1700);
    }
  }
  function foodTarget(foodX) {
    facing = foodX >= x + width() / 2 ? 1 : -1;
    return bound(foodX - width() * (facing === 1 ? .84 : .16));
  }
  function showFood(type, foodX, details = {}) {
    target = foodTarget(foodX);
    job = { type, phase:'approach', elapsed:0, foodX, ...details };
    prop.className = type === 'banana' ? 'banana' : 'bowl';
    prop.style.backgroundImage = type === 'banana' ? itemsImage : '';
    prop.hidden = false; positionProps(); setMode(type === 'banana' ? 'run' : 'walk', 90);
    say(type === 'banana' ? '香蕉！我来啦！' : type === 'meal' ? '饭点到啦，回家吃饭！' : '闻到香香的饭啦！');
  }
  function goHome(scheduled = false) {
    job = { type:'home', phase:'approach', scheduled, elapsed:0 };
    target = homeX(); setMode('walk', 90); say(scheduled ? '天晚了，回小窝睡觉啦。' : '回家睡个暖暖的小觉。');
  }
  function clearPlacement() {
    placement = null; aimDrag = null; aim.hidden = true;
  }
  function beginPlacement(type) {
    placement = type; aim.hidden = false; aimDrag = null;
    aimPoint = { x:clamp(x + width() / 2,24,Math.max(24,innerWidth-24)), y:Math.max(30,innerHeight * .4) };
    aimText.textContent = type === 'banana' ? '点击网页选择地面位置，放一只香蕉 · 方向键移动 / Enter 放下' : '按住选起点，拖动决定方向与力度，松手抛球 · 单击 / Enter 轻抛';
    aim.focus({ preventScroll:true }); drawAim();
  }
  function startBall(start, end) {
    clearPlacement(); cancelJob();
    const direction = start.x < innerWidth / 2 ? 1 : -1;
    ball = launch({ x:clamp(start.x,12,innerWidth-12), y:clamp(start.y,12,Math.max(12,ground()-12)) },end,direction);
    ballNode.hidden = false; ballNode.dataset.caught = 'false';
    job = { type:'play', phase:'chase', elapsed:0, jumpCooldown:0 }; setMode('run', 60); say('看我的飞扑接球！');
  }
  function commitBanana(px) {
    clearPlacement(); showFood('banana', clamp(px,24,Math.max(24,innerWidth-24)));
  }
  function drawAim() {
    if (!placement) return;
    guide.width = innerWidth; guide.height = innerHeight;
    const ctx = guide.getContext('2d'); if (!ctx) return;
    ctx.clearRect(0,0,guide.width,guide.height);
    if (placement === 'banana') {
      ctx.fillStyle = '#dec06d'; ctx.fillRect(aimPoint.x-20,ground()-4,40,4);
      ctx.strokeStyle = '#a89464'; ctx.setLineDash([4,7]); ctx.beginPath(); ctx.moveTo(aimPoint.x,ground()-70); ctx.lineTo(aimPoint.x,ground()-12); ctx.stroke();
      return;
    }
    const start = aimDrag?.start || aimPoint, end = aimDrag?.end || start;
    let preview = launch(start,end,start.x < innerWidth/2 ? 1 : -1);
    ctx.fillStyle = '#d18f5d'; ctx.fillRect(start.x-7,start.y-7,14,14);
    for (let i=0; i<28; i++) {
      preview = stepBall(preview,.035,ballBounds()); ctx.fillStyle = `rgba(116,137,86,${.65-i*.016})`; ctx.fillRect(preview.x-2,preview.y-2,4,4);
    }
  }
  cancelAim.addEventListener('click', () => { clearPlacement(); say('取消啦，继续陪你。'); });
  aim.addEventListener('pointerdown', e => {
    if (e.button !== 0 || e.target.closest('button') || e.target.closest('.aim-hud')) return;
    e.preventDefault(); e.stopPropagation();
    aimPoint = { x:e.clientX,y:e.clientY };
    aimDrag = { id:e.pointerId,start:{...aimPoint},end:{...aimPoint} }; aim.setPointerCapture(e.pointerId); drawAim();
  });
  aim.addEventListener('pointermove', e => {
    aimPoint = { x:e.clientX,y:e.clientY };
    if (aimDrag) aimDrag.end = {...aimPoint}; drawAim();
  });
  aim.addEventListener('pointerup', e => {
    if (!aimDrag || aimDrag.id !== e.pointerId) return;
    e.preventDefault(); e.stopPropagation(); const gesture = aimDrag, kind = placement;
    aimDrag = null; if (aim.hasPointerCapture(e.pointerId)) aim.releasePointerCapture(e.pointerId);
    if (kind === 'banana') commitBanana(e.clientX);
    else if (kind === 'play') startBall(gesture.start,{x:e.clientX,y:e.clientY});
  });
  aim.addEventListener('pointercancel', () => { aimDrag = null; drawAim(); });
  aim.addEventListener('lostpointercapture', () => { if (aimDrag) { aimDrag = null; drawAim(); } });
  document.addEventListener('keydown', e => {
    if (placement) {
      if (['Escape','Enter','ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)) { e.preventDefault(); e.stopPropagation(); }
      if (e.key === 'Escape') clearPlacement();
      if (e.key === 'Enter') { if (placement === 'banana') commitBanana(aimPoint.x); else startBall(aimPoint,aimPoint); }
      if (e.key.startsWith('Arrow')) {
        aimPoint.x = clamp(aimPoint.x + (e.key === 'ArrowLeft' ? -24 : e.key === 'ArrowRight' ? 24 : 0),12,Math.max(12,innerWidth-12));
        aimPoint.y = clamp(aimPoint.y + (e.key === 'ArrowUp' ? -24 : e.key === 'ArrowDown' ? 24 : 0),12,Math.max(12,ground()-12)); drawAim();
      }
    } else if (e.key === 'Escape' && !menu.hidden) { closeMenu(); dog.focus({preventScroll:true}); }
  },true);

  async function command(action) {
    if (!['feed','banana','pet','play','walk','run','sleep'].includes(action)) return { ok:false,message:'未知动作' };
    if (!state.enabled) return { ok:false,message:'请先打开“网页陪伴”。' };
    if (state.paused) { say('先取消暂停，我就来啦～'); return { ok:false,message:'请先取消“暂停活动”。' }; }
    if (actionPending || drag || slipLeft > 0) return { ok:false,message:'等我站稳，再陪你玩～' };
    if (job && job.type !== 'home' && !(job.type === 'play' && ['play','sleep'].includes(action))) { say('正在忙这一件事，等我一下～'); return { ok:false,message:'先等这次吃饭或接球完成吧。' }; }
    if (['feed','banana'].includes(action) && Date.now()-state.lastFeed < 8000) { say('刚吃过啦，等一小会儿再喂～'); return {ok:false,message:'刚吃过啦，等一小会儿再喂～'}; }
    if (action === 'banana' && peels.length >= 6) return {ok:false,message:'地上香蕉皮有点多，先让小狗走一走吧。'};
    if (action === 'play' && (Date.now()-state.lastPlay < 5000 || state.energy < 12)) return {ok:false,message:'先让小金毛休息一下，再来接球吧。'};
    epoch++; manualUntil = performance.now()+60000; closeMenu(); clearPlacement(); cancelJob(); airborne = false; y = floor();
    if (action === 'banana' || action === 'play') {
      beginPlacement(action); return {ok:true,placement:true,message:action === 'banana' ? '在网页点一下，选择香蕉落地的位置。' : '在网页按住拖动后松手，抛出你的小球。'};
    }
    if (action === 'feed') {
      const nextX = bound(x + (x < (innerWidth-width())/2 ? 240 : -240));
      const foodX = nextX + width() * (nextX >= x ? .84 : .16); showFood('feed',clamp(foodX,24,innerWidth-24));
    } else if (action === 'pet') {
      actionPending = true; const result = await request('pet'); actionPending = false;
      if (!state.enabled || state.paused) return result;
      setMode('happy',2.5); hearts(); say(result.message); return result;
    } else if (action === 'sleep') goHome(false);
    else { facing = x > (innerWidth-width())/2 ? -1 : 1; setMode(action,8); say(action === 'run' ? '看我的小短跑！' : '出发，巡逻小世界！'); }
    schedule(); return {ok:true,message:'收到啦，看看网页下方的小金毛。'};
  }
  chrome.runtime.onMessage.addListener((message,sender,respond) => {
    if (sender.id !== chrome.runtime.id || message?.channel !== 'golden-pet') return;
    if (message.action === 'ping') { respond({ok:true,mode,enabled:state.enabled}); return; }
    command(message.action).then(respond); return true;
  });
  chrome.storage.onChanged.addListener((changes,area) => { if (area === 'local' && changes.pet?.newValue) applyState(changes.pet.newValue); });
  function releaseDrag() {
    const previous = drag; drag = null;
    if (previous && dog.hasPointerCapture(previous.id)) dog.releasePointerCapture(previous.id);
  }
  dog.addEventListener('pointerdown', e => {
    if (e.button !== 0 || state.paused || slipLeft > 0 || placement || actionPending) return;
    closeMenu(); drag = {id:e.pointerId,startX:e.clientX,startY:e.clientY,x,y,moved:false}; dog.setPointerCapture(e.pointerId);
  });
  dog.addEventListener('pointermove', e => {
    if (!drag || drag.id !== e.pointerId) return;
    const dx=e.clientX-drag.startX,dy=e.clientY-drag.startY;
    if (!drag.moved && Math.abs(dx)+Math.abs(dy)>5) { drag.moved=true; epoch++; manualUntil=performance.now()+60000; cancelJob(); airborne=false; setMode('drag',10); }
    if (drag.moved) { x=bound(drag.x+dx); y=clamp(drag.y+dy,0,floor()); render(); }
  });
  function release(e,cancelled=false) {
    if (!drag || drag.id !== e.pointerId) return;
    const moved=drag.moved; releaseDrag();
    if (moved) { airborne=true;vy=0;setMode('drag',10);say('嘿咻，平稳落地！',2); }
    else if (!cancelled) {lastTouch=performance.now();command('pet');}
  }
  dog.addEventListener('pointerup',e=>release(e)); dog.addEventListener('pointercancel',e=>release(e,true)); dog.addEventListener('lostpointercapture',e=>release(e,true));
  dog.addEventListener('click',e=>{if(e.detail===0 && performance.now()-lastTouch>300)command('pet');});

  function addPeel(px) {
    const node=el('div','peel');node.style.backgroundImage=itemsImage;node.setAttribute('aria-hidden','true');
    const peel={x:px,node,armed:false};peels.push(peel);world.insertBefore(node,actor);positionProps();
  }
  function checkPeels(previousX) {
    if (airborne || !['walk','run'].includes(mode) || Math.abs(x-previousX)<.01) return;
    for (const peel of peels) {
      if (!peel.armed) { if (peel.x < x-8 || peel.x > x+width()+8) peel.armed=true; continue; }
      const lo=Math.min(previousX,x)+width()*.22,hi=Math.max(previousX,x)+width()*.75;
      if (peel.x>=lo-8 && peel.x<=hi+8) {
        peels=peels.filter(p=>p!==peel);hitPeel=peel;slipLeft=1.25;setMode('slip',1.25);say('哎呀，踩到香蕉皮了！',2.5);break;
      }
    }
  }
  async function finishFood(completed) {
    actionPending=true;const result=await request(completed.type,{key:completed.key,token:completed.token});actionPending=false;
    if(job!==completed || !state.enabled)return;
    const banana=completed.type==='banana',px=completed.foodX;
    cancelJob(false);if(banana && result.ok)addPeel(px);
    setMode('happy',3);say(result.message||'吃饱啦！',4);if(result.ok)hearts();
  }
  async function finishCatch(completed) {
    actionPending=true;const result=await request('play');actionPending=false;
    if(job!==completed || !state.enabled)return;
    cancelJob();setMode('happy',3);say(result.ok ? '啊呜！接住啦！' : result.message);if(result.ok)hearts();
  }
  function choose() {
    target=null;
    if (state.energy<22) {goHome(false);return;}
    const r=Math.random();facing=Math.random()<.5?-1:1;
    if(r<.46)setMode('walk',4+Math.random()*5);
    else if(r<.7)setMode('run',2+Math.random()*3);
    else if(r<.9)setMode('idle',3+Math.random()*4);
    else goHome(false);
  }
  async function checkRoutine(now) {
    if (!ready || routinePending || !state.enabled || state.paused || document.hidden) return;
    const due=routine(state);
    if(job?.type==='home' && job.scheduled && due.kind!=='sleep') {cancelJob();setMode('idle',2);say('早安，又是新的一天！');}
    if(now<manualUntil || job || placement || drag || airborne || slipLeft>0 || actionPending)return;
    if(due.kind==='sleep') {goHome(true);return;}
    if(due.kind==='meal') {
      routinePending=true;const token=crypto.randomUUID(),startedEpoch=epoch;
      const result=await request('claimMeal',{key:due.key,token});routinePending=false;
      if(!result.ok)return;
      if(epoch!==startedEpoch || job || !state.enabled || state.paused || document.hidden || placement) {request('releaseMeal',{token});return;}
      showFood('meal',homeFoodX(),{scheduled:true,key:due.key,token});
    }
  }
  function moveToward(destination,speed,dt) {
    const distance=destination-x;
    if(Math.abs(distance)>.5)facing=distance>0?1:-1;
    x=bound(x+Math.sign(distance)*Math.min(Math.abs(distance),speed*dt));
    return Math.abs(x-destination)<1;
  }
  function catchBall(previousBall,previousMouth,dt) {
    if (!ball || job?.type!=='play' || job.phase!=='chase')return;
    job.jumpCooldown=Math.max(0,job.jumpCooldown-dt);
    const m=mouth(),above=m.y-ball.y;
    const near=Math.abs(ball.x-m.x)<Math.max(110,170*scale());
    if(!airborne && job.jumpCooldown===0 && near && above>22*scale() && above<240*scale()) {
      const jumpHeight=clamp(above+30,65*scale(),190*scale());vy=-Math.sqrt(2*1200*jumpHeight);airborne=true;job.jumpCooldown=.65;setMode('jump',2);
    }
    const hit=airborne && sweptHit(previousBall,ball,previousMouth,m,ball.radius+19*scale());
    const scoop=!airborne && ball.grounded && Math.abs(ball.x-m.x)<42*scale();
    if(hit||scoop) {
      job.phase='caught';job.elapsed=0;ballNode.dataset.caught='true';
      if(!airborne)setMode('happy',1);
    }
  }
  function tick(now) {
    raf=0;const dt=last?Math.min((now-last)/1000,.05):0;last=now;
    if(!state.enabled || document.hidden || disposed){last=0;return;}
    if(!state.paused && !drag && menu.hidden && !placement && !actionPending) {
      elapsed+=dt;remaining-=dt;
      const oldX=x,oldMouth=mouth(),previousBall=ball?{...ball}:null;
      if(ball && job?.phase==='chase')ball=stepBall(ball,dt,ballBounds());
      if(slipLeft>0) {
        slipLeft=Math.max(0,slipLeft-dt);
        if(hitPeel && slipLeft<.85){hitPeel.node.remove();hitPeel=null;}
        if(slipLeft===0){setMode(job?.type==='play'?'run':target!==null?(job?.type==='banana'?'run':'walk'):'idle',4);}
      } else {
        if(airborne) {
          y+=vy*dt+600*dt*dt;vy+=1200*dt;
          if(y<0){y=0;vy=Math.max(0,vy);}
          if(y>=floor()){y=floor();airborne=false;setMode(job?.type==='play' && job.phase==='chase'?'run':job?.phase==='caught'?'happy':'idle',3);}
        }
        if(job?.type==='play') {
          if(job.phase==='chase' && ball) {
            const predicted=ball.x+ball.vx*.13;
            const direction=predicted>=x+width()/2?1:-1;
            const desired=bound(predicted-width()*(direction===1?.87:.13));
            moveToward(desired,330*scale(),dt);
            if(!airborne && mode!=='run')setMode('run',60);
            catchBall(previousBall,oldMouth,dt);
            job.elapsed+=dt;
            if(job.elapsed>50){cancelJob();setMode('idle',3);say('球玩累啦，再扔一次吧。');}
          } else if(job.phase==='caught') {
            const m=mouth();if(ball){ball.x=m.x;ball.y=m.y;ball.vx=0;ball.vy=0;}
            if(!airborne){job.elapsed+=dt;if(job.elapsed>.65){job.phase='saving';finishCatch(job);}}
          }
        } else if(!airborne && job) {
          if(job.phase==='approach') {
            if(job.type==='home')target=homeX();
            if(moveToward(target,(job.type==='banana'?260:115)*scale(),dt)) {
              job.phase='interact';job.elapsed=0;target=null;
              if(job.type==='home')setMode('sleep',job.scheduled?Infinity:30);
              else setMode('eat',3);
            }
          } else if(job.phase==='interact') {
            job.elapsed+=dt;
            if(job.type!=='home' && job.elapsed>=2.4){job.phase='saving';finishFood(job);}
            else if(job.type==='home' && !job.scheduled && job.elapsed>=30){cancelJob();setMode('idle',3);}
          }
        } else if(!airborne) {
          if(mode==='walk'||mode==='run') {
            x+=facing*(mode==='run'?175:48)*scale()*(reducedMotion.matches?.5:1)*dt;
            if(x<=0||x>=innerWidth-width()){x=bound(x);facing*=-1;}
          }
          if(remaining<=0)choose();
        }
        checkPeels(oldX);
        if(mode==='sleep') {sleepElapsed+=dt;if(sleepElapsed>=15){sleepElapsed=0;request('rest');}}
      }
    }
    if(now>=routineCheck){routineCheck=now+5000;checkRoutine(now);}
    if(!speech.hidden && now>speechUntil)speech.hidden=true;
    render();schedule();
  }
  function positionProps() {
    if(job && ['feed','banana','meal'].includes(job.type)) {
      const banana=job.type==='banana';prop.style.left=`${job.foodX-(banana?24:20)}px`;prop.style.top=`${ground()-(banana?48:24)}px`;
    }
    for(const peel of peels){peel.node.style.left=`${peel.x-24}px`;peel.node.style.top=`${ground()-48}px`;peel.node.dataset.armed=String(peel.armed);}
    if(ball){ballNode.style.left=`${ball.x-11}px`;ballNode.style.top=`${ball.y-11}px`;ballNode.style.transform=`rotate(${ball.x*1.5}deg)`;ballNode.dataset.bounces=String(ball.bounces);}
  }
  function positionUI() {
    speech.style.left=`${clamp(x+width()/2-110,8,Math.max(8,innerWidth-248))}px`;speech.style.top=`${Math.max(8,y-26)}px`;
    if(!menu.hidden){menu.style.left=`${clamp(x+width()/2-130,8,Math.max(8,innerWidth-268))}px`;menu.style.top=`${clamp(y-245,8,Math.max(8,innerHeight-250))}px`;}
  }
  function render() {
    actor.dataset.state=mode;actor.dataset.airborne=String(airborne);
    actor.style.transform=`translate3d(${x.toFixed(1)}px,${y.toFixed(1)}px,0) scale(${scale()})`;sprite.style.transform=`scaleX(${facing})`;
    const fps=mode==='run'?16:['walk','eat','jump'].includes(mode)?10:5;
    const next=state.paused?frame<0?0:frame:mode==='slip'?Math.min(7,Math.floor(elapsed*6.4)):reducedMotion.matches||!menu.hidden?0:Math.floor(elapsed*fps)%8;
    if(frame!==next||sprite.dataset.mode!==mode){frame=next;sprite.dataset.mode=mode;sprite.style.backgroundPosition=`${-frame*160}px ${-rows[mode]*128}px`;}
    kennel.style.transform=`scale(${scale()})`;kennel.dataset.activity=job?.type==='home'?job.phase==='interact'?'sleep':'return':job?.type==='meal'?'meal':'free';
    homeStatus.textContent=state.paused?'已暂停':job?.type==='home'&&job.phase==='interact'?'Z z z …':job?.type==='meal'?'开饭啦':state.scheduleEnabled?'按时吃饭，好好睡觉':'自在的小家';
    positionProps();positionUI();
  }
  function schedule(){if(!raf&&!disposed&&state.enabled&&!document.hidden)raf=requestAnimationFrame(tick);}
  function resize(){
    epoch++;cancelJob();clearPlacement();releaseDrag();airborne=false;x=bound(x);y=floor();
    if(hitPeel){hitPeel.node.remove();hitPeel=null;}slipLeft=0;setMode('idle',3);
    for(const peel of peels)peel.x=clamp(peel.x/previousWidth*innerWidth,24,Math.max(24,innerWidth-24));previousWidth=innerWidth;
    routineCheck=0;render();
  }
  window.addEventListener('resize',resize,{passive:true});
  document.addEventListener('visibilitychange',()=>{
    if(document.hidden){cancelAnimationFrame(raf);raf=0;last=0;clearPlacement();if(drag){releaseDrag();airborne=true;vy=0;}if(job?.scheduled){cancelJob();setMode('idle',3);}}
    else {routineCheck=0;request('get');schedule();}
  });
  const refresh=setInterval(()=>{if(state.enabled&&!document.hidden)request('get');},60000);
  window.addEventListener('pagehide',e=>{cancelAnimationFrame(raf);raf=0;last=0;if(!e.persisted){disposed=true;clearInterval(refresh);}});
  window.addEventListener('pageshow',()=>{routineCheck=0;schedule();});
  y=floor();request('get').then(()=>{ready=true;say(`汪！我是${state.name}，小窝也准备好啦。`,5);routineCheck=0;schedule();});
})();
