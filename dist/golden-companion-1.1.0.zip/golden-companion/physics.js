/* Deterministic viewport physics, shared by the live toy and trajectory preview. */
(() => {
  const clamp = (n, min, max) => Math.max(min, Math.min(max, n));
  function launch(start, end, direction = 1) {
    const dx = end.x - start.x, dy = end.y - start.y;
    const click = Math.hypot(dx, dy) < 12;
    return { x: start.x, y: start.y, vx: click ? direction * 420 : clamp(dx * 4, -1050, 1050),
      vy: click ? -580 : clamp(dy * 4, -1050, 1050), radius: 11, bounces: 0, grounded: false };
  }
  function stepBall(input, dt, bounds) {
    const b = { ...input }, r = b.radius;
    const right = Math.max(r, bounds.width - r), bottom = Math.max(r, bounds.height - r);
    const count = Math.max(1, Math.ceil(Math.min(dt, .1) / (1 / 120))), step = Math.min(dt, .1) / count;
    for (let i = 0; i < count; i++) {
      b.x += b.vx * step;
      if (!b.grounded) { b.y += b.vy * step + 450 * step * step; b.vy += 900 * step; }
      else b.vx *= Math.exp(-2.2 * step);
      if (b.x < r) { b.x = r; if (b.vx < 0) { b.vx *= -.82; b.bounces++; } }
      if (b.x > right) { b.x = right; if (b.vx > 0) { b.vx *= -.82; b.bounces++; } }
      if (b.y < r) { b.y = r; if (b.vy < 0) { b.vy *= -.8; b.bounces++; } }
      if (b.y >= bottom) {
        b.y = bottom;
        if (b.vy > 0) { b.bounces++; b.vy *= -.72; b.vx *= .87; }
        if (Math.abs(b.vy) < 75) { b.vy = 0; b.grounded = true; }
      }
    }
    return b;
  }
  function sweptHit(a0, a1, b0, b1, radius) {
    const x = a0.x - b0.x, y = a0.y - b0.y;
    const dx = a1.x - b1.x - x, dy = a1.y - b1.y - y;
    const length = dx * dx + dy * dy;
    const t = length ? clamp(-(x * dx + y * dy) / length, 0, 1) : 0;
    return Math.hypot(x + dx * t, y + dy * t) <= radius;
  }
  const api = { launch, stepBall, sweptHit };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else globalThis.GoldenPhysics = api;
})();
