(() => {
  const $ = id => document.getElementById(id);
  let state = GoldenCore.defaults(), activeId = null, pending = false, routineDirty = false, routineRevision = 0;
  const buttons = [...document.querySelectorAll('[data-action]')];
  function feedback(text, error = false) { $('feedback').textContent = text; $('feedback').classList.toggle('error', error); }
  async function send(action, payload) {
    try {
      const result = await chrome.runtime.sendMessage({ channel: 'golden-state', action, payload });
      if (result?.state) render(result.state);
      if (!result?.ok) feedback(result?.message || '保存失败，请重新打开面板。', true);
      return result;
    } catch { feedback('连接失败，请重新打开插件面板。', true); return { ok: false }; }
  }
  function render(next) {
    state = GoldenCore.normalize(next);
    $('pet-name').textContent = state.name;
    $('presence').textContent = !state.enabled ? '已休息' : state.paused ? '已暂停' : '正在陪伴';
    $('garden-state').textContent = !state.enabled ? '小花园暂时休息，下次见' : state.paused ? '安静等你，随时都在' : '正在摇尾巴，等你摸摸';
    document.body.classList.toggle('off', !state.enabled || state.paused);
    $('enabled').checked = state.enabled; $('paused').checked = state.paused;
    $('schedule-enabled').checked = state.scheduleEnabled;
    if (!routineDirty) {
      $('meal-one').value = state.mealTimes[0]; $('meal-two').value = state.mealTimes[1];
      $('sleep-start').value = state.sleepStart; $('wake-time').value = state.wakeTime;
    }
    $('routine-summary').textContent = state.scheduleEnabled ? `电脑本地时间 ${new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})} · 互动后一分钟恢复作息` : '自动作息已关闭，仍可点击狗窝回家。';
    if (document.activeElement !== $('name')) $('name').value = state.name;
    if (document.activeElement !== $('size')) $('size').value = state.size;
    $('size-value').value = `${state.size}%`;
    for (const key of ['hunger','mood','energy']) {
      const value = Math.round(state[key]); $(key + '-value').textContent = value;
      $(key + '-bar').setAttribute('aria-valuenow', value);
      $(key + '-bar').firstElementChild.style.width = `${value}%`;
    }
    $('hunger-note').textContent = state.hunger < 40 ? '想吃点香香的饭' : '刚刚好的满足';
    $('mood-note').textContent = state.mood < 40 ? '想要一个摸摸' : '尾巴摇个不停';
    $('energy-note').textContent = state.energy < 30 ? '睡一觉充充电' : '准备好去冒险';
    $('stats').textContent = `投喂 ${state.feeds} 次（香蕉 ${state.bananas}）· 摸摸 ${state.pets} · 接球 ${state.games}`;
  }
  async function act(action) {
    if (pending) return;
    if (!state.enabled || state.paused) { feedback(!state.enabled ? '打开“网页陪伴”，小金毛就会回来。' : '取消“暂停活动”，再和小金毛玩吧。', true); return; }
    pending = true; buttons.forEach(button => button.disabled = true);
    try {
      if (activeId === null) throw new Error('no-tab');
      const result = await chrome.tabs.sendMessage(activeId, { channel: 'golden-pet', action });
      feedback(result?.message || '小金毛收到啦！', !result?.ok);
      if (result?.ok && result.placement && location.protocol === 'chrome-extension:') window.close();
    } catch { feedback('当前页面无法显示桌宠。请打开普通网页并刷新后再试。', true); }
    finally { pending = false; buttons.forEach(button => button.disabled = false); }
  }
  buttons.forEach(button => button.addEventListener('click', () => act(button.dataset.action)));
  $('enabled').addEventListener('change', async e => {
    const enabled = e.target.checked;
    const result = await send('settings', { enabled });
    if (result?.ok) feedback(enabled ? '小金毛回来啦。已打开的旧网页可能需要刷新一次。' : '小金毛已回家休息，所有网页都会隐藏。');
  });
  $('paused').addEventListener('change', async e => {
    const paused = e.target.checked;
    const result = await send('settings', { paused });
    if (result?.ok) feedback(paused ? '已暂停，金毛会安静待在原地。' : '继续出发，去看看这个小世界。');
  });
  $('size').addEventListener('input', e => { $('size-value').value = `${e.target.value}%`; });
  $('size').addEventListener('change', e => send('settings', { size: Number(e.target.value) }));
  $('schedule-enabled').addEventListener('change', e => send('settings', { scheduleEnabled:e.target.checked }));
  for (const id of ['meal-one','meal-two','sleep-start','wake-time']) $(id).addEventListener('input', () => { routineDirty = true; routineRevision++; });
  $('save-routine').addEventListener('click', async () => {
    const mealTimes = [$('meal-one').value,$('meal-two').value], sleepStart = $('sleep-start').value, wakeTime = $('wake-time').value;
    if (![...mealTimes,sleepStart,wakeTime].every(GoldenCore.validTime)) { feedback('请填写完整的作息时间。',true); return; }
    if (mealTimes[0] === mealTimes[1] || sleepStart === wakeTime) { feedback('两餐时间需要不同，睡觉与起床时间也需要不同。',true); return; }
    const savedRevision = routineRevision;
    $('save-routine').disabled = true;
    const result = await send('settings', { mealTimes,sleepStart,wakeTime });
    $('save-routine').disabled = false;
    if (result?.ok && savedRevision === routineRevision) { routineDirty = false; render(result.state); feedback('作息已保存，会按电脑本地时间回家。'); }
    else if (result?.ok) feedback('此前的作息已保存，刚修改的时间还需要保存。');
  });
  async function saveName() {
    const name = [...$('name').value.trim()].slice(0, 12).join('');
    if (!name) { feedback('先给小金毛起个名字吧。', true); return; }
    const result = await send('settings', { name });
    if (result?.ok) { $('name').value = name; feedback(`从今天起，它就叫${name}啦。`); }
  }
  $('save-name').addEventListener('click', saveName);
  $('name').addEventListener('keydown', e => { if (e.key === 'Enter') saveName(); });
  document.querySelector('.brand').addEventListener('click', e => e.preventDefault());
  chrome.storage.onChanged.addListener((changes, area) => { if (area === 'local' && changes.pet?.newValue) render(changes.pet.newValue); });
  (async () => {
    await send('get');
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    activeId = tab?.id ?? null;
    try {
      if (activeId === null) throw new Error('no-tab');
      await chrome.tabs.sendMessage(activeId, { channel: 'golden-pet', action: 'ping' });
    } catch { feedback('在普通网页中使用；安装后请刷新已有网页。', true); }
  })();
})();
