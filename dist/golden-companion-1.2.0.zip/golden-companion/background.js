importScripts('core.js');
// Serialize all writes here, so different tabs never overwrite care actions.
let queue = Promise.resolve();
chrome.runtime.onMessage.addListener((request, sender, respond) => {
  if (sender.id !== chrome.runtime.id || request?.channel !== 'golden-state') return;
  queue = queue.catch(() => {}).then(async () => {
    if (request.action === 'sceneGet') {
      const { companionScene } = await chrome.storage.local.get('companionScene');
      respond({ ok:true, scene:GoldenCore.sanitizeScene(companionScene) }); return;
    }
    if (request.action === 'sceneSave') {
      const scene=GoldenCore.sanitizeScene(request.payload), {companionScene}=await chrome.storage.local.get('companionScene');
      if (scene && (!companionScene || scene.savedAt>=companionScene.savedAt)) await chrome.storage.local.set({companionScene:scene});
      respond({ ok:!!scene }); return;
    }
    const { pet } = await chrome.storage.local.get('pet');
    const result = GoldenCore.update(pet, request.action, request.payload);
    await chrome.storage.local.set({ pet: result.state });
    respond(result);
  }).catch(() => respond({ ok: false, message: '保存失败，请重新打开插件。' }));
  return true;
});
chrome.runtime.onInstalled.addListener(() => {
  queue = queue.catch(() => {}).then(async () => {
    const { pet } = await chrome.storage.local.get('pet');
    await chrome.storage.local.set({ pet: GoldenCore.normalize(pet) });
  });
});
