(() => {
  if (globalThis.__goldenCompanion) return;
  globalThis.__goldenCompanion = true;
  const { clamp, normalize, routine } = GoldenCore;
  const { launch, stepBall, sweptHit, approachVelocity, targetVelocity, toss, landingSurface, slipProfile, springStep } = GoldenPhysics;
  const el = (tag, cls, text) => {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text) node.textContent = text;
    return node;
  };
  const button = (cls, text, label) => {
    const node = el('button', cls, text); node.type = 'button';
    if (label) node.setAttribute('aria-label', label);
    return node;
  };
  const host = el('golden-companion'); host.id = 'golden-companion-root';
  const shadow = host.attachShadow({ mode: 'open' });
  const style = el('style'); style.textContent = GOLDEN_PET_STYLE;
  const world = el('div', 'world'), actor = el('div', 'actor');
  const petShadow=el('div','pet-shadow'), effectsCanvas=el('canvas','effects-canvas');
  petShadow.setAttribute('aria-hidden','true');effectsCanvas.setAttribute('aria-hidden','true');
  const dog = button('dog'); dog.title = '点击摸摸 · 拖拽移动 · 右键打开菜单';
  const sprite = el('span', 'sprite'); sprite.setAttribute('aria-hidden', 'true');
  sprite.style.backgroundImage = `url("${chrome.runtime.getURL('sprites.png')}")`;
  const trigger = button('menu-trigger', '···', '打开桌宠菜单'); trigger.setAttribute('aria-expanded', 'false');
  const speech = el('div', 'speech'); speech.hidden = true; speech.setAttribute('role', 'status'); speech.setAttribute('aria-live', 'polite');
  const prop = el('div'); prop.hidden = true; prop.setAttribute('aria-hidden', 'true');
  const ballNode = el('div', 'ball'); ballNode.hidden = true; ballNode.setAttribute('aria-hidden', 'true');
  const kennel = button('kennel', '', '让金毛回窝休息');
  kennel.style.backgroundImage = `url("${chrome.runtime.getURL('kennel.png')}")`;
  const homeLabel = el('span', 'home-label'), homeStatus = el('span', 'home-status'); kennel.append(homeLabel, homeStatus);
  const menu = el('div', 'menu'); menu.hidden = true; menu.setAttribute('role', 'dialog'); menu.setAttribute('aria-label', '金毛互动菜单');
  const head = el('div', 'menu-head'), name = el('strong', 'menu-name'), close = button('close', '×', '关闭菜单');
  head.append(name, close);
  const summary = el('p', 'summary'), actions = el('div', 'actions');
  for (const [action, label] of [['feed','喂狗粮'],['banana','放香蕉'],['play','抛小球'],['pet','摸摸头'],['walk','去散步'],['run','跑起来'],['sleep','回窝睡觉'],['belly','翻肚皮'],['hop','开心跳'],['sniff','闻一闻'],['stretch','伸懒腰'],['perch','跳上网页']]) {
    const node = button('action', label); node.dataset.action = action;
    node.addEventListener('click', () => { closeMenu(); command(action); }); actions.append(node);
  }
  menu.append(head, summary, actions, el('p', 'hint', '香蕉和小球可以选位置 · 点击狗窝回家'));
  const aim = el('div', 'aim-layer'); aim.hidden = true; aim.tabIndex = -1; aim.setAttribute('role', 'dialog'); aim.setAttribute('aria-label', '选择道具位置');
  const guide = el('canvas', 'aim-guide'), hud = el('div', 'aim-hud'), aimText = el('span');
  const cancelAim = button('aim-cancel', '取消 · Esc'); hud.append(aimText, cancelAim); aim.append(guide, hud);
  dog.append(sprite); actor.append(dog, trigger);
  world.append(kennel, petShadow, effectsCanvas, prop, actor, ballNode, speech, menu, aim); shadow.append(style, world); document.documentElement.append(host);
  world.style.opacity='0';

  let state = normalize(), ready = false, x = Math.max(0, innerWidth - 320), y = 0, facing = -1;
  let mode = 'idle', remaining = 4, elapsed = 0, frame = -1, last = 0, raf = 0, disposed = false;
  let job = null, target = null, drag = null, airborne = false, vy = 0, ball = null;
  let actionPending = false, speechUntil = 0, sleepElapsed = 0, lastTouch = 0;
  let placement = null, aimDrag = null, aimPoint = { x: innerWidth * .5, y: innerHeight * .4 };
  let peels = [], hitPeel = null, manualUntil = 0, routineCheck = 0, routinePending = false, epoch = 0;
  let previousWidth = innerWidth;
  let vx=0,desiredV=0,turnTo=0,windup=null,landingLeft=0,landingSpring={value:0,velocity:0};
  let support=null,ignoreSupport=null,ignoreUntil=0,slip=null,queuedAction=null;
  let wander={kind:'idle',left:4},freeBallUntil=0,footDistance=0,particles=[],saveDue=0,restoring=false;
  const platforms=new GoldenPlatforms(host);
  const durations={blink:.7,look:1.8,sniff:2.2,yawn:1.7,stretch:1.6,pet:1.4,belly:2.8,crouch:.18,launch:.15,bite:.25,land:.4,start:.32,brake:.3,turn:.4,stumble:.4,tumble:.65,dizzy:.65,recover:.7,circle:1.3,lie:.7,wake:.7,drop:.6};
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  const rows=Object.fromEntries(Object.entries(GOLDEN_ANIMATIONS).map(([key,value])=>[key,value.row]));
  const scale = () => Math.min(state.size / 100, innerWidth / 170, innerHeight / 150);
  const width = () => 160 * scale(), height = () => 128 * scale();
  const ground = () => innerHeight - 12;
  const floor = () => Math.max(0, ground() - 114 * scale());
  const bound = value => clamp(value, 0, Math.max(0, innerWidth - width()));
  const homeX = () => bound(innerWidth - 12 - 152 * scale());
  const homeFoodX = () => clamp(innerWidth - 12 - 162 * scale(), 24, Math.max(24, innerWidth - 24));
  const ballBounds = () => ({ width:innerWidth, height:ground() });
  const mouth = (px = x, py = y, direction = facing) => ({ x:px + width() * (direction === 1 ? .87 : .13), y:py + height() * (mode==='drop'?.72:mode==='bite'||mode==='jump'||mode==='launch'?.38:.47) });
  const itemsImage = `url("${chrome.runtime.getURL('items.png')}")`;

  async function request(action, payload) {
    try {
      const result = await chrome.runtime.sendMessage({ channel:'golden-state', action, payload });
      if (result?.state) applyState(result.state);
      return result || { ok:false, message:'连接中断，请刷新网页。' };
    } catch {
      say('插件已更新，请刷新网页后继续玩。', 8);
      return { ok:false, message:'请刷新网页后重试。' };
    }
  }
  function applyState(next) {
    const previous = state; state = normalize(next);
    host.hidden = !state.enabled; host.style.setProperty('display', state.enabled ? 'block' : 'none', 'important');
    dog.setAttribute('aria-label', `摸摸${state.name}`); name.textContent = `${state.name} · 小金毛`;
    homeLabel.textContent = `${state.name}的小窝`;
    kennel.title = `点击回窝休息 · 本地时间 ${state.mealTimes.join(' / ')} 吃饭，${state.sleepStart}–${state.wakeTime} 睡觉`;
    summary.textContent = `饱食 ${Math.round(state.hunger)} · 心情 ${Math.round(state.mood)} · 体力 ${Math.round(state.energy)}`;
    if (!state.enabled && previous.enabled) { saveScene();cancelJob();clearPlacement();closeMenu();releaseDrag();airborne=false;vx=0;windup=null;slip=null;if(hitPeel)hitPeel.node.remove();hitPeel=null;setMode('sit',3); }
    if (state.paused && !previous.paused) { clearPlacement(); closeMenu(); releaseDrag(); }
    if (state.size !== previous.size) { cancelJob();clearPlacement();airborne=false;support=null;vx=0;windup=null;setMode('idle',3); }
    platforms.enabled=state.platforms;
    if(!state.platforms&&support)leavePlatform();
    if(!state.effects)particles=[];
    if (JSON.stringify([state.scheduleEnabled,state.mealTimes,state.sleepStart,state.wakeTime]) !== JSON.stringify([previous.scheduleEnabled,previous.mealTimes,previous.sleepStart,previous.wakeTime])) {
      if (job?.scheduled) { cancelJob(); setMode('idle', 3); }
      routineCheck = 0; manualUntil = 0;
    }
    x = bound(x); if (!drag && !airborne) y = support?support.top-114*scale():floor();
    render(); schedule();
  }
  function say(text, seconds = 3) {
    speech.textContent = text; speechUntil = performance.now() + seconds * 1000; speech.hidden = false; positionUI();
  }
  function setMode(next, seconds = durations[next] || 4, force = false) {
    if(mode===next&&!force)return;
    mode = next; remaining = seconds; elapsed = 0; frame = -1; actor.dataset.state = mode;
    if (next !== 'sleep') sleepElapsed = 0;
  }
  function cancelJob(release = true, keepBall = false) {
    const previous = job; job = null; target = null; prop.hidden = true; prop.style.backgroundImage = '';
    if(!keepBall){ball=null;ballNode.hidden=true;freeBallUntil=0;}
    if(!airborne&&!slip&&!drag){turnTo=0;setMode('idle',.2);}
    if (release && previous?.type === 'meal') request('releaseMeal', { token:previous.token });
  }
  function closeMenu() { menu.hidden = true; trigger.setAttribute('aria-expanded', 'false'); }
  function openMenu() {
    if (!state.enabled || placement) return;
    menu.hidden = !menu.hidden; trigger.setAttribute('aria-expanded', String(!menu.hidden)); positionUI();
    if (!menu.hidden) close.focus({ preventScroll:true });
  }
  close.addEventListener('click', () => { closeMenu(); dog.focus({ preventScroll:true }); });
  trigger.addEventListener('click', openMenu);
  kennel.addEventListener('click', () => command('sleep'));
  dog.addEventListener('contextmenu', e => { e.preventDefault(); openMenu(); });
  function hearts() {
    if(!state.effects||reducedMotion.matches)return;
    for (let i = 0; i < 3; i++) {
      const heart = el('span', 'effect', '♥'); heart.style.left = `${x + width() * (.4 + i * .15)}px`; heart.style.top = `${y + height() * .18}px`;
      heart.style.animationDelay = `${i * .1}s`; world.append(heart); setTimeout(() => heart.remove(), 1700);
    }
  }
  function foodTarget(foodX) {
    const direction=foodX>=x+width()/2?1:-1;
    return bound(foodX-width()*(direction===1?.84:.16));
  }
  function showFood(type, foodX, details = {}) {
    target = foodTarget(foodX);
    job = { type, phase:'approach', elapsed:0, foodX, ...details };
    prop.className = type === 'banana' ? 'banana' : 'bowl';
    prop.style.backgroundImage = type === 'banana' ? itemsImage : '';
    prop.hidden = false; positionProps();leavePlatform();
    say(type === 'banana' ? '香蕉！我来啦！' : type === 'meal' ? '饭点到啦，回家吃饭！' : '闻到香香的饭啦！');
  }
  function goHome(scheduled = false) {
    job = { type:'home', phase:'approach', scheduled, elapsed:0 };
    target=homeX();leavePlatform();say(scheduled?'天晚了，回小窝睡觉啦。':'回家睡个暖暖的小觉。');
  }
  function clearPlacement() {
    placement = null; aimDrag = null; aim.hidden = true;
  }
  function beginPlacement(type) {
    placement = type; aim.hidden = false; aimDrag = null;
    aimPoint = { x:clamp(x + width() / 2,24,Math.max(24,innerWidth-24)), y:Math.max(30,innerHeight * .4) };
    aimText.textContent = type === 'banana' ? '点击网页选择地面位置，放一只香蕉 · 方向键移动 / Enter 放下' : '按住选起点，拖动决定方向与力度，松手抛球 · 单击 / Enter 轻抛';
    aim.focus({ preventScroll:true }); drawAim();
  }
  function startBall(start, end) {
    clearPlacement(); cancelJob();
    const direction = start.x < innerWidth / 2 ? 1 : -1;
    ball = launch({ x:clamp(start.x,12,innerWidth-12), y:clamp(start.y,12,Math.max(12,ground()-12)) },end,direction);
    ballNode.hidden = false; ballNode.dataset.caught = 'false';
    job = { type:'play',phase:'chase',elapsed:0,jumpCooldown:0,returnX:bound(start.x-width()/2) };leavePlatform();say('看我的飞扑接球！');
  }
  function commitBanana(px) {
    clearPlacement(); showFood('banana', clamp(px,24,Math.max(24,innerWidth-24)));
  }
  function drawAim() {
    if (!placement) return;
    guide.width = innerWidth; guide.height = innerHeight;
    const ctx = guide.getContext('2d'); if (!ctx) return;
    ctx.clearRect(0,0,guide.width,guide.height);
    if (placement === 'banana') {
      ctx.fillStyle = '#dec06d'; ctx.fillRect(aimPoint.x-20,ground()-4,40,4);
      ctx.strokeStyle = '#a89464'; ctx.setLineDash([4,7]); ctx.beginPath(); ctx.moveTo(aimPoint.x,ground()-70); ctx.lineTo(aimPoint.x,ground()-12); ctx.stroke();
      return;
    }
    const start = aimDrag?.start || aimPoint, end = aimDrag?.end || start;
    let preview = launch(start,end,start.x < innerWidth/2 ? 1 : -1);
    ctx.fillStyle = '#d18f5d'; ctx.fillRect(start.x-7,start.y-7,14,14);
    for (let i=0; i<28; i++) {
      preview = stepBall(preview,.035,ballBounds()); ctx.fillStyle = `rgba(116,137,86,${.65-i*.016})`; ctx.fillRect(preview.x-2,preview.y-2,4,4);
    }
  }
  cancelAim.addEventListener('click', () => { clearPlacement(); say('取消啦，继续陪你。'); });
  aim.addEventListener('pointerdown', e => {
    if (e.button !== 0 || e.target.closest('button') || e.target.closest('.aim-hud')) return;
    e.preventDefault(); e.stopPropagation();
    aimPoint = { x:e.clientX,y:e.clientY };
    aimDrag = { id:e.pointerId,start:{...aimPoint},end:{...aimPoint} }; aim.setPointerCapture(e.pointerId); drawAim();
  });
  aim.addEventListener('pointermove', e => {
    aimPoint = { x:e.clientX,y:e.clientY };
    if (aimDrag) aimDrag.end = {...aimPoint}; drawAim();
  });
  aim.addEventListener('pointerup', e => {
    if (!aimDrag || aimDrag.id !== e.pointerId) return;
    e.preventDefault(); e.stopPropagation(); const gesture = aimDrag, kind = placement;
    aimDrag = null; if (aim.hasPointerCapture(e.pointerId)) aim.releasePointerCapture(e.pointerId);
    if (kind === 'banana') commitBanana(e.clientX);
    else if (kind === 'play') startBall(gesture.start,{x:e.clientX,y:e.clientY});
  });
  aim.addEventListener('pointercancel', () => { aimDrag = null; drawAim(); });
  aim.addEventListener('lostpointercapture', () => { if (aimDrag) { aimDrag = null; drawAim(); } });
  document.addEventListener('keydown', e => {
    if (placement) {
      if (['Escape','Enter','ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)) { e.preventDefault(); e.stopPropagation(); }
      if (e.key === 'Escape') clearPlacement();
      if (e.key === 'Enter') { if (placement === 'banana') commitBanana(aimPoint.x); else startBall(aimPoint,aimPoint); }
      if (e.key.startsWith('Arrow')) {
        aimPoint.x = clamp(aimPoint.x + (e.key === 'ArrowLeft' ? -24 : e.key === 'ArrowRight' ? 24 : 0),12,Math.max(12,innerWidth-12));
        aimPoint.y = clamp(aimPoint.y + (e.key === 'ArrowUp' ? -24 : e.key === 'ArrowDown' ? 24 : 0),12,Math.max(12,ground()-12)); drawAim();
      }
    } else if (e.key === 'Escape' && !menu.hidden) { closeMenu(); dog.focus({preventScroll:true}); }
  },true);

  const poseSequences={
    blink:[['blink',.7]],look:[['look',1.8]],sniff:[['sniff',2.2]],yawn:[['yawn',1.7]],stretch:[['stretch',1.6]],
    pet:[['pet',1.4],['happy',.7]],belly:[['lie',.6],['tumble',.6],['belly',2.8],['recover',.7]],
    sit:[['sit',4],['recover',.6]],turn:[['turn',.4]],happy:[['happy',1.5]]
  };
  function startPose(kind) {
    job={type:'pose',kind,phase:'settle',index:0,elapsed:0};target=null;
  }
  function leavePlatform() {
    if(!support)return;
    ignoreSupport=support.element;ignoreUntil=performance.now()+700;support=null;airborne=true;vy=35;
    setMode('jump');
  }
  function beginJump(jumpHeight,horizontal=null,kind='toy') {
    if(airborne||windup||turnTo||landingLeft>0)return false;
    windup={left:.18,vy:-Math.sqrt(2*1200*jumpHeight),horizontal,kind};setMode('crouch',.18,true);return true;
  }
  function startPerch() {
    if(!state.platforms)return {ok:false,message:'先在专属设置中打开“网页元素停靠”。'};
    platforms.update(performance.now());
    const p=platforms.reachable(x+width()/2,y+114*scale(),scale());
    if(!p)return {ok:false,message:'附近没有够得着的按钮、文字或图片，换个位置试试。'};
    const destination=bound((p.left+p.right)/2-width()/2),rise=y+114*scale()-p.top;
    const jumpHeight=Math.min(225*scale(),rise+32*scale());
    const launchVy=-Math.sqrt(2*1200*jumpHeight);
    const seconds=(-launchVy+Math.sqrt(Math.max(0,launchVy*launchVy-2400*rise)))/1200;
    job={type:'perch',phase:'settle',platform:p,destination,jumpHeight,jumpVX:(destination-x)/Math.max(.3,seconds)};
    return {ok:true,message:'我试着跳上去，看看风景。'};
  }
  async function command(action) {
    const known=['feed','banana','pet','play','walk','run','sleep','hop','perch',...Object.keys(poseSequences)];
    if(!known.includes(action))return {ok:false,message:'未知动作'};
    if(!state.enabled)return {ok:false,message:'请先打开“网页陪伴”。'};
    if(state.paused)return {ok:false,message:'请先取消“暂停活动”。'};
    if(actionPending||drag||slip)return {ok:false,message:'等我站稳，再陪你玩～'};
    if(job?.type==='home'&&['lie','sleep','wake','stretch','exit'].includes(job.phase)&&action!=='sleep') {
      queuedAction=action;epoch++;manualUntil=performance.now()+60000;
      if(!['wake','stretch','exit'].includes(job.phase))wakeHome();
      return {ok:true,message:'醒来伸个懒腰，就来陪你。'};
    }
    if(job&&['feed','banana','meal'].includes(job.type))return {ok:false,message:'先等我把这口饭吃完吧。'};
    if(job?.type==='play'&&!['play','sleep','pet'].includes(action))return {ok:false,message:'等我把球叼回来，再来玩这个。'};
    if(['feed','banana'].includes(action)&&Date.now()-state.lastFeed<8000)return {ok:false,message:'刚吃过啦，等一小会儿再喂～'};
    if(action==='banana'&&peels.length>=6)return {ok:false,message:'先让金毛清理一下地上的香蕉皮吧。'};
    if(action==='play'&&(Date.now()-state.lastPlay<5000||state.energy<12))return {ok:false,message:'先让我休息一下，再来接球。'};
    if(action==='perch'&&!state.platforms)return {ok:false,message:'先在专属设置中打开“网页元素停靠”。'};
    epoch++;manualUntil=performance.now()+60000;closeMenu();clearPlacement();cancelJob();queuedAction=null;
    if(action==='banana'||action==='play') {
      beginPlacement(action);return {ok:true,placement:true,message:action==='banana'?'在网页选择香蕉落地的位置。':'按住选择起点，拖动后松手抛球。'};
    }
    if(action==='feed') {
      const dest=bound(x+(x<(innerWidth-width())/2?240:-240));
      showFood('feed',clamp(dest+width()*(dest>=x?.84:.16),24,innerWidth-24));
    } else if(action==='pet') {
      actionPending=true;const response=await request('pet');actionPending=false;
      if(!state.enabled||state.paused)return response;
      startPose('pet');hearts();say(response.message);return response;
    } else if(action==='sleep')goHome(false);
    else if(action==='perch')return startPerch();
    else if(action==='hop'){job={type:'hop',phase:'settle'};say('开心到跳起来！');}
    else if(action==='walk'||action==='run') {
      wander={kind:action,left:9};target=null;
      // Changing a direction is handled by braking and a turn, never an instant mirror.
      wander.direction=x>(innerWidth-width())/2?-1:1;say(action==='run'?'小爪子，出发！':'慢慢逛一圈。');
    } else {startPose(action);say({belly:'肚皮给你摸摸～',sniff:'这里有什么香香的？',yawn:'哈——有一点点困。',stretch:'伸个大懒腰！',look:'让我看看周围。',sit:'乖乖坐好。',blink:'眨眨眼，看到你啦。',turn:'转个身，继续走。'}[action]||'好开心！');}
    schedule();return {ok:true,message:'收到啦，看看网页里的小金毛。'};
  }
  chrome.runtime.onMessage.addListener((message,sender,respond)=>{
    if(sender.id!==chrome.runtime.id||message?.channel!=='golden-pet')return;
    if(message.action==='ping'){respond({ok:true,mode,enabled:state.enabled});return;}
    command(message.action).then(respond);return true;
  });
  chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.pet?.newValue)applyState(changes.pet.newValue);});
  function releaseDrag() {
    const old=drag;drag=null;if(old&&dog.hasPointerCapture(old.id))dog.releasePointerCapture(old.id);
  }
  dog.addEventListener('pointerdown',e=>{
    if(e.button!==0||state.paused||slip||placement||actionPending)return;
    closeMenu();drag={id:e.pointerId,startX:e.clientX,startY:e.clientY,x,y,moved:false,samples:[]};dog.setPointerCapture(e.pointerId);
  });
  dog.addEventListener('pointermove',e=>{
    if(!drag||drag.id!==e.pointerId)return;
    const dx=e.clientX-drag.startX,dy=e.clientY-drag.startY,now=performance.now();
    if(!drag.moved&&Math.abs(dx)+Math.abs(dy)>5) {
      drag.moved=true;epoch++;manualUntil=now+60000;cancelJob();airborne=false;support=null;windup=null;vx=0;turnTo=0;setMode('drag',10,true);
    }
    if(drag.moved) {
      x=bound(drag.x+dx);y=clamp(drag.y+dy,0,floor());
      drag.samples.push({x,y,t:now});drag.samples=drag.samples.filter(s=>now-s.t<160);render();
    }
  });
  function release(e,cancelled=false) {
    if(!drag||drag.id!==e.pointerId)return;
    const moved=drag.moved,impulse=toss(drag.samples,performance.now(),scale());releaseDrag();
    if(moved) {
      airborne=true;vx=cancelled?0:impulse.vx;vy=cancelled?0:impulse.vy;
      if(Math.abs(vx)>10)facing=Math.sign(vx);setMode('jump');say(Math.abs(vx)>100?'飞一下，再稳稳落地！':'轻轻放下，稳稳站好。',2);saveScene();
    } else if(!cancelled){lastTouch=performance.now();command('pet');}
  }
  dog.addEventListener('pointerup',e=>release(e));dog.addEventListener('pointercancel',e=>release(e,true));dog.addEventListener('lostpointercapture',e=>release(e,true));
  dog.addEventListener('click',e=>{if(e.detail===0&&performance.now()-lastTouch>300)command('pet');});

  function addPeel(px) {
    const node=el('div','peel');node.style.backgroundImage=itemsImage;node.setAttribute('aria-hidden','true');
    peels.push({x:px,node,armed:false});world.insertBefore(node,actor);positionProps();
  }
  function checkPeels(previousX) {
    if(airborne||support||windup||slip||Math.abs(vx)<8)return;
    for(const peel of peels) {
      if(!peel.armed){if(peel.x<x-8||peel.x>x+width()+8)peel.armed=true;continue;}
      if(peel.x>=Math.min(previousX,x)+width()*.22-8&&peel.x<=Math.max(previousX,x)+width()*.75+8) {
        peels=peels.filter(p=>p!==peel);hitPeel=peel;
        const profile=slipProfile(vx,scale());slip={...profile,phase:'slip',elapsed:0};vx=profile.slideVelocity;
        turnTo=0;setMode('slip',.28,true);say(profile.tumble?'哎呀，跑太快滑倒了！':'哎哟，脚底滑了一下。',3);break;
      }
    }
  }
  function stepSlip(dt) {
    slip.elapsed+=dt;x=bound(x+vx*dt);vx*=Math.exp(-2.6*dt);
    if(x<=0||x>=innerWidth-width())vx=0;
    if(hitPeel&&slip.elapsed>.2){hitPeel.node.remove();hitPeel=null;}
    const length=slip.phase==='slip'?.28:slip.phase==='tumble'?.65:slip.phase==='stumble'?.4:slip.phase==='dizzy'?slip.dizzy:.7;
    if(slip.elapsed>=length) {
      const next=slip.phase==='slip'?(slip.tumble?'tumble':'stumble'):['tumble','stumble'].includes(slip.phase)?'dizzy':slip.phase==='dizzy'?'recover':null;
      if(next){slip.phase=next;slip.elapsed=0;setMode(next,next==='dizzy'?slip.dizzy:durations[next],true);}
      else {slip=null;vx=0;setMode('idle',2);}
    }
  }
  function spawnDust(amount=5) {
    if(!state.effects||reducedMotion.matches)return;
    for(let i=0;i<amount;i++)particles.push({kind:'dust',x:x+width()*(.2+Math.random()*.5),y:y+114*scale(),vx:(Math.random()-.5)*65,vy:-15-Math.random()*25,life:.55,max:.55,size:2+Math.random()*3});
    particles=particles.slice(-56);
  }
  function footstep(distance) {
    if(!state.effects||reducedMotion.matches||airborne||support||slip||Math.abs(vx)<25)return;
    footDistance+=Math.abs(distance);
    if(footDistance>30*scale()) {
      footDistance=0;particles.push({kind:'paw',x:x+width()*.4,y:ground()-2,vx:0,vy:0,life:2,max:2,size:3,flip:Math.random()>.5});
      if(Math.abs(vx)>140*scale())spawnDust(1);particles=particles.slice(-56);
    }
  }
  function stepParticles(dt) {
    for(const p of particles){p.life-=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;if(p.kind==='dust')p.vy+=25*dt;}
    particles=particles.filter(p=>p.life>0);
  }
  function paintEffects() {
    if(effectsCanvas.width!==innerWidth||effectsCanvas.height!==innerHeight){effectsCanvas.width=innerWidth;effectsCanvas.height=innerHeight;}
    const ctx=effectsCanvas.getContext('2d');if(!ctx)return;ctx.clearRect(0,0,innerWidth,innerHeight);
    if(!state.effects)return;
    for(const p of particles) {
      ctx.globalAlpha=Math.max(0,p.life/p.max)*(p.kind==='paw'?.22:.45);ctx.fillStyle=p.kind==='paw'?'#8f7a54':'#c7b58a';
      if(p.kind==='paw'){ctx.fillRect(p.x,p.y-3,5,3);ctx.fillRect(p.x-1,p.y-6,2,2);ctx.fillRect(p.x+2,p.y-7,2,2);ctx.fillRect(p.x+5,p.y-5,2,2);}
      else ctx.fillRect(Math.round(p.x),Math.round(p.y),p.size,p.size);
    }
    ctx.globalAlpha=1;
  }
  function arrived(destination) {return Math.abs(x-destination)<2&&Math.abs(vx)<12&&!airborne&&!windup&&landingLeft<=0&&!turnTo;}
  function driveTo(destination,speed,finalFacing=null) {
    target=destination;
    const atPosition=Math.abs(destination-x)<2;
    desiredV=atPosition?0:targetVelocity(destination-x,speed,850*scale());
    // A toy can be beneath the body: reaching its x coordinate is not enough.
    // Stop and turn so the mouth actually faces it before eating or picking up.
    if(atPosition&&Math.abs(vx)<12&&!airborne&&!windup&&landingLeft<=0&&finalFacing&&facing!==finalFacing&&!turnTo){turnTo=finalFacing;setMode('turn',.4,true);}
    return arrived(destination)&&(!finalFacing||facing===finalFacing);
  }
  function integrateHorizontal(dt) {
    if(windup){vx=approachVelocity(vx,0,900*scale(),dt);x=bound(x+vx*dt);return;}
    const movingKind=job?.type==='play'?'run':job?.type==='banana'?'run':job?'walk':wander.kind;
    const locomotion=['idle','start','walk','run','brake','turn','carry'].includes(mode)&&!(job?.type==='pose'&&job.phase==='animate');
    if(locomotion&&!airborne&&!landingLeft&&Math.abs(desiredV)>2&&Math.sign(desiredV)!==facing) {
      if(Math.abs(vx)>9){desiredV=0;setMode('brake');}
      else {
        if(!turnTo){turnTo=Math.sign(desiredV);setMode('turn',.4,true);}
        desiredV=0;
      }
    }
    if(turnTo) {
      desiredV=0;if(elapsed>=.2)facing=turnTo;
      if(elapsed>=.4){turnTo=0;setMode('idle',.2);}
    }
    const old=vx;vx=approachVelocity(vx,desiredV,(airborne?430:Math.abs(desiredV)<Math.abs(vx)?1000:700)*scale(),dt);
    let next=x+(old+vx)*.5*dt;
    if(target!==null&&!airborne&&(target-x)*(target-next)<0&&Math.abs(target-x)<10*scale()){next=target;vx=0;}
    x=bound(next);
    if(x!==next){vx=0;if(!job){wander.direction=x<=0?1:-1;}}
    if(airborne||windup||landingLeft>0||turnTo||!locomotion)return;
    if(Math.abs(vx)<4&&Math.abs(desiredV)<4){if(mode==='brake'&&elapsed<.2)return;setMode('idle',3);}
    else if(job?.type==='play'&&job.phase==='return')setMode('carry',60);
    else if(Math.abs(desiredV)<Math.abs(old)-8){setMode('brake');}
    else if(Math.abs(old)<8&&Math.abs(desiredV)>10){setMode('start',.32,true);}
    else if(mode==='start'&&elapsed<.32)return;
    else setMode(Math.abs(vx)>120*scale()||movingKind==='run'?'run':'walk',60);
  }
  function updateSupport(now) {
    platforms.update(now);
    if(!support)return;
    const current=platforms.get(support.element);
    if(!current){support=null;airborne=true;vy=0;setMode('jump');return;}
    const dx=current.left-support.left;
    x=bound(x+dx);support=current;y=Math.max(0,current.top-114*scale());
    const foot=x+width()*.5;
    if(foot<current.left-5||foot>current.right+5){ignoreSupport=current.element;ignoreUntil=now+350;support=null;airborne=true;vy=0;setMode('jump');}
  }
  function integrateVertical(dt,now) {
    if(windup) {
      windup.left-=dt;
      if(windup.left<=0) {
        const jump=windup;windup=null;airborne=true;vy=jump.vy;
        if(jump.horizontal!==null){vx=clamp(jump.horizontal,-420*scale(),420*scale());if(Math.abs(vx)>10)facing=Math.sign(vx);}
        if(support){ignoreSupport=support.element;ignoreUntil=now+500;}support=null;setMode('launch',.15,true);spawnDust(3);
      }
    }
    if(!airborne)return;
    const before=y+114*scale();y+=vy*dt+600*dt*dt;vy+=1200*dt;
    if(y<0){y=0;vy=Math.max(0,vy);}
    let surface=null;
    if(state.platforms&&vy>=0)surface=landingSurface(before,y+114*scale(),x+width()/2,platforms.items.filter(p=>p.top>114*scale()+4&&(p.element!==ignoreSupport||now>ignoreUntil)),12*scale());
    if(surface||y>=floor()) {
      const impact=vy;support=surface;y=surface?surface.top-114*scale():floor();airborne=false;vy=0;landingLeft=.42;
      landingSpring={value:clamp(impact/850,.25,1),velocity:0};setMode('land',.42,true);spawnDust(impact>500?7:4);saveScene();
    } else if(mode==='launch'&&elapsed>.15)setMode('jump');
    else if(mode==='bite'&&elapsed>.25)setMode('jump');
  }
  function stepPose(dt) {
    if(job.phase==='settle') {
      desiredV=0;
      if(Math.abs(vx)<5&&!turnTo&&!airborne&&landingLeft<=0) {
        job.phase='animate';job.elapsed=0;setMode(poseSequences[job.kind][0][0],poseSequences[job.kind][0][1],true);
      }
    } else {
      const clip=poseSequences[job.kind][job.index];job.elapsed+=dt;
      if(job.kind==='turn'&&job.elapsed>clip[1]/2&&!job.turned){facing*=-1;job.turned=true;}
      if(job.elapsed>=clip[1]) {
        job.index++;job.elapsed=0;
        if(job.index>=poseSequences[job.kind].length){job=null;wander={kind:'idle',left:2};setMode('idle',2);saveScene();}
        else {const next=poseSequences[job.kind][job.index];setMode(next[0],next[1],true);}
      }
    }
  }
  function wakeHome() {
    if(job?.type!=='home')return;
    job.phase='wake';job.elapsed=0;job.scheduled=false;setMode('wake',.7,true);say('醒来啦，先伸个大懒腰。');
  }
  function stepHome(dt) {
    if(job.phase==='approach') {
      if(driveTo(homeX(),115*scale())){job.phase='circle';job.elapsed=0;setMode('circle',1.3,true);}
    } else if(job.phase==='circle') {
      job.elapsed+=dt;
      desiredV=clamp((bound(homeX()+Math.sin(job.elapsed/1.3*Math.PI*2)*9*scale())-x)*8,-45*scale(),45*scale());
      if(job.elapsed>=1.3){job.phase='lie';job.elapsed=0;vx=0;x=homeX();setMode('lie',.7,true);}
    } else if(job.phase==='lie') {
      job.elapsed+=dt;if(job.elapsed>=.7){job.phase='sleep';job.elapsed=0;setMode('sleep',30,true);saveScene();}
    } else if(job.phase==='sleep') {
      job.elapsed+=dt;sleepElapsed+=dt;
      if(sleepElapsed>=15){sleepElapsed=0;request('rest');}
      if(!job.scheduled&&job.elapsed>=30)wakeHome();
    } else if(job.phase==='wake') {
      job.elapsed+=dt;if(job.elapsed>=.7){job.phase='stretch';job.elapsed=0;setMode('stretch',1.6,true);}
    } else if(job.phase==='stretch') {
      job.elapsed+=dt;if(job.elapsed>=1.6){job.phase='exit';job.elapsed=0;setMode('idle',.2);}
    } else if(job.phase==='exit') {
      if(driveTo(bound(homeX()-95*scale()),85*scale())) {
        job=null;target=null;wander={kind:'idle',left:2};setMode('idle',2);saveScene();
        const next=queuedAction;queuedAction=null;if(next)command(next);
      }
    }
  }
  async function finishFood(completed) {
    actionPending=true;const response=await request(completed.type,{key:completed.key,token:completed.token});actionPending=false;
    if(job!==completed||!state.enabled)return;
    const banana=completed.type==='banana',px=completed.foodX;cancelJob(false);
    if(banana&&response.ok)addPeel(px);
    startPose('happy');say(response.message||'吃饱啦！',4);if(response.ok)hearts();saveScene();
  }
  async function finishReturn(completed) {
    actionPending=true;const response=await request('play');actionPending=false;
    if(job!==completed||!state.enabled)return;
    cancelJob(true,true);freeBallUntil=performance.now()+12000;startPose('happy');
    say(response.ok?'球叼回来啦，放在你脚边！':response.message,4);if(response.ok)hearts();saveScene();
  }
  function planBall(dt) {
    job.jumpCooldown=Math.max(0,job.jumpCooldown-dt);
    if(job.phase==='chase'&&ball) {
      const predicted=stepBall(ball,.1,ballBounds());
      const direction=predicted.x>=x+width()/2?1:-1;
      driveTo(bound(predicted.x-width()*(direction===1?.87:.13)),330*scale(),direction);
      const m=mouth(),above=m.y-ball.y;
      if(!airborne&&!windup&&landingLeft<=0&&job.jumpCooldown===0&&Math.abs(ball.x-m.x)<155*scale()&&above>22*scale()&&above<220*scale()) {
        if(beginJump(clamp(above+38,65*scale(),205*scale())))job.jumpCooldown=.9;
      }
      job.elapsed+=dt;
      if(job.elapsed>55){cancelJob();wander={kind:'idle',left:3};say('让我喘口气，再抛一次吧。');}
    } else if(job.phase==='pickup') {
      desiredV=0;job.elapsed+=dt;
      if(job.elapsed>=.55){job.phase='caught';job.elapsed=0;setMode('bite',.25,true);}
    } else if(job.phase==='caught') {
      job.elapsed+=dt;
      desiredV=0;
      if(job.elapsed>=.25&&!airborne&&landingLeft<=0){job.phase='return';setMode('idle',.2);say('接住啦！叼回来给你。');}
    } else if(job.phase==='return') {
      if(driveTo(job.returnX,125*scale())){job.phase='drop';job.elapsed=0;job.released=false;setMode('drop',.6,true);}
    } else if(job.phase==='drop') {
      job.elapsed+=dt;
      if(job.elapsed>.36&&!job.released){job.released=true;if(ball){ball.vx=facing*24;ball.vy=40;ball.grounded=false;ball.spin=0;}}
      if(job.elapsed>1.1&&ball?.grounded){job.phase='saving';finishReturn(job);}
    }
  }
  function afterBall(previousBall,previousMouth) {
    if(!ball||job?.type!=='play')return;
    if(job.phase==='chase') {
      const m=mouth();
      const hit=airborne&&sweptHit(previousBall,ball,previousMouth,m,ball.radius+19*scale());
      const scoop=!airborne&&!turnTo&&!windup&&landingLeft<=0&&ball.grounded&&Math.abs(ball.x-m.x)<37*scale();
      if(hit||scoop){job.phase=hit?'caught':'pickup';job.elapsed=0;ballNode.dataset.caught='true';setMode(hit?'bite':'drop',hit?.25:.55,true);}
    }
    if(['caught','return'].includes(job.phase)||(job.phase==='pickup'&&job.elapsed>.2)||(job.phase==='drop'&&!job.released)) {
      const m=mouth();ball.x=m.x;ball.y=m.y;ball.vx=0;ball.vy=0;ball.spin=0;
    }
  }
  function choose() {
    target=null;
    if(state.energy<22){goHome(false);return;}
    const r=Math.random();
    if(state.platforms&&r<.10&&platforms.reachable(x+width()/2,y+114*scale(),scale())){startPerch();return;}
    if(r<.44)wander={kind:'walk',left:4+Math.random()*5,direction:Math.random()<.5?-1:1};
    else if(r<.64)wander={kind:'run',left:2+Math.random()*3,direction:Math.random()<.5?-1:1};
    else if(r<.94){const names=['blink','look','sniff','yawn','stretch','sit'];startPose(names[Math.floor(Math.random()*names.length)]);}
    else goHome(false);
  }
  async function checkRoutine(now) {
    if(!ready||routinePending||!state.enabled||state.paused||document.hidden)return;
    const due=routine(state);
    if(job?.type==='home'&&job.scheduled&&due.kind!=='sleep')wakeHome();
    if(now<manualUntil||job||placement||drag||airborne||windup||slip||actionPending)return;
    if(due.kind==='sleep'){goHome(true);return;}
    if(due.kind==='meal') {
      routinePending=true;const token=crypto.randomUUID(),started=epoch;const response=await request('claimMeal',{key:due.key,token});routinePending=false;
      if(!response.ok)return;
      if(epoch!==started||job||!state.enabled||state.paused||document.hidden||placement){request('releaseMeal',{token});return;}
      showFood('meal',homeFoodX(),{scheduled:true,key:due.key,token});
    }
  }
  function stepIntent(dt) {
    desiredV=0;target=null;
    if(job?.type==='pose'){stepPose(dt);return;}
    if(job?.type==='home'){stepHome(dt);return;}
    if(job?.type==='play'){planBall(dt);return;}
    if(job?.type==='hop') {
      if(job.phase==='settle'&&Math.abs(vx)<5&&!airborne&&landingLeft<=0){job.phase='flight';beginJump(85*scale(),0,'happy');}
      else if(job.phase==='flight'&&!airborne&&!windup&&landingLeft<=0){job=null;startPose('happy');hearts();}
      return;
    }
    if(job?.type==='perch') {
      if(job.phase==='settle'&&Math.abs(vx)<5&&!airborne&&landingLeft<=0){job.phase='flight';beginJump(job.jumpHeight,job.jumpVX,'platform');}
      if(job.phase==='flight') {
        if(airborne)desiredV=job.jumpVX;
        else if(!windup&&landingLeft<=0){job=null;startPose('look');saveScene();}
      }
      return;
    }
    if(job) {
      if(job.phase==='approach'&&!airborne&&!windup&&landingLeft<=0) {
        const destination=foodTarget(job.foodX);
        if(driveTo(destination,(job.type==='banana'?260:115)*scale(),job.foodX>=x+width()/2?1:-1)){job.phase='interact';job.elapsed=0;setMode('eat',2.4,true);}
      } else if(job.phase==='interact') {
        job.elapsed+=dt;if(job.elapsed>=2.4){job.phase='saving';finishFood(job);}
      }
      return;
    }
    if(airborne){desiredV=vx;return;}
    wander.left-=dt;
    if(wander.kind==='walk'||wander.kind==='run')desiredV=(wander.direction||facing)*(wander.kind==='run'?180:50)*scale()*(reducedMotion.matches?.6:1);
    if(wander.left<=0)choose();
  }
  function tick(now) {
    raf=0;const delta=last?Math.min((now-last)/1000,.25):0;last=now;
    if(!state.enabled||document.hidden||disposed){last=0;return;}
    if(!ready){render();schedule();return;}
    if(!state.paused&&menu.hidden&&!placement&&!actionPending) {
      if(!drag)updateSupport(now);
      // Keep motion and animation time together on a busy page. Small steps keep
      // collisions stable, while a bounded catch-up avoids a long main-thread task.
      let budget=delta;
      while(budget>1e-6&&!actionPending) {
        const dt=Math.min(budget,1/60);budget-=dt;
        elapsed+=dt;remaining=Math.max(0,remaining-dt);
        if(!drag) {
          const oldX=x,oldMouth=mouth(),oldBall=ball?{...ball}:null;
          if(ball&&(job?.phase==='chase'||(job?.phase==='drop'&&job.released)||job?.type!=='play'))ball=stepBall(ball,dt,ballBounds());
          if(slip)stepSlip(dt);
          else {
            landingLeft=Math.max(0,landingLeft-dt);landingSpring=springStep(landingSpring,dt);
            if(landingLeft===0&&mode==='land')setMode('idle',.2);
            stepIntent(dt);
            integrateHorizontal(dt);integrateVertical(dt,now);
            if(support){const feet=x+width()/2;if(feet<support.left||feet>support.right){ignoreSupport=support.element;ignoreUntil=now+400;support=null;airborne=true;vy=0;setMode('jump');}}
            afterBall(oldBall,oldMouth);checkPeels(oldX);footstep(x-oldX);
          }
          if(freeBallUntil&&now>freeBallUntil&&job?.type!=='play'){ball=null;ballNode.hidden=true;freeBallUntil=0;}
        }
        stepParticles(dt);
      }
    }
    if(now>=routineCheck){routineCheck=now+5000;checkRoutine(now);}
    if(now>=saveDue){saveDue=now+1200;if(document.hasFocus())saveScene();}
    if(!speech.hidden&&now>speechUntil)speech.hidden=true;
    render();schedule();
  }
  function positionProps() {
    if(job&&['feed','banana','meal'].includes(job.type)){
      const banana=job.type==='banana';prop.style.left=`${job.foodX-(banana?24:20)}px`;prop.style.top=`${ground()-(banana?48:24)}px`;
    }
    for(const peel of peels){peel.node.style.left=`${peel.x-24}px`;peel.node.style.top=`${ground()-48}px`;peel.node.dataset.armed=String(peel.armed);}
    if(ball){ballNode.style.left=`${ball.x-11}px`;ballNode.style.top=`${ball.y-11}px`;ballNode.style.transform=`rotate(${ball.angle||0}rad)`;if(ballNode.dataset.bounces!==String(ball.bounces))ballNode.dataset.bounces=String(ball.bounces);}
  }
  function positionUI() {
    speech.style.left=`${clamp(x+width()/2-110,8,Math.max(8,innerWidth-248))}px`;speech.style.top=`${Math.max(8,y-26)}px`;
    if(!menu.hidden){const h=menu.offsetHeight;menu.style.left=`${clamp(x+width()/2-130,8,Math.max(8,innerWidth-268))}px`;menu.style.top=`${clamp(y-h-8,8,Math.max(8,innerHeight-h-8))}px`;}
  }
  function render() {
    if(actor.dataset.state!==mode)actor.dataset.state=mode;
    actor.dataset.airborne=String(airborne);actor.dataset.support= support?'platform':'floor';
    actor.dataset.speed=String(Math.round(vx));
    actor.style.transform=`translate3d(${x.toFixed(1)}px,${y.toFixed(1)}px,0) scale(${scale()})`;
    const squash=Math.max(-.16,Math.min(1,landingSpring.value));
    sprite.style.transform=`scale(${facing*(1+squash*.15)},${1-squash*.2})`;
    sprite.style.transformOrigin='50% 89%';
    const animation=GOLDEN_ANIMATIONS[mode]||GOLDEN_ANIMATIONS.idle;
    const fps=['walk','run','carry','start'].includes(mode)?clamp(Math.abs(vx)/scale()/12,5,20):['eat','jump','drag'].includes(mode)?10:6;
    let next=animation.loop?Math.floor(elapsed*fps)%8:Math.min(7,Math.floor(elapsed/Math.max(.1,durations[mode]||1)*8));
    if(state.paused)next=Math.max(0,frame);
    else if(reducedMotion.matches)next=animation.loop?0:Math.min(7,next);
    if(frame!==next||sprite.dataset.mode!==mode){frame=next;sprite.dataset.mode=mode;sprite.style.backgroundPosition=`${-frame*160}px ${-animation.row*128}px`;}
    const lift=Math.max(0,(support?support.top:ground())-(y+114*scale()));
    const shadowScale=clamp(1-lift/(400*scale()),.28,1);
    petShadow.style.left=`${x+width()*.12}px`;petShadow.style.top=`${(support?support.top:ground())-5}px`;
    petShadow.style.width=`${width()*.76}px`;petShadow.style.transform=`scale(${shadowScale},${shadowScale})`;petShadow.style.opacity=String(.2*shadowScale);
    kennel.style.transform=`scale(${scale()})`;
    const activity=job?.type==='home'?job.phase==='sleep'?'sleep':job.phase:job?.type==='meal'?'meal':'free';
    if(kennel.dataset.activity!==activity)kennel.dataset.activity=activity;
    const label=state.paused?'已暂停':activity==='sleep'?'Z z z …':activity==='meal'?'开饭啦':state.scheduleEnabled?'按时吃饭，好好睡觉':'自在的小家';
    if(homeStatus.textContent!==label)homeStatus.textContent=label;
    positionProps();positionUI();paintEffects();
  }
  function schedule(){if(!raf&&!disposed&&state.enabled&&!document.hidden)raf=requestAnimationFrame(tick);}
  async function saveScene() {
    if(!ready||!state.continuity||restoring||!state.enabled)return;
    let sceneMode=job?.type==='home'&&job.phase==='sleep'?'sleep':job?.type==='pose'?job.kind:job?'idle':['walk','run'].includes(wander.kind)?wander.kind:mode;
    const snapshot={x:x/Math.max(1,innerWidth-width()),lift:Math.max(0,floor()-y)/Math.max(1,innerHeight),facing,mode:sceneMode,remaining:job?.type==='pose'?Math.max(.2,(poseSequences[job.kind][job.index]?.[1]||3)-job.elapsed):Math.max(.2,wander.left),savedAt:Date.now()};
    await request('sceneSave',snapshot);
  }
  async function restoreScene() {
    if(!state.continuity||restoring)return;
    const currentEpoch=epoch;restoring=true;const result=await request('sceneGet');restoring=false;
    if(epoch!==currentEpoch||job||drag||placement||!result.scene)return;
    const scene=result.scene;x=bound(scene.x*Math.max(0,innerWidth-width()));facing=scene.facing;
    const recent=Date.now()-scene.savedAt<120000;
    y=recent?clamp(floor()-scene.lift*innerHeight,0,floor()):floor();
    airborne=y<floor()-2;vy=0;vx=0;support=null;
    if(airborne)setMode('jump');
    else if(recent&&['walk','run'].includes(scene.mode)){wander={kind:scene.mode,left:scene.remaining,direction:facing};setMode('idle',.2);}
    else if(recent&&scene.mode==='sleep'&&routine(state).kind==='sleep'){x=homeX();job={type:'home',phase:'sleep',scheduled:true,elapsed:0};setMode('sleep',30,true);}
    else if(recent&&poseSequences[scene.mode]){startPose(scene.mode);}
    else {wander={kind:'idle',left:3};setMode('idle',3);}
    render();
  }
  function resize(){
    epoch++;cancelJob();clearPlacement();releaseDrag();windup=null;support=null;airborne=false;vx=0;turnTo=0;
    x=bound(x/Math.max(1,previousWidth-width())*Math.max(1,innerWidth-width()));y=floor();
    if(hitPeel){hitPeel.node.remove();hitPeel=null;}slip=null;landingLeft=0;setMode('idle',3);wander={kind:'idle',left:3};
    for(const peel of peels)peel.x=clamp(peel.x/previousWidth*innerWidth,24,Math.max(24,innerWidth-24));previousWidth=innerWidth;
    platforms.invalidate();routineCheck=0;render();saveScene();
  }
  window.addEventListener('resize',resize,{passive:true});
  window.addEventListener('scroll',()=>platforms.invalidate(),{passive:true,capture:true});
  document.addEventListener('visibilitychange',()=>{
    if(document.hidden){saveScene();cancelAnimationFrame(raf);raf=0;last=0;clearPlacement();if(drag){releaseDrag();airborne=true;vy=0;}if(job?.scheduled){cancelJob();setMode('idle',3);}}
    else {routineCheck=0;request('get').then(()=>{if(!job)restoreScene();});schedule();}
  });
  window.addEventListener('focus',()=>{if(ready&&!job&&!drag&&!placement)setTimeout(()=>{if(document.hasFocus()&&!job)restoreScene();},100);});
  const refresh=setInterval(()=>{if(state.enabled&&!document.hidden)request('get');},60000);
  window.addEventListener('pagehide',e=>{saveScene();cancelAnimationFrame(raf);raf=0;last=0;if(!e.persisted){disposed=true;clearInterval(refresh);observer.disconnect();rootObserver.disconnect();}});
  window.addEventListener('pageshow',()=>{routineCheck=0;schedule();});
  // Recover after a client-side app replaces its root, without inspecting page content.
  let repairTimer=0;
  function ensureHost(){
    if(disposed||host.isConnected||repairTimer)return;
    repairTimer=setTimeout(()=>{repairTimer=0;if(!disposed&&!host.isConnected&&document.documentElement){document.documentElement.append(host);rootObserver.disconnect();rootObserver.observe(document.documentElement,{childList:true});}},100);
  }
  const observer=new MutationObserver(ensureHost),rootObserver=new MutationObserver(ensureHost);
  observer.observe(document,{childList:true});rootObserver.observe(document.documentElement,{childList:true});
  y=floor();request('get').then(async()=>{
    await restoreScene();ready=true;world.style.opacity='1';say(`汪！${state.name}来陪你啦。`,4);routineCheck=0;schedule();
  });
})();
