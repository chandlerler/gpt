/* Opt-in geometry only: never reads text, values, URLs, images or forms. */
(() => {
  class Platforms {
    constructor(host) { this.host=host;this.items=[];this.enabled=false;this.dirty=true;this.next=0; }
    invalidate() { this.dirty=true; }
    update(now) {
      if(!this.enabled){this.items=[];return;}
      if(now<this.next && !this.dirty)return;
      this.next=now+700;this.dirty=false;
      const candidates=document.querySelectorAll('button, a, img, h1, h2, h3, p, [data-golden-platform]');
      const list=[];
      // Bound work on very large documents; no mutation of the host page.
      for(let i=0;i<Math.min(candidates.length,600);i++) {
        const node=candidates[i];if(this.host.contains(node))continue;
        const r=node.getBoundingClientRect();
        if(r.width<70||r.height<12||r.width>innerWidth*.95||r.top<100||r.top>innerHeight-30||r.right<40||r.left>innerWidth-40)continue;
        const css=getComputedStyle(node);if(css.visibility==='hidden'||css.display==='none'||Number(css.opacity)===0)continue;
        list.push({element:node,left:Math.max(0,r.left),right:Math.min(innerWidth,r.right),top:r.top});
        if(list.length>=50)break;
      }
      this.items=list;
    }
    get(element) { return this.items.find(p=>p.element===element)||null; }
    reachable(x,feet,scale) {
      return this.items.filter(p=>p.top>114*scale+4&&feet-p.top>12&&feet-p.top<=205*scale&&Math.abs((p.left+p.right)/2-x)<270*scale)
        .sort((a,b)=>Math.abs((a.left+a.right)/2-x)-Math.abs((b.left+b.right)/2-x))[0]||null;
    }
  }
  globalThis.GoldenPlatforms=Platforms;
})();
