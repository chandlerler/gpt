importScripts('core.js','scene.js');
let queue=Promise.resolve();
const coordinator=new GoldenScene.Coordinator({
  read:()=>chrome.storage.local.get(null),write:values=>chrome.storage.local.set(values),
  active:async id=>{try{const tab=await chrome.tabs.get(id),win=await chrome.windows.get(tab.windowId);return tab.active&&win.focused&&win.type==='normal';}catch{return false;}},
  yield:(id,message)=>Promise.race([chrome.tabs.sendMessage(id,message),new Promise(resolve=>setTimeout(()=>resolve(null),250))])
});
chrome.runtime.onMessage.addListener((request,sender,respond)=>{
  if(sender.id!==chrome.runtime.id||request?.channel!=='golden-state'||(sender.frameId&&sender.frameId!==0))return;
  queue=queue.catch(()=>{}).then(async()=>{
    const p=request.payload||{};
    if(request.action==='worldAcquire')return respond(await coordinator.acquire(p,sender));
    if(request.action==='worldSave')return respond(await coordinator.save(p,sender));
    if(request.action==='worldEffect')return respond(await coordinator.effect(p,sender));
    if(request.action==='worldRead'){const {world}=await coordinator.read();return respond({ok:true,scene:world.scene,epoch:world.epoch,owner:world.owner});}
    const {pet}=await chrome.storage.local.get('pet');
    if(sender.tab&&['feed','banana','meal','pet','play','rest','trainReward'].includes(request.action))return respond({ok:false,message:'请先接续当前场景。'});
    const result=GoldenCore.update(pet,request.action,p);
    await chrome.storage.local.set({pet:result.state});respond(result);
  }).catch(()=>respond({ok:false,message:'保存失败，请重新打开插件。'}));return true;
});
chrome.runtime.onInstalled.addListener(()=>{
  queue=queue.catch(()=>{}).then(async()=>{const {pet}=await chrome.storage.local.get('pet');await chrome.storage.local.set({pet:GoldenCore.normalize(pet)});});
});
