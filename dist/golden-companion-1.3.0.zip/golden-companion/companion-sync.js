/* One advancing scene across tabs/windows. Epochs fence off stale documents. */
(() => {
  class Sync {
    constructor(hooks){this.hooks=hooks;this.client=crypto.randomUUID();this.epoch=0;this.seq=0;this.active=false;this.pending=null;this.generation=0;this.saving=false;this.closed=false;}
    async raw(action,payload){try{return await chrome.runtime.sendMessage({channel:'golden-state',action,payload});}catch{return {ok:false,disconnected:true};}}
    async acquire(){
      if(this.pending)return this.pending;
      if(this.closed||document.hidden)return false;
      this.pending=this.performAcquire();try{return await this.pending;}finally{this.pending=null;}
    }
    async performAcquire(){
      const generation=this.generation;
      const result=await this.raw('worldAcquire',{client:this.client});
        if(this.closed||document.hidden||generation!==this.generation)return false;
        if(result.ok){const changed=!this.active||this.epoch!==result.epoch;
          if(changed){this.epoch=result.epoch;this.seq=result.seq||0;if(result.scene)this.hooks.restore(result.scene);else if(result.legacy)this.hooks.legacy(result.legacy);}
          this.active=true;this.hooks.owner(true);return true;
        }
        if(!result.disconnected){this.active=false;this.hooks.owner(false);if(result.scene)this.hooks.restore(result.scene);}
        return false;
    }
    async checkpoint(){
      if(!this.active||this.saving||this.closed)return;
      const epoch=this.epoch;this.saving=true;
      try{const result=await this.raw('worldSave',{client:this.client,epoch,seq:++this.seq,scene:this.hooks.capture()});
        if(result.revoked&&this.epoch===epoch){this.active=false;this.hooks.owner(false);}
      }finally{this.saving=false;}
    }
    yield(message){
      if(message.client!==this.client||message.epoch<this.epoch)return null;
      this.generation++;
      if(message.epoch!==this.epoch){this.active=false;this.hooks.owner(false);return null;}
      this.hooks.release();const scene=this.hooks.capture();this.active=false;this.hooks.owner(false);
      return {client:this.client,epoch:this.epoch,seq:++this.seq,scene};
    }
    async effect(action,data={},eventId=crypto.randomUUID()){
      if(!this.active&&!(await this.acquire()))return {ok:false,message:'请在当前活动网页继续互动。'};
      const epoch=this.epoch,result=await this.raw('worldEffect',{client:this.client,epoch,seq:++this.seq,eventId,action,data,scene:this.hooks.capture()});
      if(result.revoked&&this.epoch===epoch){this.active=false;this.hooks.owner(false);}return result;
    }
    start(){this.timer=setInterval(()=>{if(document.hidden||this.closed)return;if(this.active)this.checkpoint();else this.acquire();},300);return this.acquire();}
    close(){clearInterval(this.timer);this.closed=true;this.generation++;}
  }
  globalThis.GoldenSync=Sync;
})();
