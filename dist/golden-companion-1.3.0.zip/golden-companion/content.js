(() => {
  if (globalThis.__goldenCompanion) return;
  globalThis.__goldenCompanion = true;
  const { clamp, normalize, routine } = GoldenCore;
  const { launch, stepBall, sweptHit, approachVelocity, targetVelocity, toss, landingSurface, slipProfile, springStep } = GoldenPhysics;
  const el = (tag, cls, text) => {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text) node.textContent = text;
    return node;
  };
  const button = (cls, text, label) => {
    const node = el('button', cls, text); node.type = 'button';
    if (label) node.setAttribute('aria-label', label);
    return node;
  };
  const host = el('golden-companion'); host.id = 'golden-companion-root';
  const shadow = host.attachShadow({ mode: 'open' });
  const style = el('style'); style.textContent = GOLDEN_PET_STYLE;
  const world = el('div', 'world'), actor = el('div', 'actor');
  const petShadow=el('div','pet-shadow'), effectsCanvas=el('canvas','effects-canvas'),toyCanvas=el('canvas','effects-canvas toys-canvas'),ropeHandle=button('rope-handle','','拖住绳环拔河');ropeHandle.hidden=true;
  petShadow.setAttribute('aria-hidden','true');effectsCanvas.setAttribute('aria-hidden','true');
  const dog = button('dog'); dog.title = '点击摸摸 · 拖拽移动 · 右键打开菜单';
  const sprite = el('span', 'sprite'); sprite.setAttribute('aria-hidden', 'true');
  sprite.style.backgroundImage = `url("${chrome.runtime.getURL('sprites.png')}")`;
  const trigger = button('menu-trigger', '···', '打开桌宠菜单'); trigger.setAttribute('aria-expanded', 'false');
  const speech = el('div', 'speech'); speech.hidden = true; speech.setAttribute('role', 'status'); speech.setAttribute('aria-live', 'polite');
  const prop = el('div'); prop.hidden = true; prop.setAttribute('aria-hidden', 'true');
  const ballNode = el('div', 'ball'); ballNode.hidden = true; ballNode.setAttribute('aria-hidden', 'true');
  const kennel = button('kennel', '', '让金毛回窝休息');
  kennel.style.backgroundImage = `url("${chrome.runtime.getURL('kennel.png')}")`;
  const homeLabel = el('span', 'home-label'), homeStatus = el('span', 'home-status'); kennel.append(homeLabel, homeStatus);
  const menu = el('div', 'menu'); menu.hidden = true; menu.setAttribute('role', 'dialog'); menu.setAttribute('aria-label', '金毛互动菜单');
  const head = el('div', 'menu-head'), name = el('strong', 'menu-name'), close = button('close', '×', '关闭菜单');
  head.append(name, close);
  const summary = el('p', 'summary'), actions = el('div', 'actions');
  for (const [action, label] of [['feed','喂狗粮'],['banana','放香蕉'],['play','抛小球'],['pet','摸摸头'],['walk','去散步'],['run','跑起来'],['sleep','回窝睡觉'],['belly','翻肚皮'],['hop','开心跳'],['sniff','闻一闻'],['stretch','伸懒腰'],['perch','选落脚点'],['frisbee','扔飞盘'],['tug','玩拔河'],['trampoline','放弹床'],['blocks','搭积木'],['reward','奖励零食'],['tidy','收拾道具']]) {
    const node = button('action', label); node.dataset.action = action;
    node.addEventListener('click', () => { closeMenu(); command(action); }); actions.append(node);
  }
  menu.append(head, summary, actions, el('p', 'hint', '香蕉和小球可以选位置 · 点击狗窝回家'));
  const aim = el('div', 'aim-layer'); aim.hidden = true; aim.tabIndex = -1; aim.setAttribute('role', 'dialog'); aim.setAttribute('aria-label', '选择道具位置');
  const guide = el('canvas', 'aim-guide'), hud = el('div', 'aim-hud'), aimText = el('span');
  const cancelAim = button('aim-cancel', '取消 · Esc'); hud.append(aimText, cancelAim); aim.append(guide, hud);
  dog.append(sprite); actor.append(dog, trigger);
  world.append(kennel, petShadow, effectsCanvas, toyCanvas, prop, actor, ballNode, ropeHandle, speech, menu, aim); shadow.append(style, world); document.documentElement.append(host);
  world.style.opacity='0';

  let state = normalize(), ready = false, x = Math.max(0, innerWidth - 320), y = 0, facing = -1;
  let mode = 'idle', remaining = 4, elapsed = 0, frame = -1, last = 0, raf = 0, disposed = false;
  let job = null, target = null, drag = null, airborne = false, vy = 0, ball = null;
  let actionPending = false, speechUntil = 0, sleepElapsed = 0, lastTouch = 0;
  let placement = null, aimDrag = null, aimPoint = { x: innerWidth * .5, y: innerHeight * .4 };
  let peels = [], hitPeel = null, manualUntil = 0, routineCheck = 0, routinePending = false, epoch = 0;
  let previousWidth=innerWidth,previousHeight=innerHeight,previousScale=1;
  let pads=[],blocks=[],rope=null,inviteLeft=90,cursor={x:innerWidth/2,y:innerHeight/2};
  let clockWall=Date.now(),clockMono=performance.now();
  let vx=0,desiredV=0,turnTo=0,windup=null,landingLeft=0,landingSpring={value:0,velocity:0};
  let support=null,ignoreSupport=null,ignoreUntil=0,slip=null,queuedAction=null;
  let wander={kind:'idle',left:4},freeBallUntil=0,footDistance=0,particles=[],saveDue=0,restoring=false;
  const platforms=new GoldenPlatforms(host);
  const durations={blink:.7,look:1.8,sniff:2.2,yawn:1.7,stretch:1.6,pet:1.4,belly:2.8,crouch:.18,launch:.15,bite:.25,land:.4,start:.32,brake:.3,turn:.4,stumble:.4,tumble:.65,dizzy:.65,recover:.7,circle:1.3,lie:.7,wake:.7,drop:.6};
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  const rows=Object.fromEntries(Object.entries(GOLDEN_ANIMATIONS).map(([key,value])=>[key,value.row]));
  const scale = () => Math.min(state.size / 100, innerWidth / 170, innerHeight / 150);
  const width = () => 160 * scale(), height = () => 128 * scale();
  const ground = () => innerHeight - 12;
  const floor = () => Math.max(0, ground() - 114 * scale());
  const bound = value => clamp(value, 0, Math.max(0, innerWidth - width()));
  const homeX = () => bound(innerWidth - 12 - 152 * scale());
  const homeFoodX = () => clamp(innerWidth - 12 - 162 * scale(), 24, Math.max(24, innerWidth - 24));
  const ballBounds = () => ({ width:innerWidth, height:ground() });
  const mouth = (px = x, py = y, direction = facing) => ({ x:px + width() * (direction === 1 ? .87 : .13), y:py + height() * (mode==='drop'?.72:mode==='bite'||mode==='jump'||mode==='launch'?.38:.47) });
  const itemsImage = `url("${chrome.runtime.getURL('items.png')}")`;

  async function request(action, payload) {
    try {
      const care=['feed','banana','meal','pet','play','rest','trainReward'].includes(action);
      const result=care?await sync.effect(action,payload||{},payload?.eventId||crypto.randomUUID()):await chrome.runtime.sendMessage({channel:'golden-state',action,payload});
      if (result?.state) applyState(result.state);
      return result || { ok:false, message:'连接中断，请刷新网页。' };
    } catch {
      say('插件已更新，请刷新网页后继续玩。', 8);
      return { ok:false, message:'请刷新网页后重试。' };
    }
  }
  function applyState(next) {
    const previous = state; state = normalize(next);
    host.hidden = !state.enabled; host.style.setProperty('display', state.enabled ? 'block' : 'none', 'important');
    dog.setAttribute('aria-label', `摸摸${state.name}`); name.textContent = `${state.name} · 小金毛`;
    homeLabel.textContent = `${state.name}的小窝`;
    kennel.title = `点击回窝休息 · 本地时间 ${state.mealTimes.join(' / ')} 吃饭，${state.sleepStart}–${state.wakeTime} 睡觉`;
    summary.textContent = `饱食 ${Math.round(state.hunger)} · 心情 ${Math.round(state.mood)} · 体力 ${Math.round(state.energy)}`;
    if (!state.enabled && previous.enabled) { saveScene();cancelJob();clearPlacement();closeMenu();releaseDrag();airborne=false;vx=0;windup=null;slip=null;if(hitPeel)hitPeel.node.remove();hitPeel=null;setMode('sit',3); }
    if (state.paused && !previous.paused) { clearPlacement(); closeMenu(); releaseDrag(); }
    if(ready&&state.size!==previous.size){const scene=captureScene();restoreScene(scene);}
    platforms.enabled=state.platforms;
    if(!state.platforms&&support)leavePlatform();
    if(!state.effects)particles=[];
    if (JSON.stringify([state.scheduleEnabled,state.mealTimes,state.sleepStart,state.wakeTime]) !== JSON.stringify([previous.scheduleEnabled,previous.mealTimes,previous.sleepStart,previous.wakeTime])) {
      if (job?.scheduled) { cancelJob(); setMode('idle', 3); }
      routineCheck = 0; manualUntil = 0;
    }
    x = bound(x); if (!drag && !airborne) y = support?support.top-114*scale():floor();
    render(); schedule();
  }
  function say(text, seconds = 3) {
    speech.textContent = text; speechUntil = performance.now() + seconds * 1000; speech.hidden = false; positionUI();
  }
  function setMode(next, seconds = durations[next] || 4, force = false) {
    if(mode===next&&!force)return;
    mode = next; remaining = seconds; elapsed = 0; frame = -1; actor.dataset.state = mode;
    if (next !== 'sleep') sleepElapsed = 0;
  }
  function cancelJob(release = true, keepBall = false) {
    const previous = job; job = null; target = null; prop.hidden = true; prop.style.backgroundImage = '';
    if(!keepBall){ball=null;ballNode.hidden=true;freeBallUntil=0;}if(previous?.type==='tug')rope=null;
    if(!airborne&&!slip&&!drag){turnTo=0;setMode('idle',.2);}
    if (release && previous?.type === 'meal') request('releaseMeal', { token:previous.token });
  }
  function closeMenu() { menu.hidden = true; trigger.setAttribute('aria-expanded', 'false'); }
  function openMenu() {
    if (!state.enabled || placement) return;
    menu.hidden = !menu.hidden; trigger.setAttribute('aria-expanded', String(!menu.hidden)); positionUI();
    if (!menu.hidden) close.focus({ preventScroll:true });
  }
  close.addEventListener('click', () => { closeMenu(); dog.focus({ preventScroll:true }); });
  trigger.addEventListener('click', openMenu);
  kennel.addEventListener('click', () => command('sleep'));
  dog.addEventListener('contextmenu', e => { e.preventDefault(); openMenu(); });
  function hearts() {
    if(!state.effects||reducedMotion.matches)return;
    for (let i = 0; i < 3; i++) {
      const heart = el('span', 'effect', '♥'); heart.style.left = `${x + width() * (.4 + i * .15)}px`; heart.style.top = `${y + height() * .18}px`;
      heart.style.animationDelay = `${i * .1}s`; world.append(heart); setTimeout(() => heart.remove(), 1700);
    }
  }
  function foodTarget(foodX) {
    const direction=foodX>=x+width()/2?1:-1;
    return bound(foodX-width()*(direction===1?.84:.16));
  }
  function showFood(type, foodX, details = {}) {
    target = foodTarget(foodX);
    job = { type, phase:'approach', elapsed:0, foodX, ...details };
    prop.className = type === 'banana' ? 'banana' : 'bowl';
    prop.style.backgroundImage = type === 'banana' ? itemsImage : '';
    prop.hidden = false; positionProps();leavePlatform();
    say(type === 'banana' ? '香蕉！我来啦！' : type === 'meal' ? '饭点到啦，回家吃饭！' : '闻到香香的饭啦！');
  }
  function goHome(scheduled = false) {
    job = { type:'home', phase:'approach', scheduled, elapsed:0 };
    target=homeX();leavePlatform();say(scheduled?'天晚了，回小窝睡觉啦。':'回家睡个暖暖的小觉。');
  }
  function clearPlacement() {
    placement = null; aimDrag = null; aim.hidden = true;
  }
  function beginPlacement(type) {
    placement = type; aim.hidden = false; aimDrag = null;
    if(type==='perch')platforms.invalidate();
    aimPoint = { x:clamp(x + width() / 2,24,Math.max(24,innerWidth-24)), y:Math.max(30,innerHeight * .4) };
    refreshAimText();
    aim.focus({ preventScroll:true }); drawAim();
  }
  function startBall(start, end, kind='ball') {
    clearPlacement(); cancelJob();
    const direction = start.x < innerWidth / 2 ? 1 : -1;
    ball = launch({ x:clamp(start.x,12,innerWidth-12), y:clamp(start.y,12,Math.max(12,ground()-12)) },end,direction,kind);
    ballNode.hidden = false; ballNode.dataset.caught = 'false';
    job = { type:'play',toy:kind,phase:'chase',elapsed:0,jumpCooldown:0,returnX:bound(start.x-width()/2) };leavePlatform();say('看我的飞扑接球！');
  }
  function commitBanana(px) {
    clearPlacement(); showFood('banana', clamp(px,24,Math.max(24,innerWidth-24)));
  }
  function drawAim() {
    if (!placement) return;
    guide.width = innerWidth; guide.height = innerHeight;
    const ctx = guide.getContext('2d'); if (!ctx) return;
    ctx.clearRect(0,0,guide.width,guide.height);
    if(placement==='perch'){drawPlatforms(ctx);return;}
    if (['banana','trampoline','blocks'].includes(placement)) {
      ctx.fillStyle = '#dec06d'; ctx.fillRect(aimPoint.x-20,ground()-4,40,4);
      ctx.strokeStyle = '#a89464'; ctx.setLineDash([4,7]); ctx.beginPath(); ctx.moveTo(aimPoint.x,ground()-70); ctx.lineTo(aimPoint.x,ground()-12); ctx.stroke();
      return;
    }
    const start = aimDrag?.start || aimPoint, end = aimDrag?.end || start;
    let preview = launch(start,end,start.x < innerWidth/2 ? 1 : -1,placement==='frisbee'?'frisbee':'ball');
    ctx.fillStyle = '#d18f5d'; ctx.fillRect(start.x-7,start.y-7,14,14);
    for (let i=0; i<28; i++) {
      preview = stepBall(preview,.035,ballBounds()); ctx.fillStyle = `rgba(116,137,86,${.65-i*.016})`; ctx.fillRect(preview.x-2,preview.y-2,4,4);
    }
  }
  cancelAim.addEventListener('click', () => { clearPlacement(); say('取消啦，继续陪你。'); });
  aim.addEventListener('pointerdown', e => {
    if (e.button !== 0 || e.target.closest('button') || e.target.closest('.aim-hud')) return;
    e.preventDefault(); e.stopPropagation();
    aimPoint = { x:e.clientX,y:e.clientY };
    aimDrag = { id:e.pointerId,start:{...aimPoint},end:{...aimPoint} }; aim.setPointerCapture(e.pointerId); drawAim();
  });
  aim.addEventListener('pointermove', e => {
    aimPoint = { x:e.clientX,y:e.clientY };
    if (aimDrag) aimDrag.end = {...aimPoint}; drawAim();
  });
  aim.addEventListener('pointerup', e => {
    if (!aimDrag || aimDrag.id !== e.pointerId) return;
    e.preventDefault(); e.stopPropagation(); const gesture = aimDrag, kind = placement;
    aimDrag = null; if (aim.hasPointerCapture(e.pointerId)) aim.releasePointerCapture(e.pointerId);
    if (kind === 'banana') commitBanana(e.clientX);
    else if(kind==='play'||kind==='frisbee')startBall(gesture.start,{x:e.clientX,y:e.clientY},kind==='frisbee'?'frisbee':'ball');
    else if(kind==='trampoline'||kind==='blocks')placeToy(kind,e.clientX);
    else if(kind==='perch')pickPerch(e.clientX,e.clientY);
  });
  aim.addEventListener('pointercancel', () => { aimDrag = null; drawAim(); });
  aim.addEventListener('lostpointercapture', () => { if (aimDrag) { aimDrag = null; drawAim(); } });
  document.addEventListener('keydown', e => {
    if (placement) {
      if (['Escape','Enter','ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)) { e.preventDefault(); e.stopPropagation(); }
      if (e.key === 'Escape') clearPlacement();
      if (e.key === 'Enter') { if(placement==='banana')commitBanana(aimPoint.x);else if(['blocks','trampoline'].includes(placement))placeToy(placement,aimPoint.x);else if(placement==='perch')pickPerch(aimPoint.x,aimPoint.y);else startBall(aimPoint,aimPoint,placement==='frisbee'?'frisbee':'ball'); }
      if (e.key.startsWith('Arrow')) {
        aimPoint.x = clamp(aimPoint.x + (e.key === 'ArrowLeft' ? -24 : e.key === 'ArrowRight' ? 24 : 0),12,Math.max(12,innerWidth-12));
        aimPoint.y = clamp(aimPoint.y + (e.key === 'ArrowUp' ? -24 : e.key === 'ArrowDown' ? 24 : 0),12,Math.max(12,ground()-12)); drawAim();
      }
    } else if (e.key === 'Escape' && !menu.hidden) { closeMenu(); dog.focus({preventScroll:true}); }
  },true);

  function refreshAimText(){
    aimText.textContent={banana:'点击地面位置放香蕉 · Esc 取消',play:'拖动决定方向与力度，松手抛球 · Enter 轻抛',frisbee:'拖动抛出旋转飞盘 · Enter 轻抛',trampoline:'点击选择弹床位置，狗狗和小球都能弹起来',blocks:'点击放一叠积木，试试用球撞倒它们',perch:'绿色边缘可以到达，点击选择落点 · 支持分段跳跃'}[placement]||'';
  }
  function placeToy(kind,px){
    clearPlacement();
    if(kind==='trampoline'){
      if(pads.length>=2){say('已经有两张弹床啦，先收拾一下道具。');return;}
      pads.push({id:crypto.randomUUID(),x:clamp(px,65,innerWidth-65),width:110,pulse:0,cooldown:0,armed:true});say('弹床放好啦，跑过它试试！');
    }else{
      if(blocks.length>=12){say('积木已经够多啦，先收拾一下道具。');return;}
      for(let i=0;i<3;i++)blocks.push({id:crypto.randomUUID(),x:clamp(px-16,0,innerWidth-32),y:ground()-32*(i+1),w:32,h:32,vx:0,vy:0,angle:0,spin:0});say('积木搭好啦，可以用球撞倒它们。');
    }saveScene();
  }
  function startTug(){
    leavePlatform();job={type:'tug',phase:'settle',elapsed:0,anchor:x};rope=null;say('站稳啦，准备和你拔河！');
  }
  function prepareRope(){
    job.phase='play';job.anchor=x;const m=mouth(),rest=Math.min(100,innerWidth/6);
    rope={x:clamp(m.x+facing*(rest+10),30,innerWidth-30),y:m.y,vx:0,vy:0,rest,effort:0,held:false};say('拖住绳环，和我拔河！');
  }
  async function finishTug(){
    if(!job||job.phase==='saving')return;const completed=job;job.phase='saving';actionPending=true;
    const r=await request('play',{toy:'tug',eventId:completed.id||(completed.id=crypto.randomUUID())});actionPending=false;
    if(job!==completed||!sync.active)return;rope=null;cancelJob();startPose('happy');say(r.ok?'这场拔河真开心！':r.message);saveScene();
  }
  function stepTug(dt){
    if(job.phase==='settle'){
      if(airborne||windup||landingLeft>0||Math.abs(vx)>5)return;
      const direction=x+width()/2<innerWidth/2?1:-1;
      if(facing!==direction){turnTo=direction;job.phase='orient';setMode('turn',.4,true);}else prepareRope();return;
    }
    if(job.phase==='orient'){if(!turnTo)prepareRope();return;}
    if(!rope){cancelJob();return;}
    if(job.phase==='retry'){finishTug();return;}
    job.elapsed+=dt;const m=mouth(),distance=Math.hypot(rope.x-m.x,rope.y-m.y),stretch=Math.max(0,distance-rope.rest);
    if(rope.held){desiredV=clamp((rope.x-m.x-facing*rope.rest)*.45+(job.anchor-x)*4,-40,40);if(stretch>rope.rest*.2)rope.effort+=dt*Math.min(2,stretch/(rope.rest*.45));setMode('tug',60);}
    else {GoldenToys.stepRope(rope,m,dt);rope.x=clamp(rope.x,18,innerWidth-18);rope.y=clamp(rope.y,18,ground()-18);desiredV=0;setMode('bite',60);}
    if(rope.effort>=4)finishTug();else if(job.elapsed>90){rope=null;cancelJob();say('绳子先收好，下次再玩。');}
  }
  const skillNames={recall:'召回',shake:'握手',wait:'等待',playdead:'装死'};
  function startTraining(skill){
    leavePlatform();const trained=state.training[skill];
    job={type:'training',skill,phase:'settle',elapsed:0,index:0,coached:trained<40&&Math.random()>.65-trained*.006,destination:bound(x>innerWidth/2?100:innerWidth-width()-100)};
    say(`练习${skillNames[skill]}：完成后记得奖励一颗零食。`,4);
  }
  function trainingSequence(j){return j.skill==='shake'?[['sit',.5],['shake',2]]:j.skill==='wait'?[['sit',4]]:j.skill==='playdead'?[['lie',.5],['tumble',.6],['playdead',2],['recover',.7]]:[['happy',.8]];}
  function stepTraining(dt){
    if(job.phase==='reward'){finishTraining();return;}
    if(job.phase==='settle'){
      if(airborne||windup||landingLeft>0)return;
      if(job.skill==='recall'){if(!driveTo(job.destination,155*scale()))return;}
      else if(Math.abs(vx)>5)return;
      job.phase=job.coached?'coach':'perform';job.elapsed=0;job.index=0;setMode(job.coached?'look':trainingSequence(job)[0][0],2,true);
      if(job.coached)say('再示范一下，我正在学呢。',2);
    }else if(job.phase==='coach'){
      job.elapsed+=dt;if(job.elapsed>=1.5){job.phase='perform';job.elapsed=0;setMode(trainingSequence(job)[0][0],2,true);}
    }else if(job.phase==='perform'){
      const clips=trainingSequence(job);job.elapsed+=dt;
      if(job.elapsed>=clips[job.index][1]){job.elapsed=0;job.index++;if(job.index===clips.length){job.phase='awaitReward';setMode('sit',60);say('做到了！点“奖励零食”让我记住吧。',15);}else setMode(clips[job.index][0],clips[job.index][1],true);}
    }else if(job.phase==='awaitReward'){
      job.elapsed+=dt;if(job.elapsed>45){cancelJob();say('这次先练到这里，下次继续。');}
    }
  }
  async function finishTraining(){
    if(!job||job.type!=='training'||job.phase==='saving')return;
    const completed=job;job.phase='saving';actionPending=true;
    const r=await request('trainReward',{skill:job.skill,coached:job.coached,eventId:job.id||(job.id=crypto.randomUUID())});actionPending=false;
    if(job!==completed||!sync.active)return;cancelJob();startPose('happy');if(r.ok)hearts();say(r.message,4);saveScene();
  }
  function stepWorldToys(dt,oldBall){
    blocks=GoldenToys.stepBlocks(blocks,dt,ballBounds());
    for(const b of blocks){if(!airborne&&Math.abs(vx)>15&&y+114*scale()>b.y&&x+width()*.7>b.x&&x+width()*.25<b.x+b.w){b.vx+=vx*dt*9;b.spin+=vx*dt*.05;vx*=.97;}}
    if(ball&&(job?.type!=='play'||job.phase==='chase'||(job.phase==='drop'&&job.released))){
      GoldenToys.hitBlocks(ball,blocks);
      for(const pad of pads){const top=ground()-14;if(oldBall&&ball.x>pad.x-pad.width/2&&ball.x<pad.x+pad.width/2&&oldBall.y+ball.radius<=top+2&&ball.y+ball.radius>=top&&ball.vy>=0){ball.y=top-ball.radius;const speed=Math.abs(ball.vy);ball.vy=speed>90?-speed*.8:0;ball.grounded=speed<=90;pad.pulse=.5;}}
      if(ball.grounded&&ball.y+ball.radius<ground()-2&&!pads.some(p=>Math.abs(ball.x-p.x)<p.width/2))ball.grounded=false;
    }
    for(const pad of pads){pad.pulse=Math.max(0,pad.pulse-dt);pad.cooldown=Math.max(0,pad.cooldown-dt);const feet=x+width()/2,inside=Math.abs(feet-pad.x)<pad.width/2-8;
      if(!inside)pad.armed=true;
      if(inside&&!airborne&&!support&&!windup&&!slip&&pad.armed&&Math.abs(vx)>20&&pad.cooldown===0){pad.armed=false;pad.pulse=.5;pad.cooldown=.5;airborne=true;vy=-610*scale();landingLeft=0;setMode('launch',.15,true);}
    }
  }
  function paintToys(){
    if(toyCanvas.width!==innerWidth||toyCanvas.height!==innerHeight){toyCanvas.width=innerWidth;toyCanvas.height=innerHeight;}
    const ctx=toyCanvas.getContext('2d');ctx.clearRect(0,0,innerWidth,innerHeight);
    for(const p of pads){ctx.fillStyle='#517a69';ctx.fillRect(p.x-p.width/2,ground()-14+p.pulse*8,p.width,7);ctx.fillStyle='#b2c89b';ctx.fillRect(p.x-p.width/2+4,ground()-14+p.pulse*8,p.width-8,3);ctx.fillStyle='#886b4b';ctx.fillRect(p.x-p.width/2+5,ground()-7,7,7);ctx.fillRect(p.x+p.width/2-12,ground()-7,7,7);}
    for(let i=0;i<blocks.length;i++){const b=blocks[i];ctx.save();ctx.translate(b.x+b.w/2,b.y+b.h/2);ctx.rotate(b.angle);ctx.fillStyle=['#d99a62','#83a582','#8caab1'][i%3];ctx.fillRect(-b.w/2,-b.h/2,b.w,b.h);ctx.strokeStyle='#79664c';ctx.lineWidth=2;ctx.strokeRect(-b.w/2+1,-b.h/2+1,b.w-2,b.h-2);ctx.fillStyle='#ffffff66';ctx.fillRect(-b.w/2+4,-b.h/2+4,b.w-8,3);ctx.restore();}
    ropeHandle.hidden=!rope;if(rope){const m=mouth();ctx.strokeStyle='#b48550';ctx.lineWidth=5;ctx.setLineDash([5,3]);ctx.beginPath();ctx.moveTo(m.x,m.y);ctx.quadraticCurveTo((m.x+rope.x)/2,Math.max(m.y,rope.y)+Math.max(0,rope.rest-Math.hypot(rope.x-m.x,rope.y-m.y))*.35,rope.x,rope.y);ctx.stroke();ctx.setLineDash([]);ropeHandle.style.left=`${rope.x-16}px`;ropeHandle.style.top=`${rope.y-16}px`;ropeHandle.setAttribute('aria-label',`拔河绳环，完成 ${Math.min(100,Math.round(rope.effort/4*100))}%`);}
    toyCanvas.dataset.blocks=String(blocks.length);toyCanvas.dataset.pads=String(pads.length);
  }
  ropeHandle.addEventListener('pointerdown',e=>{if(!sync.active||!rope||state.paused)return;e.preventDefault();rope.held=true;ropeHandle.setPointerCapture(e.pointerId);});
  ropeHandle.addEventListener('pointermove',e=>{if(!rope?.held)return;const m=mouth(),dx=e.clientX-m.x,dy=e.clientY-m.y,d=Math.max(1,Math.hypot(dx,dy)),length=Math.min(240,d);rope.x=clamp(m.x+dx/d*length,18,innerWidth-18);rope.y=clamp(m.y+dy/d*length,18,ground()-18);rope.vx=0;rope.vy=0;});
  for(const event of ['pointerup','pointercancel','lostpointercapture'])ropeHandle.addEventListener(event,()=>{if(rope)rope.held=false;});
  document.addEventListener('pointermove',e=>{cursor={x:e.clientX,y:e.clientY};},{passive:true});

  const poseSequences={
    blink:[['blink',.7]],look:[['look',1.8]],sniff:[['sniff',2.2]],yawn:[['yawn',1.7]],stretch:[['stretch',1.6]],
    pet:[['pet',1.4],['happy',.7]],belly:[['lie',.6],['tumble',.6],['belly',2.8],['recover',.7]],
    sit:[['sit',4],['recover',.6]],turn:[['turn',.4]],happy:[['happy',1.5]]
  };
  function startPose(kind) {
    job={type:'pose',kind,phase:'settle',index:0,elapsed:0};target=null;
  }
  function leavePlatform() {
    if(!support)return;
    ignoreSupport=support.element;ignoreUntil=performance.now()+700;support=null;airborne=true;vy=35;
    setMode('jump');
  }
  function beginJump(jumpHeight,horizontal=null,kind='toy') {
    if(airborne||windup||turnTo||landingLeft>0)return false;
    windup={left:.18,vy:-Math.sqrt(2*1200*jumpHeight),horizontal,kind};setMode('crouch',.18,true);return true;
  }
  function drawPlatforms(ctx){
    platforms.update(performance.now());
    for(const p of platforms.items){const route=platforms.route(p,x+width()/2,y+114*scale(),scale(),support);ctx.fillStyle=route?'#71996cb0':'#a79c8c77';ctx.fillRect(p.left,p.top-5,p.right-p.left,8);ctx.font='12px system-ui';ctx.fillStyle=route?'#3b6847':'#81796e';ctx.fillText(route?`${route.length>1?route.length+' 段跳跃':'可跳上'}`:'暂时够不到',p.left+3,p.top-10);}
  }
  function pickPerch(px,py){
    platforms.invalidate();platforms.update(performance.now());
    const choices=platforms.items.filter(p=>px>=p.left-8&&px<=p.right+8&&Math.abs(py-p.top)<65).sort((a,b)=>Math.abs(a.top-py)-Math.abs(b.top-py));
    const p=choices[0];if(!p){say('点击绿色的边缘来选落点。');return;}
    const result=startPerch(p);if(result.ok)clearPlacement();else say(result.message);
  }
  function startPerch(selected=null){
    if(!state.platforms)return {ok:false,message:'先打开网页元素停靠。'};
    platforms.update(performance.now());const p=selected||platforms.reachable(x+width()/2,y+114*scale(),scale());
    if(!p)return {ok:false,message:'附近没有安全落脚点。'};
    const route=platforms.route(p,x+width()/2,y+114*scale(),scale(),support);
    if(!route)return {ok:false,message:'这个位置太高或没有足够的落脚空间，试试绿色边缘。'};
    job={type:'perch',phase:'approach',leg:0,route:route.map(p=>({left:p.left,right:p.right,top:p.top}))};
    say(route.length>1?`找到路线啦，分 ${route.length} 次跳上去。`:'先找好起跳位置，再稳稳跳上去。');return {ok:true};
  }
  function stepPerch(dt){
    const goal=job.route?.[job.leg],p=platforms.match(goal);
    if(!p){if(airborne){desiredV=vx;job.phase='lost';return;}cancelJob();startPose('look');say('落脚点变了，我先站稳再找新的。');return;}
    const destination=bound((p.left+p.right)/2-width()/2);
    if(job.phase==='approach'){
      if(airborne||windup||landingLeft>0)return;
      if(!support){const launchX=bound(destination-Math.sign(destination-x)*Math.min(135*scale(),Math.abs(destination-x)));if(!driveTo(launchX,110*scale()))return;}
      else if(Math.abs(vx)>5)return;
      const rise=y+114*scale()-p.top,jumpHeight=Math.max(40*scale(),rise+30*scale());
      if(jumpHeight>225*scale()||jumpHeight>y-6){cancelJob();say('这个落点现在够不到啦。');return;}
      const jumpVy=-Math.sqrt(2400*jumpHeight),time=(-jumpVy+Math.sqrt(Math.max(0,jumpVy*jumpVy-2400*rise)))/1200;
      job.destination=destination;job.jumpVX=(destination-x)/Math.max(.25,time);job.jumpHeight=jumpHeight;
      if(Math.abs(job.jumpVX)>420*scale()){cancelJob();say('距离有些远，换个近一点的落点吧。');return;}
      if(beginJump(jumpHeight,job.jumpVX,'platform'))job.phase='flight';
    }else if(job.phase==='flight'||job.phase==='lost'){
      if(airborne)desiredV=job.jumpVX||vx;
      else if(!windup&&landingLeft<=0){
        if(support?.element===p.element&&job.leg+1<job.route.length){job.leg++;job.phase='approach';vx=0;setMode('idle',.2);}
        else {cancelJob();startPose('look');say(support?'稳稳站好，看看这里的风景。':'先在地面站稳啦。');saveScene();}
      }
    }
  }
  async function command(action) {
    if(!(await sync.acquire()))return {ok:false,message:'请在当前活动网页继续互动。'};
    const known=['feed','banana','pet','play','walk','run','sleep','hop','perch','frisbee','tug','trampoline','blocks','reward','tidy',...Object.keys(skillNames).map(k=>'train:'+k),...Object.keys(poseSequences)];
    if(!known.includes(action))return {ok:false,message:'未知动作'};
    if(!state.enabled)return {ok:false,message:'请先打开“网页陪伴”。'};
    if(state.paused)return {ok:false,message:'请先取消“暂停活动”。'};
    if(actionPending||drag||slip)return {ok:false,message:'等我站稳，再陪你玩～'};
    if(action==='reward'){if(job?.type!=='training'||job.phase!=='awaitReward')return {ok:false,message:'等它完成训练，再奖励零食。'};await finishTraining();return {ok:true,message:'奖励完成，熟练度已保存。'};}
    if(action==='tidy'){cancelJob();clearPlacement();ball=null;rope=null;pads=[];blocks=[];for(const p of peels)p.node.remove();peels=[];saveScene();return {ok:true,message:'道具收好啦。'};}
    if(action.startsWith('train:')&&Date.now()-state.lastTrain<10000)return {ok:false,message:'先消化一下刚学到的本领吧。'};
    if(job?.type==='home'&&['lie','sleep','wake','stretch','exit'].includes(job.phase)&&action!=='sleep') {
      queuedAction=action;epoch++;manualUntil=performance.now()+60000;
      if(!['wake','stretch','exit'].includes(job.phase))wakeHome();
      return {ok:true,message:'醒来伸个懒腰，就来陪你。'};
    }
    if(job&&['feed','banana','meal'].includes(job.type))return {ok:false,message:'先等我把这口饭吃完吧。'};
    if(job?.type==='play'&&!['play','frisbee','tug','sleep','pet','trampoline','blocks'].includes(action))return {ok:false,message:'等我把球叼回来，再来玩这个。'};
    if(['feed','banana'].includes(action)&&Date.now()-state.lastFeed<8000)return {ok:false,message:'刚吃过啦，等一小会儿再喂～'};
    if(action==='banana'&&peels.length>=6)return {ok:false,message:'先让金毛清理一下地上的香蕉皮吧。'};
    if(['play','frisbee','tug'].includes(action)&&(Date.now()-state.lastPlay<5000||state.energy<12))return {ok:false,message:'先让我休息一下，再来接球。'};
    if(action==='perch'&&!state.platforms)return {ok:false,message:'先在专属设置中打开“网页元素停靠”。'};
    epoch++;manualUntil=performance.now()+60000;closeMenu();clearPlacement();cancelJob();queuedAction=null;
    if(['banana','play','frisbee','trampoline','blocks','perch'].includes(action)) {
      beginPlacement(action);return {ok:true,placement:true,message:aimText.textContent};
    }
    if(action==='tug')startTug();
    else if(action.startsWith('train:'))startTraining(action.split(':')[1]);
    else if(action==='feed') {
      const dest=bound(x+(x<(innerWidth-width())/2?240:-240));
      showFood('feed',clamp(dest+width()*(dest>=x?.84:.16),24,innerWidth-24));
    } else if(action==='pet') {
      startPose('pet');actionPending=true;const response=await request('pet');actionPending=false;
      if(!state.enabled||state.paused||!sync.active)return response;
      hearts();say(response.message);return response;
    } else if(action==='sleep')goHome(false);
    else if(action==='hop'){job={type:'hop',phase:'settle'};say('开心到跳起来！');}
    else if(action==='walk'||action==='run') {
      wander={kind:action,left:9};target=null;
      // Changing a direction is handled by braking and a turn, never an instant mirror.
      wander.direction=x>(innerWidth-width())/2?-1:1;say(action==='run'?'小爪子，出发！':'慢慢逛一圈。');
    } else {startPose(action);say({belly:'肚皮给你摸摸～',sniff:'这里有什么香香的？',yawn:'哈——有一点点困。',stretch:'伸个大懒腰！',look:'让我看看周围。',sit:'乖乖坐好。',blink:'眨眨眼，看到你啦。',turn:'转个身，继续走。'}[action]||'好开心！');}
    schedule();return {ok:true,message:'收到啦，看看网页里的小金毛。'};
  }
  chrome.runtime.onMessage.addListener((message,sender,respond)=>{
    if(sender.id!==chrome.runtime.id||message?.channel!=='golden-pet')return;
    if(message.action==='yieldScene'){respond(sync.yield(message));return;}
    if(message.action==='ping'){respond({ok:true,mode,enabled:state.enabled,active:sync.active,training:job?.type==='training'?{skill:job.skill,phase:job.phase}:null});return;}
    command(message.action).then(respond);return true;
  });
  chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.pet?.newValue)applyState(changes.pet.newValue);});
  function releaseDrag() {
    const old=drag;drag=null;if(old&&dog.hasPointerCapture(old.id))dog.releasePointerCapture(old.id);
  }
  dog.addEventListener('pointerdown',e=>{
    if(!sync.active||e.button!==0||state.paused||slip||placement||actionPending)return;
    closeMenu();drag={id:e.pointerId,startX:e.clientX,startY:e.clientY,x,y,moved:false,samples:[]};dog.setPointerCapture(e.pointerId);
  });
  dog.addEventListener('pointermove',e=>{
    if(!drag||drag.id!==e.pointerId)return;
    const dx=e.clientX-drag.startX,dy=e.clientY-drag.startY,now=performance.now();
    if(!drag.moved&&Math.abs(dx)+Math.abs(dy)>5) {
      drag.moved=true;epoch++;manualUntil=now+60000;cancelJob();airborne=false;support=null;windup=null;vx=0;turnTo=0;setMode('drag',10,true);
    }
    if(drag.moved) {
      x=bound(drag.x+dx);y=clamp(drag.y+dy,0,floor());
      drag.samples.push({x,y,t:now});drag.samples=drag.samples.filter(s=>now-s.t<160);render();
    }
  });
  function release(e,cancelled=false) {
    if(!drag||drag.id!==e.pointerId)return;
    const moved=drag.moved,impulse=toss(drag.samples,performance.now(),scale());releaseDrag();
    if(moved) {
      airborne=true;vx=cancelled?0:impulse.vx;vy=cancelled?0:impulse.vy;
      if(Math.abs(vx)>10)facing=Math.sign(vx);setMode('jump');say(Math.abs(vx)>100?'飞一下，再稳稳落地！':'轻轻放下，稳稳站好。',2);saveScene();
    } else if(!cancelled){lastTouch=performance.now();command('pet');}
  }
  dog.addEventListener('pointerup',e=>release(e));dog.addEventListener('pointercancel',e=>release(e,true));dog.addEventListener('lostpointercapture',e=>release(e,true));
  dog.addEventListener('click',e=>{if(e.detail===0&&performance.now()-lastTouch>300)command('pet');});

  function addPeel(px,id=crypto.randomUUID()) {
    const node=el('div','peel');node.style.backgroundImage=itemsImage;node.setAttribute('aria-hidden','true');
    peels.push({id,x:px,node,armed:false});world.insertBefore(node,actor);positionProps();
  }
  function checkPeels(previousX) {
    if(airborne||support||windup||slip||Math.abs(vx)<8)return;
    for(const peel of peels) {
      if(!peel.armed){if(peel.x<x-8||peel.x>x+width()+8)peel.armed=true;continue;}
      if(peel.x>=Math.min(previousX,x)+width()*.22-8&&peel.x<=Math.max(previousX,x)+width()*.75+8) {
        peels=peels.filter(p=>p!==peel);hitPeel=peel;
        const profile=slipProfile(vx,scale());slip={...profile,phase:'slip',elapsed:0};vx=profile.slideVelocity;
        turnTo=0;setMode('slip',.28,true);say(profile.tumble?'哎呀，跑太快滑倒了！':'哎哟，脚底滑了一下。',3);break;
      }
    }
  }
  function stepSlip(dt) {
    slip.elapsed+=dt;x=bound(x+vx*dt);vx*=Math.exp(-2.6*dt);
    if(x<=0||x>=innerWidth-width())vx=0;
    if(hitPeel&&slip.elapsed>.2){hitPeel.node.remove();hitPeel=null;}
    const length=slip.phase==='slip'?.28:slip.phase==='tumble'?.65:slip.phase==='stumble'?.4:slip.phase==='dizzy'?slip.dizzy:.7;
    if(slip.elapsed>=length) {
      const next=slip.phase==='slip'?(slip.tumble?'tumble':'stumble'):['tumble','stumble'].includes(slip.phase)?'dizzy':slip.phase==='dizzy'?'recover':null;
      if(next){slip.phase=next;slip.elapsed=0;setMode(next,next==='dizzy'?slip.dizzy:durations[next],true);}
      else {slip=null;vx=0;setMode('idle',2);}
    }
  }
  function spawnDust(amount=5) {
    if(!state.effects||reducedMotion.matches)return;
    for(let i=0;i<amount;i++)particles.push({kind:'dust',x:x+width()*(.2+Math.random()*.5),y:y+114*scale(),vx:(Math.random()-.5)*65,vy:-15-Math.random()*25,life:.55,max:.55,size:2+Math.random()*3});
    particles=particles.slice(-56);
  }
  function footstep(distance) {
    if(!state.effects||reducedMotion.matches||airborne||support||slip||Math.abs(vx)<25)return;
    footDistance+=Math.abs(distance);
    if(footDistance>30*scale()) {
      footDistance=0;particles.push({kind:'paw',x:x+width()*.4,y:ground()-2,vx:0,vy:0,life:2,max:2,size:3,flip:Math.random()>.5});
      if(Math.abs(vx)>140*scale())spawnDust(1);particles=particles.slice(-56);
    }
  }
  function stepParticles(dt) {
    for(const p of particles){p.life-=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;if(p.kind==='dust')p.vy+=25*dt;}
    particles=particles.filter(p=>p.life>0);
  }
  function paintEffects() {
    if(effectsCanvas.width!==innerWidth||effectsCanvas.height!==innerHeight){effectsCanvas.width=innerWidth;effectsCanvas.height=innerHeight;}
    const ctx=effectsCanvas.getContext('2d');if(!ctx)return;ctx.clearRect(0,0,innerWidth,innerHeight);
    if(!state.effects)return;
    for(const p of particles) {
      ctx.globalAlpha=Math.max(0,p.life/p.max)*(p.kind==='paw'?.22:.45);ctx.fillStyle=p.kind==='paw'?'#8f7a54':'#c7b58a';
      if(p.kind==='paw'){ctx.fillRect(p.x,p.y-3,5,3);ctx.fillRect(p.x-1,p.y-6,2,2);ctx.fillRect(p.x+2,p.y-7,2,2);ctx.fillRect(p.x+5,p.y-5,2,2);}
      else ctx.fillRect(Math.round(p.x),Math.round(p.y),p.size,p.size);
    }
    ctx.globalAlpha=1;
  }
  function arrived(destination) {return Math.abs(x-destination)<2&&Math.abs(vx)<12&&!airborne&&!windup&&landingLeft<=0&&!turnTo;}
  function driveTo(destination,speed,finalFacing=null) {
    target=destination;
    const atPosition=Math.abs(destination-x)<2;
    desiredV=atPosition?0:targetVelocity(destination-x,speed,850*scale());
    // A toy can be beneath the body: reaching its x coordinate is not enough.
    // Stop and turn so the mouth actually faces it before eating or picking up.
    if(atPosition&&Math.abs(vx)<12&&!airborne&&!windup&&landingLeft<=0&&finalFacing&&facing!==finalFacing&&!turnTo){turnTo=finalFacing;setMode('turn',.4,true);}
    return arrived(destination)&&(!finalFacing||facing===finalFacing);
  }
  function integrateHorizontal(dt) {
    if(windup){vx=approachVelocity(vx,0,900*scale(),dt);x=bound(x+vx*dt);return;}
    const movingKind=job?.type==='play'?'run':job?.type==='banana'?'run':job?'walk':wander.kind;
    const locomotion=['idle','start','walk','run','brake','turn','carry'].includes(mode)&&!((job?.type==='pose'&&job.phase==='animate')||job?.type==='tug'||(job?.type==='training'&&job.phase!=='settle'));
    if(locomotion&&!airborne&&!landingLeft&&Math.abs(desiredV)>2&&Math.sign(desiredV)!==facing) {
      if(Math.abs(vx)>9){desiredV=0;setMode('brake');}
      else {
        if(!turnTo){turnTo=Math.sign(desiredV);setMode('turn',.4,true);}
        desiredV=0;
      }
    }
    if(turnTo) {
      desiredV=0;if(elapsed>=.2)facing=turnTo;
      if(elapsed>=.4){turnTo=0;setMode('idle',.2);}
    }
    const old=vx;vx=approachVelocity(vx,desiredV,(airborne?430:Math.abs(desiredV)<Math.abs(vx)?1000:700)*scale(),dt);
    let next=x+(old+vx)*.5*dt;
    if(target!==null&&!airborne&&(target-x)*(target-next)<0&&Math.abs(target-x)<10*scale()){next=target;vx=0;}
    x=bound(next);
    if(x!==next){vx=0;if(!job){wander.direction=x<=0?1:-1;}}
    if(airborne||windup||landingLeft>0||turnTo||!locomotion)return;
    if(Math.abs(vx)<4&&Math.abs(desiredV)<4){if(mode==='brake'&&elapsed<.2)return;setMode('idle',3);}
    else if(job?.type==='play'&&job.phase==='return')setMode('carry',60);
    else if(Math.abs(desiredV)<Math.abs(old)-8){setMode('brake');}
    else if(Math.abs(old)<8&&Math.abs(desiredV)>10){setMode('start',.32,true);}
    else if(mode==='start'&&elapsed<.32)return;
    else setMode(Math.abs(vx)>120*scale()||movingKind==='run'?'run':'walk',60);
  }
  function updateSupport(now) {
    platforms.update(now);
    if(!support)return;
    const current=platforms.get(support.element);
    if(!current){support=null;airborne=true;vy=0;setMode('jump');return;}
    if(Math.abs(current.top-support.top)>130){support=null;airborne=true;vy=0;setMode('jump');return;}
    const dx=current.left-support.left;
    x=bound(x+dx);support=current;y=Math.max(0,current.top-114*scale());
    const foot=x+width()*.5;
    if(foot<current.left-5||foot>current.right+5){ignoreSupport=current.element;ignoreUntil=now+350;support=null;airborne=true;vy=0;setMode('jump');}
  }
  function integrateVertical(dt,now) {
    if(windup) {
      windup.left-=dt;
      if(windup.left<=0) {
        const jump=windup;windup=null;airborne=true;vy=jump.vy;
        if(jump.horizontal!==null){vx=clamp(jump.horizontal,-420*scale(),420*scale());if(Math.abs(vx)>10)facing=Math.sign(vx);}
        if(support){ignoreSupport=support.element;ignoreUntil=now+500;}support=null;setMode('launch',.15,true);spawnDust(3);
      }
    }
    if(!airborne)return;
    const before=y+114*scale();y+=vy*dt+600*dt*dt;vy+=1200*dt;
    if(y<0){y=0;vy=Math.max(0,vy);}
    let surface=null;
    if(state.platforms&&vy>=0)surface=landingSurface(before,y+114*scale(),x+width()/2,platforms.items.filter(p=>p.top>114*scale()+4&&(p.element!==ignoreSupport||now>ignoreUntil)),12*scale());
    if(surface||y>=floor()) {
      const impact=vy;const pad=!surface&&pads.find(p=>Math.abs(x+width()/2-p.x)<p.width/2-8);
      if(pad&&impact>260&&pad.cooldown<=0){y=floor();vy=-impact*.76;pad.pulse=.5;pad.cooldown=.2;pad.armed=false;setMode('launch',.15,true);return;}
      support=surface;y=surface?surface.top-114*scale():floor();airborne=false;vy=0;landingLeft=.42;
      landingSpring={value:clamp(impact/850,.25,1),velocity:0};setMode('land',.42,true);spawnDust(impact>500?7:4);saveScene();
    } else if(mode==='launch'&&elapsed>.15)setMode('jump');
    else if(mode==='bite'&&elapsed>.25)setMode('jump');
  }
  function stepPose(dt) {
    if(job.phase==='settle') {
      desiredV=0;
      if(Math.abs(vx)<5&&!turnTo&&!airborne&&landingLeft<=0) {
        job.phase='animate';job.elapsed=0;setMode(poseSequences[job.kind][0][0],poseSequences[job.kind][0][1],true);
      }
    } else {
      const clip=poseSequences[job.kind][job.index];job.elapsed+=dt;
      if(job.kind==='turn'&&job.elapsed>clip[1]/2&&!job.turned){facing*=-1;job.turned=true;}
      if(job.elapsed>=clip[1]) {
        job.index++;job.elapsed=0;
        if(job.index>=poseSequences[job.kind].length){job=null;wander={kind:'idle',left:2};setMode('idle',2);saveScene();}
        else {const next=poseSequences[job.kind][job.index];setMode(next[0],next[1],true);}
      }
    }
  }
  function wakeHome() {
    if(job?.type!=='home')return;
    job.phase='wake';job.elapsed=0;job.scheduled=false;setMode('wake',.7,true);say('醒来啦，先伸个大懒腰。');
  }
  function stepHome(dt) {
    if(job.phase==='approach') {
      if(driveTo(homeX(),115*scale())){job.phase='circle';job.elapsed=0;setMode('circle',1.3,true);}
    } else if(job.phase==='circle') {
      job.elapsed+=dt;
      desiredV=clamp((bound(homeX()+Math.sin(job.elapsed/1.3*Math.PI*2)*9*scale())-x)*8,-45*scale(),45*scale());
      if(job.elapsed>=1.3){job.phase='lie';job.elapsed=0;vx=0;x=homeX();setMode('lie',.7,true);}
    } else if(job.phase==='lie') {
      job.elapsed+=dt;if(job.elapsed>=.7){job.phase='sleep';job.elapsed=0;setMode('sleep',30,true);saveScene();}
    } else if(job.phase==='sleep') {
      job.elapsed+=dt;sleepElapsed+=dt;
      if(sleepElapsed>=15){sleepElapsed=0;request('rest');}
      if(!job.scheduled&&job.elapsed>=30)wakeHome();
    } else if(job.phase==='wake') {
      job.elapsed+=dt;if(job.elapsed>=.7){job.phase='stretch';job.elapsed=0;setMode('stretch',1.6,true);}
    } else if(job.phase==='stretch') {
      job.elapsed+=dt;if(job.elapsed>=1.6){job.phase='exit';job.elapsed=0;setMode('idle',.2);}
    } else if(job.phase==='exit') {
      if(driveTo(bound(homeX()-95*scale()),85*scale())) {
        job=null;target=null;wander={kind:'idle',left:2};setMode('idle',2);saveScene();
        const next=queuedAction;queuedAction=null;if(next)command(next);
      }
    }
  }
  async function finishFood(completed) {
    actionPending=true;const response=await request(completed.type,{key:completed.key,token:completed.token,eventId:completed.id||(completed.id=crypto.randomUUID())});actionPending=false;
    if(job!==completed||!state.enabled||!sync.active)return;
    const banana=completed.type==='banana',px=completed.foodX;cancelJob(false);
    if(banana&&response.ok)addPeel(px);
    startPose('happy');say(response.message||'吃饱啦！',4);if(response.ok)hearts();saveScene();
  }
  async function finishReturn(completed) {
    actionPending=true;const response=await request('play',{toy:completed.toy||'ball',eventId:completed.id||(completed.id=crypto.randomUUID())});actionPending=false;
    if(job!==completed||!state.enabled||!sync.active)return;
    cancelJob(true,true);freeBallUntil=performance.now()+12000;startPose('happy');
    say(response.ok?'球叼回来啦，放在你脚边！':response.message,4);if(response.ok)hearts();saveScene();
  }
  function planBall(dt) {
    job.jumpCooldown=Math.max(0,job.jumpCooldown-dt);
    if(job.phase==='chase'&&ball) {
      const predicted=stepBall(ball,.1,ballBounds());
      const direction=predicted.x>=x+width()/2?1:-1;
      driveTo(bound(predicted.x-width()*(direction===1?.87:.13)),330*scale(),direction);
      const m=mouth(),above=m.y-ball.y;
      if(!airborne&&!windup&&landingLeft<=0&&job.jumpCooldown===0&&Math.abs(ball.x-m.x)<155*scale()&&above>22*scale()&&above<220*scale()) {
        if(beginJump(clamp(above+38,65*scale(),205*scale())))job.jumpCooldown=.9;
      }
      job.elapsed+=dt;
      if(job.elapsed>55){cancelJob();wander={kind:'idle',left:3};say('让我喘口气，再抛一次吧。');}
    } else if(job.phase==='pickup') {
      desiredV=0;job.elapsed+=dt;
      if(job.elapsed>=.55){job.phase='caught';job.elapsed=0;setMode('bite',.25,true);}
    } else if(job.phase==='caught') {
      job.elapsed+=dt;
      desiredV=0;
      if(job.elapsed>=.25&&!airborne&&landingLeft<=0){job.phase='return';setMode('idle',.2);say('接住啦！叼回来给你。');}
    } else if(job.phase==='return') {
      if(driveTo(job.returnX,125*scale())){job.phase='drop';job.elapsed=0;job.released=false;setMode('drop',.6,true);}
    } else if(job.phase==='drop') {
      job.elapsed+=dt;
      if(job.elapsed>.36&&!job.released){job.released=true;if(ball){ball.vx=facing*24;ball.vy=40;ball.grounded=false;ball.spin=0;}}
      if(job.elapsed>1.1&&ball?.grounded){job.phase='saving';finishReturn(job);}
    }
  }
  function afterBall(previousBall,previousMouth) {
    if(!ball||job?.type!=='play')return;
    if(job.phase==='chase') {
      const m=mouth();
      const hit=airborne&&sweptHit(previousBall,ball,previousMouth,m,ball.radius+19*scale());
      const scoop=!airborne&&!turnTo&&!windup&&landingLeft<=0&&ball.grounded&&Math.abs(ball.x-m.x)<37*scale();
      if(hit||scoop){job.phase=hit?'caught':'pickup';job.elapsed=0;ballNode.dataset.caught='true';setMode(hit?'bite':'drop',hit?.25:.55,true);}
    }
    if(['caught','return'].includes(job.phase)||(job.phase==='pickup'&&job.elapsed>.2)||(job.phase==='drop'&&!job.released)) {
      const m=mouth();ball.x=m.x;ball.y=m.y;ball.vx=0;ball.vy=0;ball.spin=0;
    }
  }
  function choose() {
    target=null;
    if(state.energy<22){goHome(false);return;}
    const personality=GoldenCore.profile(state),r=Math.random();
    if(state.hunger<40&&state.personality==='foodie'&&r<.35){startPose('sniff');return;}
    if(state.personality==='clingy'&&r<.18){job={type:'follow',elapsed:0};say('跟着你走一小会儿。');return;}
    if(state.platforms&&r<.10&&platforms.reachable(x+width()/2,y+114*scale(),scale())){startPerch();return;}
    if(r<.44)wander={kind:'walk',left:4+Math.random()*5,direction:Math.random()<.5?-1:1};
    else if(r<.44+personality.runChance)wander={kind:'run',left:2+Math.random()*3,direction:Math.random()<.5?-1:1};
    else if(r<.94){const names=['blink','look','sniff','yawn','stretch','sit'];startPose(names[Math.floor(Math.random()*names.length)]);}
    else goHome(false);
  }
  async function checkRoutine(now) {
    if(!ready||!sync.active||routinePending||!state.enabled||state.paused||document.hidden)return;
    reconcileClock();
    const due=routine(state);
    if(job?.type==='home'&&job.scheduled&&due.kind!=='sleep')wakeHome();
    if(now<manualUntil||job||placement||drag||airborne||windup||slip||actionPending)return;
    if(due.kind==='sleep'){goHome(true);return;}
    if(due.kind==='meal') {
      routinePending=true;const token=crypto.randomUUID(),started=epoch;const response=await request('claimMeal',{key:due.key,token});routinePending=false;
      if(!response.ok)return;
      if(epoch!==started||job||!state.enabled||state.paused||document.hidden||placement){request('releaseMeal',{token});return;}
      showFood('meal',homeFoodX(),{scheduled:true,key:due.key,token});
    }
  }
  function stepIntent(dt) {
    desiredV=0;target=null;
    if(job?.type==='training'){stepTraining(dt);return;}
    if(job?.type==='tug'){stepTug(dt);return;}
    if(job?.type==='follow'){job.elapsed+=dt;driveTo(bound(cursor.x-width()/2),65*scale());if(job.elapsed>12){cancelJob();wander={kind:'idle',left:3};}return;}
    if(job?.type==='pose'){stepPose(dt);return;}
    if(job?.type==='home'){stepHome(dt);return;}
    if(job?.type==='play'){planBall(dt);return;}
    if(job?.type==='hop') {
      if(job.phase==='settle'&&Math.abs(vx)<5&&!airborne&&landingLeft<=0){job.phase='flight';beginJump(85*scale(),0,'happy');}
      else if(job.phase==='flight'&&!airborne&&!windup&&landingLeft<=0){job=null;startPose('happy');hearts();}
      return;
    }
    if(job?.type==='perch'){stepPerch(dt);return;}
    if(job) {
      if(job.phase==='approach'&&!airborne&&!windup&&landingLeft<=0) {
        const destination=foodTarget(job.foodX);
        if(driveTo(destination,(job.type==='banana'?260:115)*scale(),job.foodX>=x+width()/2?1:-1)){job.phase='interact';job.elapsed=0;setMode('eat',2.4,true);}
      } else if(job.phase==='interact') {
        job.elapsed+=dt;if(job.elapsed>=2.4){job.phase='saving';finishFood(job);}
      }
      return;
    }
    if(airborne){desiredV=vx;return;}
    inviteLeft-=dt;if(inviteLeft<=0){inviteLeft=state.personality==='energetic'?100:160;const toy=GoldenCore.profile(state).favorite;say(state.hunger<40?'肚子有一点饿，有空喂我一口吧。':`想和你玩${{ball:'小球',frisbee:'飞盘',tug:'拔河'}[toy]}，有空就叫我！`,5);startPose(state.hunger<40?'sniff':'happy');return;}
    wander.left-=dt;
    if(wander.kind==='walk'||wander.kind==='run')desiredV=(wander.direction||facing)*(wander.kind==='run'?180:50)*scale()*(reducedMotion.matches?.6:1)*GoldenCore.profile(state).speed;
    if(wander.left<=0)choose();
  }
  function tick(now) {
    raf=0;const delta=last?Math.min((now-last)/1000,.25):0;last=now;
    if(!state.enabled||document.hidden||disposed){last=0;return;}
    if(!ready){render();schedule();return;}
    actor.dataset.job=job?.type||'none';actor.dataset.phase=job?.phase||'none';
    if(sync.active&&!state.paused&&menu.hidden&&!placement&&!actionPending) {
      if(!drag)updateSupport(now);
      // Keep motion and animation time together on a busy page. Small steps keep
      // collisions stable, while a bounded catch-up avoids a long main-thread task.
      let budget=delta;
      while(budget>1e-6&&!actionPending) {
        const dt=Math.min(budget,1/60);budget-=dt;
        elapsed+=dt;remaining=Math.max(0,remaining-dt);
        if(!drag) {
          const oldX=x,oldMouth=mouth(),oldBall=ball?{...ball}:null;
          if(ball&&(job?.phase==='chase'||(job?.phase==='drop'&&job.released)||job?.type!=='play'))ball=stepBall(ball,dt,ballBounds());
          if(slip)stepSlip(dt);
          else {
            landingLeft=Math.max(0,landingLeft-dt);landingSpring=springStep(landingSpring,dt);
            if(landingLeft===0&&mode==='land')setMode('idle',.2);
            stepIntent(dt);
            integrateHorizontal(dt);integrateVertical(dt,now);
            if(support){const feet=x+width()/2;if(feet<support.left||feet>support.right){ignoreSupport=support.element;ignoreUntil=now+400;support=null;airborne=true;vy=0;setMode('jump');}}
            afterBall(oldBall,oldMouth);checkPeels(oldX);footstep(x-oldX);
          }
          stepWorldToys(dt,oldBall);
          if(freeBallUntil&&now>freeBallUntil&&job?.type!=='play'){ball=null;ballNode.hidden=true;freeBallUntil=0;}
        }
        stepParticles(dt);
      }
    }
    if(now>=routineCheck){routineCheck=now+5000;checkRoutine(now);}
    if(placement==='perch'&&now>=platforms.next)drawAim();
    
    if(!speech.hidden&&now>speechUntil)speech.hidden=true;
    render();schedule();
  }
  function positionProps() {
    if(job&&['feed','banana','meal'].includes(job.type)){
      const banana=job.type==='banana';prop.style.left=`${job.foodX-(banana?24:20)}px`;prop.style.top=`${ground()-(banana?48:24)}px`;
    }
    for(const peel of peels){peel.node.style.left=`${peel.x-24}px`;peel.node.style.top=`${ground()-48}px`;peel.node.dataset.armed=String(peel.armed);}
    if(ball){ballNode.classList.toggle('frisbee',ball.kind==='frisbee');ballNode.style.left=`${ball.x-(ball.kind==='frisbee'?16:11)}px`;ballNode.style.top=`${ball.y-(ball.kind==='frisbee'?6:11)}px`;ballNode.style.transform=`rotate(${ball.angle||0}rad)`;if(ballNode.dataset.bounces!==String(ball.bounces))ballNode.dataset.bounces=String(ball.bounces);}
  }
  function positionUI() {
    speech.style.left=`${clamp(x+width()/2-110,8,Math.max(8,innerWidth-248))}px`;speech.style.top=`${Math.max(8,y-26)}px`;
    if(!menu.hidden){const h=menu.offsetHeight;menu.style.left=`${clamp(x+width()/2-130,8,Math.max(8,innerWidth-268))}px`;menu.style.top=`${clamp(y-h-8,8,Math.max(8,innerHeight-h-8))}px`;}
  }
  function render() {
    if(actor.dataset.state!==mode)actor.dataset.state=mode;
    actor.dataset.airborne=String(airborne);actor.dataset.support= support?'platform':'floor';
    actor.dataset.speed=String(Math.round(vx));
    actor.style.transform=`translate3d(${x.toFixed(1)}px,${y.toFixed(1)}px,0) scale(${scale()})`;
    const squash=Math.max(-.16,Math.min(1,landingSpring.value));
    sprite.style.transform=`scale(${facing*(1+squash*.15)},${1-squash*.2})`;
    sprite.style.transformOrigin='50% 89%';
    const animation=GOLDEN_ANIMATIONS[mode]||GOLDEN_ANIMATIONS.idle;
    const fps=['walk','run','carry','start'].includes(mode)?clamp(Math.abs(vx)/scale()/12,5,20):['eat','jump','drag'].includes(mode)?10:6;
    let next=animation.loop?Math.floor(elapsed*fps)%8:Math.min(7,Math.floor(elapsed/Math.max(.1,durations[mode]||1)*8));
    if(state.paused)next=Math.max(0,frame);
    else if(reducedMotion.matches)next=animation.loop?0:Math.min(7,next);
    if(frame!==next||sprite.dataset.mode!==mode){frame=next;sprite.dataset.mode=mode;sprite.style.backgroundPosition=`${-frame*160}px ${-animation.row*128}px`;}
    const lift=Math.max(0,(support?support.top:ground())-(y+114*scale()));
    const shadowScale=clamp(1-lift/(400*scale()),.28,1);
    petShadow.style.left=`${x+width()*.12}px`;petShadow.style.top=`${(support?support.top:ground())-5}px`;
    petShadow.style.width=`${width()*.76}px`;petShadow.style.transform=`scale(${shadowScale},${shadowScale})`;petShadow.style.opacity=String(.2*shadowScale);
    kennel.style.transform=`scale(${scale()})`;
    const activity=job?.type==='home'?job.phase==='sleep'?'sleep':job.phase:job?.type==='meal'?'meal':'free';
    if(kennel.dataset.activity!==activity)kennel.dataset.activity=activity;
    const label=state.paused?'已暂停':activity==='sleep'?'Z z z …':activity==='meal'?'开饭啦':state.scheduleEnabled?'按时吃饭，好好睡觉':'自在的小家';
    if(homeStatus.textContent!==label)homeStatus.textContent=label;
    positionProps();positionUI();paintEffects();paintToys();
  }
  function schedule(){if(!raf&&!disposed&&state.enabled&&!document.hidden)raf=requestAnimationFrame(tick);}
  function reconcileClock(savedAt=null){
    const wall=Date.now(),mono=performance.now();
    const jump=savedAt===null?Math.abs((wall-clockWall)-(mono-clockMono))>120000:Math.abs(wall-savedAt)>120000;
    clockWall=wall;clockMono=mono;
    if(jump){manualUntil=0;if(job?.type==='home'&&!job.scheduled&&['sleep','lie'].includes(job.phase))wakeHome();}
  }
  function captureScene(){
    reconcileClock();
    if(job&&!job.id)job.id=crypto.randomUUID();
    const now=performance.now();
    return GoldenScene.sanitize({schema:2,viewport:{w:previousWidth,h:previousHeight,scale:previousScale},
      pet:{x,y,vx,vy,facing,mode,elapsed,remaining,airborne:airborne||!!drag?.moved,turnTo,landingLeft,sleepElapsed,manualLeft:Math.max(0,(manualUntil-now)/1000),freeBallLeft:Math.max(0,(freeBallUntil-now)/1000),inviteLeft},
      job,target,wander,windup,spring:landingSpring,slip,support,ball,peels:peels.map(p=>({id:p.id,x:p.x,armed:p.armed})),
      placement,aim:aimPoint,queuedAction,toys:{pads,blocks,rope}});
  }
  function restoreScene(raw){
    const s=GoldenScene.sanitize(raw);if(!s)return;
    const old=s.viewport,rx=innerWidth/old.w,ry=innerHeight/old.h;
    const sx=value=>value*rx,sy=value=>value*ry;
    const oldTravel=Math.max(1,old.w-160*old.scale),newTravel=Math.max(0,innerWidth-width());
    const p=s.pet;x=bound(p.x/oldTravel*newTravel);
    const lift=(old.h-12-114*old.scale)-p.y;y=clamp(floor()-lift*ry,0,floor());
    vx=clamp(p.vx*rx,-650*scale(),650*scale());vy=clamp(p.vy*ry,-1000,1000);facing=p.facing===-1?-1:1;
    mode=GOLDEN_ANIMATIONS[p.mode]?p.mode:'idle';elapsed=p.elapsed||0;remaining=p.remaining||0;frame=-1;
    airborne=!!p.airborne;turnTo=p.turnTo||0;landingLeft=p.landingLeft||0;sleepElapsed=p.sleepElapsed||0;
    manualUntil=performance.now()+(p.manualLeft||0)*1000;freeBallUntil=p.freeBallLeft?performance.now()+p.freeBallLeft*1000:0;inviteLeft=p.inviteLeft??90;
    job=s.job;target=s.target===null?null:bound(s.target/oldTravel*newTravel);wander=s.wander;windup=s.windup;landingSpring=s.spring;slip=s.slip;
    if(windup){windup.vy*=ry;if(Number.isFinite(windup.horizontal))windup.horizontal*=rx;else windup.horizontal=null;}
    if(slip)slip.slideVelocity*=rx;
    if(job){for(const k of ['foodX'])if(Number.isFinite(job[k]))job[k]=sx(job[k]);
      for(const k of ['returnX','destination','anchor'])if(Number.isFinite(job[k]))job[k]=bound(job[k]/oldTravel*newTravel);
      if(Number.isFinite(job.jumpVX))job.jumpVX*=rx;
      if(job.route)job.route=job.route.map(r=>({left:sx(r.left),right:sx(r.right),top:sy(r.top)}));
      if(job.phase==='saving'){job.phase=job.type==='play'?'drop':job.type==='training'?'reward':job.type==='tug'?'retry':'interact';job.elapsed=job.type==='play'?2:3;}
    }
    ball=s.ball;if(ball){ball.x=clamp(sx(ball.x),ball.radius,innerWidth-ball.radius);ball.y=clamp(sy(ball.y),ball.radius,ground()-ball.radius);ball.vx*=rx;ball.vy*=ry;}
    for(const peel of peels)peel.node.remove();peels=[];if(hitPeel){hitPeel.node.remove();hitPeel=null;}
    for(const peel of s.peels){addPeel(sx(peel.x),peel.id);peels.at(-1).armed=peel.armed;}
    pads=s.toys.pads.map(p=>({...p,x:clamp(sx(p.x),60,innerWidth-60)}));
    blocks=s.toys.blocks.map(b=>({...b,x:clamp(sx(b.x),0,innerWidth-b.w),y:clamp(sy(b.y),0,ground()-b.h),vx:b.vx*rx,vy:b.vy*ry}));
    rope=s.toys.rope;if(rope){rope.x=sx(rope.x);rope.y=sy(rope.y);rope.held=false;}
    platforms.update(performance.now());support=s.support?platforms.match({left:sx(s.support.left),right:sx(s.support.right),top:sy(s.support.top)}):null;
    if(support)y=support.top-114*scale();else if(s.support){airborne=true;vy=Math.max(0,vy);setMode('jump');}
    queuedAction=s.queuedAction;drag=null;aimDrag=null;reconcileClock(s.savedAt);
    placement=s.placement;aim.hidden=!placement;aimPoint=s.aim?{x:sx(s.aim.x),y:sy(s.aim.y)}:{x:innerWidth/2,y:innerHeight/2};
    if(placement)refreshAimText();
    prop.hidden=!job||!['feed','banana','meal'].includes(job.type);
    if(!prop.hidden){prop.className=job.type==='banana'?'banana':'bowl';prop.style.backgroundImage=job.type==='banana'?itemsImage:'';}
    ballNode.hidden=!ball;ballNode.dataset.caught=String(!!ball&&job?.type==='play'&&job.phase!=='chase');
    previousWidth=innerWidth;previousHeight=innerHeight;previousScale=scale();last=0;render();
  }
  function restoreLegacy(s){x=bound(s.x*Math.max(0,innerWidth-width()));facing=s.facing;y=floor();setMode('idle',3);}
  function releaseTransient(){
    if(drag){const moved=drag.moved;releaseDrag();if(moved){airborne=true;vy=0;setMode('jump');}}
    if(rope)rope.held=false;aimDrag=null;
  }
  const sync=new GoldenSync({capture:captureScene,restore:restoreScene,legacy:restoreLegacy,release:releaseTransient,
    owner:active=>{actor.dataset.active=String(active);last=0;if(ready){render();schedule();}}});
  function saveScene(){if(ready)return sync.checkpoint();}
  function resize(){
    const scene=captureScene();releaseTransient();platforms.invalidate();restoreScene(scene);routineCheck=0;saveScene();
  }
  window.addEventListener('resize',resize,{passive:true});
  window.addEventListener('scroll',()=>platforms.invalidate(),{passive:true,capture:true});
  document.addEventListener('visibilitychange',()=>{
    if(document.hidden){releaseTransient();saveScene();cancelAnimationFrame(raf);raf=0;last=0;}
    else {routineCheck=0;request('get').then(()=>sync.acquire());schedule();}
  });
  window.addEventListener('focus',()=>{if(ready)sync.acquire();});
  window.addEventListener('blur',()=>{if(ready){releaseTransient();saveScene();}});
  const refresh=setInterval(()=>{if(state.enabled&&!document.hidden)request('get');},60000);
  window.addEventListener('pagehide',e=>{releaseTransient();saveScene();cancelAnimationFrame(raf);raf=0;last=0;if(!e.persisted){disposed=true;clearInterval(refresh);sync.close();observer.disconnect();rootObserver.disconnect();}});
  window.addEventListener('pageshow',()=>{routineCheck=0;if(ready)sync.acquire();schedule();});
  let repairTimer=0;
  function ensureHost(){if(disposed||host.isConnected||repairTimer)return;repairTimer=setTimeout(()=>{repairTimer=0;if(!disposed&&!host.isConnected&&document.documentElement){document.documentElement.append(host);rootObserver.disconnect();rootObserver.observe(document.documentElement,{childList:true});}},100);}
  const observer=new MutationObserver(ensureHost),rootObserver=new MutationObserver(ensureHost);
  observer.observe(document,{childList:true});rootObserver.observe(document.documentElement,{childList:true});
  y=floor();request('get').then(async()=>{previousScale=scale();await sync.start();ready=true;world.style.opacity='1';say(`汪！${state.name}在这里接着陪你。`,3);routineCheck=0;schedule();});
})();
