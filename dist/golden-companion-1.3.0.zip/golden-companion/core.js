/* Shared pure state logic; no page data or network access. */
(() => {
  const clamp = (n, min = 0, max = 100) => Math.max(min, Math.min(max, n));
  const defaults = (now = Date.now()) => ({
    version: 4, name: '糯米', enabled: true, paused: false, size: 100,
    effects: true, platforms: false, continuity: true, personality:'gentle', bond:0, xp:0,
    training:{recall:0,shake:0,wait:0,playdead:0}, habits:{ball:0,frisbee:0,tug:0}, lastTrain:0, completedEvents:[],
    hunger: 76, mood: 84, energy: 90, feeds: 0, pets: 0, games: 0,
    updatedAt: now, lastFeed: 0, lastPet: 0, lastPlay: 0, lastRest: 0,
    bananas: 0, scheduleEnabled: true, mealTimes: ['08:00', '18:00'],
    sleepStart: '22:00', wakeTime: '07:00', mealHistory: [],
    mealClaimKey: '', mealClaimToken: '', mealClaimUntil: 0
  });
  const validTime = value => typeof value === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(value);
  const minutesOf = time => Number(time.slice(0, 2)) * 60 + Number(time.slice(3));
  function normalize(raw = {}, now = Date.now()) {
    const s = defaults(now);
    if (!raw || typeof raw !== 'object') return s;
    for (const key of ['hunger', 'mood', 'energy']) {
      if (Number.isFinite(raw[key])) s[key] = clamp(raw[key]);
    }
    for (const key of ['feeds', 'pets', 'games', 'bananas', 'updatedAt', 'lastFeed', 'lastPet', 'lastPlay', 'lastRest', 'mealClaimUntil']) {
      if (Number.isFinite(raw[key])) s[key] = Math.max(0, raw[key]);
    }
    s.updatedAt = Math.min(now, s.updatedAt);
    s.personality=['gentle','energetic','clingy','foodie'].includes(raw.personality)?raw.personality:'gentle';
    s.bond=Number.isFinite(raw.bond)?clamp(raw.bond):0;s.xp=Number.isFinite(raw.xp)?clamp(raw.xp,0,100000):0;
    s.lastTrain=Number.isFinite(raw.lastTrain)?Math.min(now,Math.max(0,raw.lastTrain)):0;
    for(const k of Object.keys(s.training))s.training[k]=Number.isFinite(raw.training?.[k])?clamp(raw.training[k]):0;
    for(const k of Object.keys(s.habits))s.habits[k]=Number.isFinite(raw.habits?.[k])?clamp(raw.habits[k],0,100000):0;
    s.completedEvents=Array.isArray(raw.completedEvents)?raw.completedEvents.filter(v=>typeof v==='string'&&v.length<=120).slice(-128):[];
    s.name = typeof raw.name === 'string' ? [...raw.name.trim()].slice(0, 12).join('') || '糯米' : s.name;
    s.enabled = typeof raw.enabled === 'boolean' ? raw.enabled : s.enabled;
    s.paused = typeof raw.paused === 'boolean' ? raw.paused : s.paused;
    for (const key of ['effects', 'platforms']) if (typeof raw[key] === 'boolean') s[key] = raw[key];
    s.size = Number.isFinite(raw.size) ? clamp(raw.size, 70, 150) : s.size;
    s.scheduleEnabled = typeof raw.scheduleEnabled === 'boolean' ? raw.scheduleEnabled : true;
    if (Array.isArray(raw.mealTimes) && raw.mealTimes.length === 2 && raw.mealTimes.every(validTime) && raw.mealTimes[0] !== raw.mealTimes[1]) s.mealTimes = [...raw.mealTimes].sort();
    if (validTime(raw.sleepStart)) s.sleepStart = raw.sleepStart;
    if (validTime(raw.wakeTime)) s.wakeTime = raw.wakeTime;
    if (s.sleepStart === s.wakeTime) { s.sleepStart = '22:00'; s.wakeTime = '07:00'; }
    if (Array.isArray(raw.mealHistory)) s.mealHistory = [...new Set(raw.mealHistory.filter(k => typeof k === 'string' && /^\d{4}-\d{2}-\d{2}\|\d{2}:\d{2}$/.test(k)))].slice(-8);
    for (const key of ['mealClaimKey', 'mealClaimToken']) if (typeof raw[key] === 'string') s[key] = raw[key].slice(0, 80);
    return s;
  }
  // Local civil time, including midnight and changes of system time zone.
  function routine(raw, date = new Date()) {
    const s = normalize(raw, date.getTime());
    if (!s.scheduleEnabled) return { kind: 'free' };
    const minute = date.getHours() * 60 + date.getMinutes();
    const day = [date.getFullYear(), String(date.getMonth()+1).padStart(2,'0'), String(date.getDate()).padStart(2,'0')].join('-');
    for (const time of [...s.mealTimes].reverse()) {
      const elapsed = minute - minutesOf(time), key = `${day}|${time}`;
      if (elapsed >= 0 && elapsed < 60 && !s.mealHistory.includes(key)) return { kind: 'meal', key, time };
    }
    const start = minutesOf(s.sleepStart), end = minutesOf(s.wakeTime);
    const sleeping = start > end ? minute >= start || minute < end : minute >= start && minute < end;
    return { kind: sleeping ? 'sleep' : 'free' };
  }
  function advance(raw, now = Date.now()) {
    const s = normalize(raw, now);
    // Offline time is capped; the pet never dies and sleep restores energy.
    const minutes = Math.min(120, Math.max(0, now - s.updatedAt) / 60000);
    if (s.enabled && !s.paused) {
      s.hunger = clamp(s.hunger - minutes * 0.18, 15);
      s.mood = clamp(s.mood - minutes * 0.10, 25);
      s.energy = clamp(s.energy + minutes * 0.12);
    }
    s.updatedAt = now;
    return s;
  }
  function update(raw, action, payload = {}, now = Date.now()) {
    const s = advance(raw, now);
    let ok = true, message = '';
    switch (action) {
      case 'settings': {
        for (const key of ['name', 'enabled', 'paused', 'size', 'effects', 'platforms', 'personality', 'scheduleEnabled', 'mealTimes', 'sleepStart', 'wakeTime']) {
          if (Object.hasOwn(payload, key)) s[key] = payload[key];
        }
        break;
      }
      case 'feed':
      case 'banana':
        if (now - s.lastFeed < 8000) { ok = false; message = '刚吃过啦，等一小会儿再喂～'; break; }
        s.hunger = clamp(s.hunger + (action === 'banana' ? 12 : 18)); s.mood = clamp(s.mood + 5); s.feeds++; s.lastFeed = now;
        if (action === 'banana') s.bananas++;
        message = action === 'banana' ? '香蕉真甜！咦，地上留了一块皮…' : '咔嚓咔嚓，好香！'; break;
      case 'claimMeal': {
        const due = routine(s, new Date(now));
        if (!s.enabled || s.paused || due.kind !== 'meal' || due.key !== payload.key || typeof payload.token !== 'string' || !payload.token || payload.token.length > 80 || s.mealClaimUntil > now) { ok = false; break; }
        s.mealClaimKey = due.key; s.mealClaimToken = payload.token; s.mealClaimUntil = now + 90000; break;
      }
      case 'releaseMeal':
        if (payload.token === s.mealClaimToken) { s.mealClaimKey = ''; s.mealClaimToken = ''; s.mealClaimUntil = 0; }
        break;
      case 'meal':
        if (!s.scheduleEnabled || s.mealClaimKey !== payload.key || s.mealClaimToken !== payload.token || !payload.token || s.mealClaimUntil < now || s.mealHistory.includes(payload.key)) { ok = false; message = '这餐已经吃过啦，去休息吧。'; break; }
        s.mealHistory = [...s.mealHistory, payload.key].slice(-8);
        s.mealClaimKey = ''; s.mealClaimToken = ''; s.mealClaimUntil = 0;
        s.hunger = clamp(s.hunger + 24); s.energy = clamp(s.energy + 5); s.feeds++;
        message = '在家吃饱了，心里暖暖的。'; break;
      case 'pet':
        if (now - s.lastPet < 1500) { ok = false; message = '最喜欢你的摸摸了 ♡'; break; }
        s.mood = clamp(s.mood + 7); s.pets++; s.lastPet = now;
        message = '最喜欢你的摸摸了 ♡'; break;
      case 'play':
        if (now - s.lastPlay < 5000) { ok = false; message = '让我喘口气，再玩一次！'; break; }
        if (s.energy < 12) { ok = false; message = '有点累啦，先让我睡一会儿～'; break; }
        s.mood = clamp(s.mood + 10); s.energy = clamp(s.energy - 8); s.games++; s.lastPlay = now;
        message = '捡到啦！再陪我玩一次吧'; break;
      case 'rest':
        if (now - s.lastRest >= 15000) { s.energy = clamp(s.energy + 8); s.lastRest = now; }
        break;
      case 'trainReward':
        if(!Object.hasOwn(s.training,payload.skill)||now-s.lastTrain<10000){ok=false;message='先消化一下刚学到的本领吧。';break;}
        s.training[payload.skill]=clamp(s.training[payload.skill]+(payload.coached?8:16));s.lastTrain=now;
        s.hunger=clamp(s.hunger+3);s.mood=clamp(s.mood+5);message='奖励收到！这个本领又熟练了一点。';break;
      case 'get': break;
      default: return { ok: false, message: '未知操作', state: s };
    }
    if(ok&&['feed','banana','pet','play','trainReward'].includes(action)){
      s.bond=clamp(s.bond+(action==='pet'?2:1));s.xp+=action==='trainReward'?12:action==='play'?8:3;
      if(action==='play'){const toy=['ball','frisbee','tug'].includes(payload.toy)?payload.toy:'ball';s.habits[toy]++;}
    }
    return { ok, message, state: normalize(s, now) };
  }
  const sceneModes = ['idle','walk','run','sit','look','sniff','yawn','stretch','pet','belly','happy','sleep'];
  function sanitizeScene(raw, now = Date.now()) {
    if (!raw || typeof raw !== 'object' || !Number.isFinite(raw.x)) return null;
    return { x:clamp(raw.x,0,1), lift:Number.isFinite(raw.lift)?clamp(raw.lift,0,.8):0,
      facing:raw.facing===-1?-1:1, mode:sceneModes.includes(raw.mode)?raw.mode:'idle',
      remaining:Number.isFinite(raw.remaining)?clamp(raw.remaining,.2,30):3,
      savedAt:Math.min(now,Number.isFinite(raw.savedAt)?Math.max(0,raw.savedAt):now) };
  }
  function profile(raw){const s=normalize(raw),favorite=Object.keys(s.habits).sort((a,b)=>s.habits[b]-s.habits[a])[0];return {level:Math.min(50,1+Math.floor(s.xp/100)),favorite:s.habits[favorite]?favorite:'ball',speed:s.personality==='energetic'?1.18:s.personality==='gentle'?.9:1,runChance:s.personality==='energetic'?.4:.2,follow:s.personality==='clingy'};}
  const api = { profile, clamp, defaults, normalize, advance, update, routine, validTime, sanitizeScene };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else globalThis.GoldenCore = api;
})();
