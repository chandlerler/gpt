/* Deterministic viewport physics, shared by the live toy and trajectory preview. */
(() => {
  const clamp = (n, min, max) => Math.max(min, Math.min(max, n));
  function launch(start, end, direction = 1, kind = 'ball') {
    const dx = end.x - start.x, dy = end.y - start.y;
    const click = Math.hypot(dx, dy) < 12;
    return { kind, x: start.x, y: start.y, vx: click ? direction * 420 : clamp(dx * 4, -1050, 1050),
      vy: click ? -580 : clamp(dy * 4, -1050, 1050), radius: kind==='frisbee'?16:11, bounces: 0, grounded: false, angle:0, spin:0 };
  }
  function stepBall(input, dt, bounds) {
    const b = { angle:0,spin:0,...input }, r = b.radius;
    const right = Math.max(r, bounds.width - r), bottom = Math.max(r, bounds.height - r);
    const count = Math.max(1, Math.ceil(Math.min(dt, .1) / (1 / 120))), step = Math.min(dt, .1) / count;
    for (let i = 0; i < count; i++) {
      const gravity=b.kind==='frisbee'?Math.max(100,370-Math.abs(b.vx)*.22):900;
      if(b.kind==='frisbee'&&!b.grounded)b.vx*=Math.exp(-.18*step);
      b.x += b.vx * step;
      if (!b.grounded) { b.y += b.vy * step + gravity/2 * step * step; b.vy += gravity * step; }
      else b.vx *= Math.exp(-2.2 * step);
      const rolling = b.vx / r*(b.kind==='frisbee'?1.6:1);
      b.spin += (rolling-b.spin)*Math.min(1,step*(b.grounded?24:3));
      b.angle += b.spin*step;
      if (b.x < r) { b.x = r; if (b.vx < 0) { b.vx *= -.82; b.bounces++; } }
      if (b.x > right) { b.x = right; if (b.vx > 0) { b.vx *= -.82; b.bounces++; } }
      if (b.y < r) { b.y = r; if (b.vy < 0) { b.vy *= -.8; b.bounces++; } }
      if (b.y >= bottom) {
        b.y = bottom;
        if (b.vy > 0) { b.bounces++; b.vy *= -.72; b.vx *= .87; }
        if (Math.abs(b.vy) < 75) { b.vy = 0; b.grounded = true; }
      }
    }
    return b;
  }
  function sweptHit(a0, a1, b0, b1, radius) {
    const x = a0.x - b0.x, y = a0.y - b0.y;
    const dx = a1.x - b1.x - x, dy = a1.y - b1.y - y;
    const length = dx * dx + dy * dy;
    const t = length ? clamp(-(x * dx + y * dy) / length, 0, 1) : 0;
    return Math.hypot(x + dx * t, y + dy * t) <= radius;
  }
  function approachVelocity(current, desired, acceleration, dt) {
    return current + Math.sign(desired-current)*Math.min(Math.abs(desired-current),acceleration*dt);
  }
  function targetVelocity(distance, speed, braking = 650) {
    return Math.sign(distance)*Math.min(speed,Math.sqrt(2*braking*Math.max(0,Math.abs(distance)-1)));
  }
  function toss(samples, now, scale = 1) {
    const recent=samples.filter(s=>now-s.t<=140);
    if(recent.length<2 || now-recent.at(-1).t>90)return {vx:0,vy:0};
    const first=recent[0],last=recent.at(-1),seconds=(last.t-first.t)/1000;
    if(seconds<.012)return {vx:0,vy:0};
    return {vx:clamp((last.x-first.x)/seconds*.7,-460*scale,460*scale),vy:clamp((last.y-first.y)/seconds*.55,-540*scale,450*scale)};
  }
  function landingSurface(beforeFeet, afterFeet, center, platforms, halfFoot = 12) {
    if(afterFeet<beforeFeet)return null;
    return platforms.filter(p=>p.top>=beforeFeet-.5&&p.top<=afterFeet+.5&&center+halfFoot>p.left&&center-halfFoot<p.right)
      .sort((a,b)=>a.top-b.top)[0] || null;
  }
  function slipProfile(speed, scale=1) {
    const v=Math.abs(speed)/scale;
    return { tumble:v>125, slideVelocity:clamp(speed*1.12,-410*scale,410*scale), dizzy:v>125?.65:.25 };
  }
  function springStep(s, dt) {
    let value=s.value,velocity=s.velocity;
    const steps=Math.max(1,Math.ceil(dt*120)),d=dt/steps;
    for(let i=0;i<steps;i++){velocity+=(-180*value-19*velocity)*d;value+=velocity*d;}
    return {value,velocity};
  }
  const api = { launch, stepBall, sweptHit, approachVelocity, targetVelocity, toss, landingSurface, slipProfile, springStep };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else globalThis.GoldenPhysics = api;
})();
