/* Opt-in visible geometry only; no page text, form values, URLs or selectors saved. */
(() => {
  class Platforms {
    constructor(host){this.host=host;this.items=[];this.enabled=false;this.dirty=true;this.next=0;}
    invalidate(){this.dirty=true;}
    measure(node){
      if(!node?.isConnected||this.host.contains(node))return null;
      const r=node.getBoundingClientRect(),css=getComputedStyle(node);
      if(r.width<48||r.height<8||r.width>innerWidth*.99||r.top<125||r.top>innerHeight-25||css.visibility==='hidden'||css.display==='none'||Number(css.opacity)<.05)return null;
      if(css.transform!=='none'){try{const m=new DOMMatrix(css.transform);if(Math.abs(m.b)>.02||Math.abs(m.c)>.02)return null;}catch{return null;}}
      let left=Math.max(12,r.left),right=Math.min(innerWidth-12,r.right);
      for(let p=node.parentElement;p&&p!==document.documentElement;p=p.parentElement){const c=getComputedStyle(p);if(/hidden|clip|auto|scroll/.test(c.overflow+c.overflowX+c.overflowY)){const a=p.getBoundingClientRect();if(r.top<a.top||r.top>a.bottom-3)return null;left=Math.max(left,a.left);right=Math.min(right,a.right);}}
      if(right-left<48)return null;
      const exposed=[];
      for(const frac of [.15,.35,.5,.65,.85]){const x=left+(right-left)*frac;const hit=document.elementsFromPoint(x,r.top+Math.min(5,r.height/2)).find(n=>n!==this.host&&!this.host.contains(n));if(hit&&(hit===node||node.contains(hit)))exposed.push(x);}
      if(exposed.length<2)return null;
      left=Math.max(left,Math.min(...exposed)-12);right=Math.min(right,Math.max(...exposed)+12);
      return {element:node,left,right,top:r.top};
    }
    update(now){
      if(!this.enabled){this.items=[];return;}if(now<this.next&&!this.dirty)return;this.next=now+700;this.dirty=false;
      const candidates=document.querySelectorAll('button,a,img,h1,h2,h3,p,[data-golden-platform]'),list=[];
      for(let i=0;i<Math.min(candidates.length,600)&&list.length<45;i++){const p=this.measure(candidates[i]);if(p)list.push(p);}this.items=list;
    }
    get(element){return this.measure(element);}
    match(r){if(!r)return null;return this.items.find(p=>Math.abs(p.top-r.top)<22&&Math.abs((p.left+p.right-r.left-r.right)/2)<60)||null;}
    reachable(x,feet,scale){return this.items.filter(p=>p.top>114*scale+8&&feet-p.top>12&&feet-p.top<=195*scale&&Math.abs((p.left+p.right)/2-x)<260*scale).sort((a,b)=>Math.abs((a.left+a.right)/2-x)-Math.abs((b.left+b.right)/2-x))[0]||null;}
    route(target,x,feet,scale,support=null){
      const queue=[{point:support||{left:x-25,right:x+25,top:feet},path:[]}],seen=new Set();
      while(queue.length){const {point,path}=queue.shift();if(path.length>=4)continue;
        for(const p of this.items){if(seen.has(p.element)||p.top<114*scale+12)continue;
          const rise=point.top-p.top,dx=Math.abs((p.left+p.right-point.left-point.right)/2);
          if(rise>195*scale||rise< -200*scale||Math.abs(rise)<10)continue;
          const maxJump=Math.min(225*scale,point.top-114*scale-8);if(maxJump<Math.max(30*scale,rise+24*scale))continue;
          const v=Math.sqrt(2400*Math.max(40*scale,rise+30*scale)),time=(v+Math.sqrt(Math.max(0,v*v-2400*rise)))/1200;
          if((path.length||support)&&dx>Math.min(280*scale,time*360*scale))continue;
          const next=[...path,p];if(p.element===target.element)return next;seen.add(p.element);queue.push({point:p,path:next});
        }
      }return null;
    }
  }
  globalThis.GoldenPlatforms=Platforms;
})();
