/* Serializable scene contract. No DOM, page text, selectors or URLs are stored. */
(() => {
  const num=(v,f=0,min=-20000,max=20000)=>Number.isFinite(v)?Math.max(min,Math.min(max,v)):f;
  const pick=(raw,numbers=[],strings=[],flags=[])=>{
    if(!raw||typeof raw!=='object')return null;
    const out={};for(const k of numbers)if(Number.isFinite(raw[k]))out[k]=num(raw[k]);
    for(const k of strings)if(typeof raw[k]==='string')out[k]=raw[k].slice(0,100);
    for(const k of flags)if(typeof raw[k]==='boolean')out[k]=raw[k];return out;
  };
  const rect=r=>pick(r,['left','right','top']);
  function sanitize(raw){
    if(!raw||raw.schema!==2||!raw.pet||!Number.isFinite(raw.pet.x))return null;
    const pet={x:0,y:0,vx:0,vy:0,facing:1,elapsed:0,remaining:3,turnTo:0,landingLeft:0,sleepElapsed:0,mode:'idle',airborne:false,...pick(raw.pet,['x','y','vx','vy','facing','elapsed','remaining','turnTo','landingLeft','sleepElapsed','manualLeft','freeBallLeft','inviteLeft'],['mode'],['airborne'])};
    let job=pick(raw.job,['elapsed','index','foodX','returnX','jumpCooldown','destination','jumpHeight','jumpVX','leg','timer','progress','destinationY','anchor'],['id','type','phase','kind','token','key','skill','toy'],['scheduled','released','turned','coached','rewarded']);
    const phases={pose:['settle','animate'],home:['approach','circle','lie','sleep','wake','stretch','exit'],play:['chase','pickup','caught','return','drop','saving'],training:['settle','coach','perform','awaitReward','reward','saving'],tug:['settle','orient','play','retry','saving'],perch:['approach','flight','lost'],hop:['settle','flight'],follow:[],feed:['approach','interact','saving'],banana:['approach','interact','saving'],meal:['approach','interact','saving']};
    if(job&&(!Object.hasOwn(phases,job.type)||(phases[job.type].length&&!phases[job.type].includes(job.phase))))job=null;
    if(job?.type==='pose'&&!['blink','look','sniff','yawn','stretch','pet','belly','sit','turn','happy'].includes(job.kind))job=null;
    if(job?.type==='training'&&!['recall','shake','wait','playdead'].includes(job.skill))job=null;
    if(job)job={elapsed:0,index:0,leg:0,jumpCooldown:0,...job};
    if(job&&Array.isArray(raw.job.route))job.route=raw.job.route.slice(0,5).map(rect).filter(Boolean);
    const toys=raw.toys||{};
    return {schema:2,viewport:{w:num(raw.viewport?.w,1200,160,16000),h:num(raw.viewport?.h,800,150,16000),scale:num(raw.viewport?.scale,1,.1,2)},pet,job,
      target:Number.isFinite(raw.target)?num(raw.target):null,
      wander:pick(raw.wander,['left','direction'],['kind'])||{kind:'idle',left:3},
      windup:pick(raw.windup,['left','vy','horizontal'],['kind']),
      spring:pick(raw.spring,['value','velocity'])||{value:0,velocity:0},
      slip:pick(raw.slip,['elapsed','slideVelocity','dizzy'],['phase'],['tumble']),
      support:rect(raw.support),
      ball:raw.ball&&Number.isFinite(raw.ball.x)&&Number.isFinite(raw.ball.y)?{x:0,y:0,vx:0,vy:0,radius:11,angle:0,spin:0,bounces:0,kind:'ball',grounded:false,...pick(raw.ball,['x','y','vx','vy','radius','angle','spin','bounces'],['kind'],['grounded'])}:null,
      peels:Array.isArray(raw.peels)?raw.peels.slice(0,6).map(p=>pick(p,['x'],['id'],['armed'])).filter(Boolean):[],
      placement:['banana','play','frisbee','trampoline','blocks','perch'].includes(raw.placement)?raw.placement:null,
      aim:pick(raw.aim,['x','y']),queuedAction:typeof raw.queuedAction==='string'?raw.queuedAction.slice(0,40):null,
      toys:{pads:Array.isArray(toys.pads)?toys.pads.slice(0,2).map(p=>pick(p,['x','width','pulse','cooldown'],['id'],['armed'])).filter(Boolean):[],
        blocks:Array.isArray(toys.blocks)?toys.blocks.slice(0,12).map(p=>pick(p,['x','y','vx','vy','w','h','angle','spin'],['id'])).filter(Boolean):[],
        rope:pick(toys.rope,['x','y','vx','vy','effort','rest'],[],[])},
      savedAt:num(raw.savedAt,Date.now(),0,8640000000000000)};
  }
  class Coordinator {
    constructor(io){this.io=io;}
    async read(){const data=await this.io.read();return {data,world:data.companionWorld||{epoch:0,owner:null,seq:0,scene:null}};}
    owns(w,p,sender){return !!w.owner&&w.owner.tab===sender.tab?.id&&w.owner.client===p.client&&w.epoch===p.epoch;}
    async acquire(p,sender){
      const {data,world:w}=await this.read();
      if(!sender.tab||!p.client||!(await this.io.active(sender.tab.id)))return {ok:false,observer:true,scene:w.scene,epoch:w.epoch};
      if(w.owner?.tab===sender.tab.id&&w.owner?.client===p.client)return {ok:true,epoch:w.epoch,scene:w.scene,seq:w.seq};
      if(w.owner){
        try{
          const reply=await this.io.yield(w.owner.tab,{channel:'golden-pet',action:'yieldScene',client:w.owner.client,epoch:w.epoch});
          if(reply?.client===w.owner.client&&reply.epoch===w.epoch&&reply.seq>=w.seq){const scene=sanitize(reply.scene);if(scene){w.scene=scene;w.seq=reply.seq;}}
        }catch{/* Closed or discarded document: use its last durable checkpoint. */}
      }
      if(!(await this.io.active(sender.tab.id))){w.owner=null;w.epoch++;await this.io.write({companionWorld:w});return {ok:false,observer:true,scene:w.scene,epoch:w.epoch};}
      w.epoch++;w.owner={tab:sender.tab.id,client:String(p.client).slice(0,100)};w.seq=0;w.updatedAt=Date.now();
      await this.io.write({companionWorld:w});return {ok:true,epoch:w.epoch,scene:w.scene,seq:0,legacy:w.scene?null:GoldenCore.sanitizeScene(data.companionScene)};
    }
    async save(p,sender){
      const {world:w}=await this.read();
      if(!this.owns(w,p,sender))return {ok:false,revoked:true};
      if(!Number.isFinite(p.seq)||p.seq<=w.seq)return {ok:false,oldSequence:true};
      const scene=sanitize(p.scene);if(!scene)return {ok:false};
      w.scene=scene;w.seq=p.seq;w.updatedAt=Date.now();
      const active=await this.io.active(sender.tab.id);
      if(!active){w.owner=null;w.epoch++;}
      await this.io.write({companionWorld:w});return {ok:true,revoked:!active};
    }
    async effect(p,sender){
      const {data,world:w}=await this.read();
      if(!this.owns(w,p,sender))return {ok:false,revoked:true,message:'活动已交接到当前网页。'};
      if(typeof p.eventId!=='string'||p.eventId.length>120||!['feed','banana','meal','pet','play','rest','trainReward'].includes(p.action))return {ok:false};
      const pet=GoldenCore.normalize(data.pet);
      if(pet.completedEvents.includes(p.eventId))return {ok:true,replayed:true,state:pet,message:'已记住这次互动。'};
      const result=GoldenCore.update(pet,p.action,p.data||{});
      if(result.ok)result.state.completedEvents=[...pet.completedEvents,p.eventId].slice(-128);
      const scene=sanitize(p.scene);if(scene&&p.seq>w.seq){w.scene=scene;w.seq=p.seq;}
      await this.io.write({pet:result.state,companionWorld:w});return result;
    }
  }
  const api={sanitize,Coordinator};if(typeof module!=='undefined'&&module.exports)module.exports=api;else globalThis.GoldenScene=api;
})();
