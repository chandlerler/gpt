/* Small bounded rigid-body playground, shared by live scene and tests. */
(() => {
  const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
  function stepBlocks(input,dt,bounds){
    const blocks=input.map(b=>({...b}));
    for(const b of blocks){b.vy+=1000*dt;b.x+=b.vx*dt;b.y+=b.vy*dt;b.angle+=b.spin*dt;b.spin*=Math.exp(-2*dt);
      if(b.x<0||b.x+b.w>bounds.width){b.x=clamp(b.x,0,bounds.width-b.w);b.vx*=-.35;}
      if(b.y+b.h>=bounds.height){b.y=bounds.height-b.h;b.vy=Math.abs(b.vy)<60?0:-b.vy*.18;b.vx*=Math.exp(-6*dt);b.spin*=Math.exp(-8*dt);b.angle+=(Math.round(b.angle/(Math.PI/2))*(Math.PI/2)-b.angle)*Math.min(1,dt*8);}}
    for(let iteration=0;iteration<3;iteration++)for(let i=0;i<blocks.length;i++)for(let j=i+1;j<blocks.length;j++){
      const a=blocks[i],b=blocks[j],dx=(a.x+a.w/2)-(b.x+b.w/2),dy=(a.y+a.h/2)-(b.y+b.h/2),ox=(a.w+b.w)/2-Math.abs(dx),oy=(a.h+b.h)/2-Math.abs(dy);
      if(ox<=0||oy<=0)continue;
      if(oy<ox){const top=dy<0?a:b,bottom=dy<0?b:a;top.y=bottom.y-top.h;top.vy=Math.min(top.vy,bottom.vy);top.vx*=Math.exp(-3*dt);}
      else {const sign=dx<0?-1:1;a.x+=sign*ox/2;b.x-=sign*ox/2;const impulse=(a.vx-b.vx)*.55;a.vx-=impulse;b.vx+=impulse;}
    }
    return blocks;
  }
  function hitBlocks(ball,blocks){
    if(!ball)return ball;
    for(const b of blocks){const cx=clamp(ball.x,b.x,b.x+b.w),cy=clamp(ball.y,b.y,b.y+b.h),dx=ball.x-cx,dy=ball.y-cy,d=Math.hypot(dx,dy);
      if(d>=ball.radius)continue;
      let nx=d>.001?dx/d:(ball.x<b.x+b.w/2?-1:1),ny=d>.001?dy/d:0;
      ball.x+=nx*(ball.radius-d+.1);ball.y+=ny*(ball.radius-d+.1);
      const relative=(ball.vx-b.vx)*nx+(ball.vy-b.vy)*ny;
      if(relative<0){const impulse=-relative*.95;ball.vx+=impulse*nx;ball.vy+=impulse*ny;b.vx-=impulse*nx*.5;b.vy-=impulse*ny*.5;b.spin+=clamp((cy-b.y-b.h/2)*impulse*.001,-12,12);ball.grounded=false;ball.bounces++;}
    }return ball;
  }
  function stepRope(rope,mouth,dt){
    if(rope.held)return rope;
    const dx=rope.x-mouth.x,dy=rope.y-mouth.y,d=Math.max(1,Math.hypot(dx,dy)),stretch=d-rope.rest;
    rope.vx+=(-dx/d*stretch*30-rope.vx*7)*dt;rope.vy+=(-dy/d*stretch*30-rope.vy*7+35)*dt;
    rope.x+=rope.vx*dt;rope.y+=rope.vy*dt;return rope;
  }
  const api={stepBlocks,hitBlocks,stepRope};if(typeof module!=='undefined'&&module.exports)module.exports=api;else globalThis.GoldenToys=api;
})();
